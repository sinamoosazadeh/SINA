PINE SCRIPT (sina) 

List: 

1. OMEGA (sina) 
2. ULI - Ultimate Liquidity Intelligence (sina) 
3. IQCE - Institutional Quantum Confluence Engine (sina) 
4. UICE - Ultra-Institutional Composite Engine (sina) 
5. Multi-Strategy Container (sina) 
6  APEX MERIDIAN (sina) 
7. 
8. 
9. 
10. 

======================================================================

1. OMEGA (sina) 

//@version=6
indicator("OMEGA (sina)", overlay=true, max_bars_back=5000, max_labels_count=500, max_boxes_count=500, max_lines_count=150)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 0: CUSTOM TYPES
// ═══════════════════════════════════════════════════════════════════════════

type MarketSnapshot
    float open       = na
    float high       = na
    float low        = na
    float close      = na
    float volume     = na
    float atr        = na
    float atr_50     = na
    float vwap       = na
    float volatility = na

type RegimeState
    string regimeType   = "NEUTRAL"
    float regimeScore   = 50.0
    float confidence    = 50.0
    float trendStrength = 50.0
    float hurst         = 0.5
    float entropy       = 0.5
    float adx           = 0.0
    float atrRatio      = 1.0
    int   direction     = 0

type StructureState
    float score           = 50.0
    bool  bosBull         = false
    bool  bosBear         = false
    bool  chochBull       = false
    bool  chochBear       = false
    bool  mssBull         = false
    bool  mssBear         = false
    float swingHigh       = na
    float swingLow        = na
    float premiumDiscount = 50.0

type LiquidityState
    float score      = 50.0
    float sslLevel   = na
    float bslLevel   = na
    bool  sweepBull  = false
    bool  sweepBear  = false
    float sweepScore = 0.0
    float eqh        = na
    float eql        = na

type ContextState
    float score        = 50.0
    bool  btcAlignment = false
    bool  htfAlignment = false
    int   htfDirection = 0
    float vwapDist     = 0.0
    float volumeRatio  = 1.0

type QuantState
    float score            = 50.0
    float zscore           = 0.0
    float momentum         = 0.0
    float volExpansion     = 0.0
    float linRegSlope      = 0.0
    float meanReversion    = 0.0
    float trendPersistence = 0.0
    float efficiency       = 0.0

type ConfluenceState
    float longScore  = 50.0
    float shortScore = 50.0
    float rawScore   = 50.0
    float agreement  = 0.0

type ProbabilityState
    float longProb     = 0.0
    float shortProb    = 0.0
    float neutralProb  = 0.0
    float confidence   = 0.0
    float expectedMove = na

type TradeState
    bool   active          = false
    int    direction       = 0
    string rank            = "NONE"
    string setupType       = "NONE"
    float  entryPrice      = na
    float  stopLoss        = na
    float  tp1             = na
    float  tp2             = na
    float  tp3             = na
    float  tp4             = na
    float  posSize         = na
    float  currentQty      = 0.0
    float  accPnL          = 0.0
    int    entryBar        = 0
    bool   tp1Hit          = false
    bool   tp2Hit          = false
    bool   breakevenActive = false
    bool   trailActive     = false
    float  trailStop       = na

type HistoricalTrade
    string regime     = "NEUTRAL"
    string setupType  = "NONE"
    string rank       = "NONE"
    bool   isWin      = false
    float  pnl        = 0.0
    float  entryPrice = na
    float  exitPrice  = na
    float  rr         = 0.0

type BlockZone
    int   id           = 0
    int   zoneType     = 0
    bool  isBullish    = false
    float top          = na
    float bottom       = na
    float midpoint     = na
    float strength     = 0.0
    int   createdBar   = 0
    bool  isMitigated  = false
    int   mitigatedBar = 0
    box   visualBox    = na

type TradeVisual
    int entryBar
    int endBar
    int direction
    float entryPrice
    float sl
    float tp1
    float tp2
    float tp3
    float tp4
    bool isFinalized
    bool slHit
    bool tp1Hit
    bool tp2Hit
    bool tp3Hit
    bool tp4Hit
    line entryLine
    line slLine
    line tp1Line
    line tp2Line
    line tp3Line
    line tp4Line
    label entryLabel
    label slLabel
    label tp1Label
    label tp2Label
    label tp3Label
    label tp4Label
    box profitBox
    box lossBox

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: INPUTS
// ═══════════════════════════════════════════════════════════════════════════

grpMaster = "══════ MASTER CONTROLS ══════"
i_showDashboard  = input.bool(true, "Show Institutional Dashboard", group=grpMaster)
i_showSignals    = input.bool(true, "Show Entry Signals", group=grpMaster)
i_showZones      = input.bool(true, "Show OB/FVG/Liquidity Zones", group=grpMaster)
i_showStructure  = input.bool(true, "Show Structure Labels", group=grpMaster)
i_enableBacktest = input.bool(true, "Enable Live Backtest Engine", group=grpMaster)
i_dbPos          = input.string("top_right", "Dashboard HUD Position", options=["top_right","bottom_right","top_left","bottom_left"], group=grpMaster)

grpHTF = "══════ MULTI-TIMEFRAME ANALYSIS ══════"
i_htf1 = input.timeframe("240", "HTF 1 - Primary Structure", group=grpHTF)
i_htf2 = input.timeframe("60", "HTF 2 - Intermediate Trend", group=grpHTF)
i_htf3 = input.timeframe("15", "HTF 3 - Macro Bias", group=grpHTF)

grpSMC = "══════ SMART MONEY CONCEPTS ══════"
i_swingLen       = input.int(6, "Swing Pivot Length", minval=2, maxval=50, group=grpSMC)
i_obDisplacement = input.float(1.15, "OB Displacement ATR Mult", minval=0.5, step=0.1, group=grpSMC)
i_obMaxAge       = input.int(220, "Zone Max Age Bars", minval=25, maxval=1000, group=grpSMC)
i_fvgMinSize     = input.float(0.08, "FVG Min Size ATR Mult", minval=0.01, step=0.01, group=grpSMC)
i_liqTolerance   = input.float(0.08, "EQH/EQL Tolerance ATR", minval=0.01, step=0.01, group=grpSMC)

grpQuant = "══════ QUANTITATIVE MATH ══════"
i_zscoreLen     = input.int(20, "Z-Score Length", minval=5, maxval=200, group=grpQuant)
i_momentumLen   = input.int(14, "Momentum RSI Length", minval=5, maxval=100, group=grpQuant)
i_meanRevThresh = input.float(2.2, "Mean Reversion Threshold Sigma", minval=0.5, step=0.1, group=grpQuant)

grpExec = "══════ VIRTUAL EXECUTION & RISK ══════"
i_totalCapital  = input.float(10000.0, "Total Initial Capital", minval=100.0, group=grpExec)
i_baseCurrency  = input.string("USDT", "Main Currency Symbol", group=grpExec)
i_riskPerTrade  = input.float(3.0, "Base Risk % per Trade", minval=0.1, maxval=10.0, step=0.1, group=grpExec)

i_activeTrig    = input.bool(true, "Active Trigger Line", inline="trig", group=grpExec)

i_activeSL      = input.bool(true, "Active Stop Loss", inline="sl", group=grpExec)
i_slAtrMult     = input.float(1.5, "Stop Loss ATR Mult", minval=0.5, step=0.1, inline="sl", group=grpExec)

i_activeTP1     = input.bool(true, "Active TP1", inline="tp1", group=grpExec)
i_tp1R          = input.float(1.0, "TP1 R-Multiple", minval=0.1, step=0.1, inline="tp1", group=grpExec)

i_activeTP2     = input.bool(true, "Active TP2", inline="tp2", group=grpExec)
i_tp2R          = input.float(1.2, "TP2 R-Multiple", minval=0.1, step=0.1, inline="tp2", group=grpExec)

i_activeTP3     = input.bool(true, "Active TP3", inline="tp3", group=grpExec)
i_tp3R          = input.float(1.5, "TP3 R-Multiple", minval=0.1, step=0.1, inline="tp3", group=grpExec)

i_activeTP4     = input.bool(true, "Active TP4", inline="tp4", group=grpExec)
i_tp4R          = input.float(2.0, "TP4 R-Multiple", minval=0.1, step=0.1, inline="tp4", group=grpExec)

i_tp1Pct        = input.float(30.0, "TP1 Close %", minval=1, maxval=100, step=1, group=grpExec)
i_tp2Pct        = input.float(30.0, "TP2 Close %", minval=1, maxval=100, step=1, group=grpExec)
i_trailAfterTP2 = input.bool(true, "Enable Structure-Based Trailing Stop", group=grpExec)
i_maxConsecLoss = input.int(5, "Max Consecutive Losses Kill Switch", minval=2, maxval=20, group=grpExec)
i_cooldownBars  = input.int(20, "Kill Switch Cooldown Bars", minval=5, maxval=500, group=grpExec)
i_slippagePct   = input.float(0.02, "Slippage + Fees % (Standard)", minval=0.0, step=0.01, group=grpExec)

grpStyleControls = "══════ GLOBAL STYLE CONTROLS ══════"
i_showTable      = input.bool(true, "Show Dashboard Table", group=grpStyleControls)
i_showPaneLabels = input.bool(true, "Show On-Chart Pane Labels", group=grpStyleControls)
i_showBoxes      = input.bool(true, "Show OB/FVG Boxes", group=grpStyleControls)
i_showLines      = input.bool(true, "Show Risk Management Lines", group=grpStyleControls)

grpRiskVisual = "══════ RISK VISUAL CUSTOMIZATION ══════"
i_showRiskVisuals = input.bool(true, "Show Complete Risk Visual System", group=grpRiskVisual)
i_maxRiskVisuals  = input.int(80, "Max Risk Visual Signals", minval=5, maxval=150, group=grpRiskVisual)

i_tp1Color = input.color(#14532d, "TP1 Dark Green", group=grpRiskVisual)
i_tp2Color = input.color(#166534, "TP2 Medium-Dark Green", group=grpRiskVisual)
i_tp3Color = input.color(#22c55e, "TP3 Normal Green", group=grpRiskVisual)
i_tp4Color = input.color(#86efac, "TP4 Light Green", group=grpRiskVisual)
i_tpWidth  = input.int(1, "TP Line Width", minval=1, maxval=10, group=grpRiskVisual)

i_slColor = input.color(#ef4444, "SL Red Color", group=grpRiskVisual)
i_slWidth = input.int(1, "SL Line Width", minval=1, maxval=10, group=grpRiskVisual)

i_trigColor = input.color(#6366f1, "Trigger Indigo Color", group=grpRiskVisual)
i_trigWidth = input.int(1, "Trigger Line Width", minval=1, maxval=10, group=grpRiskVisual)

i_profitZoneColor = input.color(color.new(#089981, 90), "Profit Zone Bg (Standard 10% Opacity)", group=grpRiskVisual)
i_lossZoneColor   = input.color(color.new(#f23645, 90), "Loss Zone Bg (Standard 10% Opacity)", group=grpRiskVisual)

grpStyleColors = "══════ STYLE COLOR CUSTOMIZATION ══════"
C_BULL       = input.color(color.rgb(20, 184, 166), "Bullish Color", group=grpStyleColors)
C_BULL_DARK  = input.color(color.rgb(6, 78, 59), "Bullish Dark Color", group=grpStyleColors)
C_BEAR       = input.color(color.rgb(244, 63, 94), "Bearish Color", group=grpStyleColors)
C_BEAR_DARK  = input.color(color.rgb(127, 29, 29), "Bearish Dark Color", group=grpStyleColors)
C_GOLD       = input.color(color.rgb(245, 158, 11), "Gold Color", group=grpStyleColors)
C_BLUE       = input.color(color.rgb(59, 130, 246), "Blue Color", group=grpStyleColors)
C_CYAN       = input.color(color.rgb(34, 211, 238), "Cyan Color", group=grpStyleColors)
C_TEXT       = input.color(color.rgb(241, 245, 249), "Text Color", group=grpStyleColors)
C_MUTED      = input.color(color.rgb(148, 163, 184), "Muted Text Color", group=grpStyleColors)
C_PANEL      = input.color(color.rgb(17, 24, 39), "Panel Header Color", group=grpStyleColors)
C_DB_BG      = input.color(color.rgb(8, 13, 21), "Dashboard BG Color", group=grpStyleColors)
C_GRID       = input.color(color.rgb(36, 48, 64), "Grid Line Color", group=grpStyleColors)

C_EMA9       = input.color(color.rgb(250, 204, 21), "EMA 9 Color", group=grpStyleColors)
C_EMA21      = input.color(color.rgb(251, 146, 60), "EMA 21 Color", group=grpStyleColors)
C_EMA50      = input.color(color.rgb(59, 130, 246), "EMA 50 Color", group=grpStyleColors)
C_EMA200     = input.color(color.rgb(148, 163, 184), "EMA 200 Color", group=grpStyleColors)

grpWeights = "══════ DYNAMIC WEIGHTS ══════"
i_wStructure    = input.float(1.3, "Structure Weight", minval=0.0, maxval=2.0, step=0.1, group=grpWeights)
i_wLiquidity    = input.float(1.3, "Liquidity Weight", minval=0.0, maxval=2.0, step=0.1, group=grpWeights)
i_wQuant        = input.float(1.0, "Quant Weight", minval=0.0, maxval=2.0, step=0.1, group=grpWeights)
i_wContext      = input.float(0.7, "Context Weight", minval=0.0, maxval=2.0, step=0.1, group=grpWeights)
i_wRegime       = input.float(0.7, "Regime Weight", minval=0.0, maxval=2.0, step=0.1, group=grpWeights)
i_adaptLearning = input.bool(true, "Enable Adaptive Confluence Learning", group=grpWeights)

grpThresh = "══════ SCORING THRESHOLDS ══════"
i_minLongScore  = input.float(70.0, "Min Long Confluence Score", minval=30, maxval=90, step=1, group=grpThresh)
i_minShortScore = input.float(70.0, "Min Short Confluence Score", minval=30, maxval=90, step=1, group=grpThresh)
i_minProb       = input.float(70.0, "Min Probability %", minval=40, maxval=90, step=1, group=grpThresh)
i_scoreDiff     = input.float(8.0, "Min Score Differential", minval=2, maxval=30, step=1, group=grpThresh)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: CONSTANTS / GLOBALS
// ═══════════════════════════════════════════════════════════════════════════

MAX_SIGNAL_LABELS    = 300
MAX_STRUCTURE_LABELS = 180
MAX_ACTIVE_ZONES     = 120

var float[] swingHighs = array.new<float>(0)
var float[] swingLows  = array.new<float>(0)
var BlockZone[] activeZones = array.new<BlockZone>(0)
var int zoneCounter = 0

var label[] signalLabels    = array.new<label>(0)
var label[] structureLabels = array.new<label>(0)

var TradeState activeTrade = TradeState.new()
var float virtualEquity = i_totalCapital
var float peakEquity    = i_totalCapital
var float maxDrawdown   = 0.0
var HistoricalTrade[] tradeHistory = array.new<HistoricalTrade>(0)

var int consecutiveLosses = 0
var int killSwitchBar = 0
var bool killActive = false

var float adaptStructWeight  = 1.0
var float adaptLiquWeight    = 1.0
var float adaptQuantWeight   = 1.0
var float adaptContextWeight = 1.0
var float adaptRegimeWeight  = 1.0

var TradeVisual[] activeVisuals = array.new<TradeVisual>(0)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: HELPERS
// ═══════════════════════════════════════════════════════════════════════════

f_clamp(float val, float minV, float maxV) =>
    math.max(minV, math.min(maxV, val))

f_norm(float val, float minV, float maxV) =>
    maxV != minV ? f_clamp((val - minV) / (maxV - minV) * 100.0, 0.0, 100.0) : 50.0

f_zscore(series float src, int len) =>
    float mean = nz(ta.sma(src, len), src)
    float std  = nz(ta.stdev(src, len), 0.0)
    std > 0 ? (src - mean) / std : 0.0

f_hurst(series float src, int len) =>
    float mean = nz(ta.sma(src, len), src)
    float std  = nz(ta.stdev(src, len), 0.0)
    float maxDev = 0.0
    float minDev = 0.0
    float cum = 0.0
    for i = 0 to len - 1
        cum += nz(src[i], src) - mean
        maxDev := math.max(maxDev, cum)
        minDev := math.min(minDev, cum)
    float rs = std > 0 ? (maxDev - minDev) / std : 0.0
    rs > 0 ? f_clamp(math.log(rs) / math.log(len), 0.0, 1.0) : 0.5

f_entropy(series float src, int len) =>
    float out = 0.5
    float minV = ta.lowest(src, len)
    float maxV = ta.highest(src, len)
    float rangeV = maxV - minV
    if not na(minV) and not na(maxV) and rangeV > 0
        float[] bins = array.new_float(10, 0.0)
        for i = 0 to len - 1
            int idx = int((nz(src[i], src) - minV) / rangeV * 9.0)
            idx := int(f_clamp(idx, 0, 9))
            array.set(bins, idx, array.get(bins, idx) + 1.0)
        float ent = 0.0
        for i = 0 to 9
            float p = array.get(bins, i) / len
            if p > 0
                ent -= p * math.log(p)
        out := ent > 0 ? ent / math.log(10.0) : 0.0
    out

f_linreg_slope(series float src, int len) =>
    float sumX = 0.0
    float sumY = 0.0
    float sumXY = 0.0
    float sumX2 = 0.0
    for i = 0 to len - 1
        float x = float(len - 1 - i)
        float y = nz(src[i], src)
        sumX += x
        sumY += y
        sumXY += x * y
        sumX2 += x * x
    float denom = len * sumX2 - sumX * sumX
    denom != 0 ? (len * sumXY - sumX * sumY) / denom : 0.0

f_mtf_close(string tf) =>
    request.security(syminfo.tickerid, tf, close[1], barmerge.gaps_off, barmerge.lookahead_off)

f_mtf_ema(string tf, int len) =>
    request.security(syminfo.tickerid, tf, ta.ema(close, len)[1], barmerge.gaps_off, barmerge.lookahead_off)

f_adx(int len) =>
    [plus, minus, adxValue] = ta.dmi(len, len)
    adxValue

f_volume_delta() =>
    float rng = high - low + 1e-10
    (close - open) / rng * volume

f_table_pos(string posStr) =>
    posStr == "top_right" ? position.top_right : posStr == "bottom_right" ? position.bottom_right : posStr == "top_left" ? position.top_left : position.bottom_left

f_push_label(label[] arr, label id, int maxCount) =>
    array.push(arr, id)
    if array.size(arr) > maxCount
        label old = array.shift(arr)
        if not na(old)
            label.delete(old)

f_prune_zones(BlockZone[] zones, int maxCount) =>
    while array.size(zones) > maxCount
        BlockZone old = array.pop(zones)
        if not na(old.visualBox)
            box.delete(old.visualBox)

f_create_visual(int entryBar, int dir, float entry, float sl, float tp1, float tp2, float tp3, float tp4) =>
    TradeVisual.new(
      entryBar=entryBar,
      endBar=entryBar,
      direction=dir,
      entryPrice=entry,
      sl=sl,
      tp1=tp1,
      tp2=tp2,
      tp3=tp3,
      tp4=tp4,
      isFinalized=false,
      slHit=false,
      tp1Hit=false,
      tp2Hit=false,
      tp3Hit=false,
      tp4Hit=false,
      entryLine=line.new(entryBar, entry, entryBar, entry, color=color.new(color.white, 100)),
      slLine=line.new(entryBar, sl, entryBar, sl, color=color.new(color.white, 100)),
      tp1Line=line.new(entryBar, tp1, entryBar, tp1, color=color.new(color.white, 100)),
      tp2Line=line.new(entryBar, tp2, entryBar, tp2, color=color.new(color.white, 100)),
      tp3Line=line.new(entryBar, tp3, entryBar, tp3, color=color.new(color.white, 100)),
      tp4Line=line.new(entryBar, tp4, entryBar, tp4, color=color.new(color.white, 100)),
      entryLabel=label.new(entryBar, entry, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      slLabel=label.new(entryBar, sl, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      tp1Label=label.new(entryBar, tp1, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      tp2Label=label.new(entryBar, tp2, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      tp3Label=label.new(entryBar, tp3, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      tp4Label=label.new(entryBar, tp4, "", color=color.new(color.black, 100), style=label.style_label_left, textcolor=color.new(color.white, 0), size=size.tiny),
      profitBox=box.new(entryBar, math.max(entry, tp4), entryBar, math.min(entry, tp4), bgcolor=color.new(color.white, 100), border_color=color.new(color.white, 100)),
      lossBox=box.new(entryBar, math.max(entry, sl), entryBar, math.min(entry, sl), bgcolor=color.new(color.white, 100), border_color=color.new(color.white, 100))
    )

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: CACHED INDICATORS
// ═══════════════════════════════════════════════════════════════════════════

float cached_atr_14  = ta.atr(14)
float cached_atr_50  = ta.atr(50)
float cached_vwap    = ta.vwap(hlc3)
float main_rsi       = ta.rsi(close, i_momentumLen)
float cached_ema_9   = ta.ema(close, 9)
float cached_ema_21  = ta.ema(close, 21)
float cached_ema_50  = ta.ema(close, 50)
float cached_ema_200 = ta.ema(close, 200)
float main_zscore    = f_zscore(close, i_zscoreLen)
float main_adx       = f_adx(14)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: CORE ENGINES
// ═══════════════════════════════════════════════════════════════════════════

f_market_snapshot(float atr14, float atr50, float vwapVal) =>
    float safeVwap = nz(vwapVal, close)
    float vol = atr14 / (close + 1e-10) * 100.0
    MarketSnapshot.new(open, high, low, close, volume, atr14, atr50, safeVwap, vol)

f_regime_engine(MarketSnapshot snap, float adxVal, float ema50Val, float ema200Val) =>
    float atrRatio = snap.atr / (snap.atr_50 + 1e-10)
    float hurst = f_hurst(close, 50)
    float entropy = f_entropy(close, 50)

    float lTrend = math.exp(-math.pow(hurst - 0.70, 2) / 0.10) * (adxVal / 100.0) * (1.0 - entropy)
    float lRange = math.exp(-math.pow(hurst - 0.40, 2) / 0.10) * (1.0 - adxVal / 100.0) * entropy
    float lExp   = math.exp(-math.pow(atrRatio - 1.50, 2) / 0.20) * (adxVal / 100.0)
    float lComp  = math.exp(-math.pow(atrRatio - 0.60, 2) / 0.15) * (1.0 - hurst)

    float total = lTrend + lRange + lExp + lComp + 1e-10
    float pTrend = lTrend / total
    float pRange = lRange / total
    float pExp   = lExp / total
    float pComp  = lComp / total

    string regime = "NEUTRAL"
    float conf = 50.0

    if pTrend > pRange and pTrend > pExp and pTrend > pComp
        regime := adxVal > 25 ? "STRONG_TREND" : "WEAK_TREND"
        conf := pTrend * 100.0
    else if pRange > pTrend and pRange > pExp and pRange > pComp
        regime := "RANGE"
        conf := pRange * 100.0
    else if pExp > pTrend and pExp > pRange and pExp > pComp
        regime := "EXPANSION"
        conf := pExp * 100.0
    else
        regime := "COMPRESSION"
        conf := pComp * 100.0

    int dir = 0
    if close > ema50Val and ema50Val >= ema200Val
        dir := 1
    else if close < ema50Val and ema50Val <= ema200Val
        dir := -1
    else if close > ema50Val
        dir := 1
    else if close < ema50Val
        dir := -1

    float amp = regime == "STRONG_TREND" ? f_clamp(22.0 + (adxVal - 25.0) * 0.6, 22.0, 40.0) : regime == "WEAK_TREND" ? 15.0 : regime == "EXPANSION" ? 18.0 : regime == "RANGE" ? 7.0 : 3.0
    float score = f_clamp(50.0 + dir * amp, 0.0, 100.0)
    RegimeState.new(regime, score, conf, adxVal, hurst, entropy, adxVal, atrRatio, dir)

f_structure_engine(float ph, float pl, float htfClose, float htfEma) =>
    var float lastHigh = na
    var float lastLow = na
    var float brokenHigh = na
    var float brokenLow = na
    var int trendDir = 0

    if not na(ph)
        if na(lastHigh) or ph != lastHigh
            lastHigh := ph
            brokenHigh := na

    if not na(pl)
        if na(lastLow) or pl != lastLow
            lastLow := pl
            brokenLow := na

    bool bosBull = not na(lastHigh) and close > lastHigh and (na(brokenHigh) or brokenHigh != lastHigh)
    bool bosBear = not na(lastLow) and close < lastLow and (na(brokenLow) or brokenLow != lastLow)

    if bosBull
        brokenHigh := lastHigh
    if bosBear
        brokenLow := lastLow

    bool chochBull = false
    bool chochBear = false

    if bosBull and trendDir == -1
        chochBull := true
        trendDir := 1
    else if bosBear and trendDir == 1
        chochBear := true
        trendDir := -1
    else if trendDir == 0
        trendDir := bosBull ? 1 : bosBear ? -1 : 0
    else if bosBull
        trendDir := 1
    else if bosBear
        trendDir := -1

    bool mssBull = chochBull and not na(htfClose) and not na(htfEma) and htfClose > htfEma
    bool mssBear = chochBear and not na(htfClose) and not na(htfEma) and htfClose < htfEma

    float score = 50.0
    if mssBull
        score := 82.0
    else if mssBear
        score := 18.0
    else if chochBull
        score := 75.0
    else if chochBear
        score := 25.0
    else if bosBull
        score := 70.0
    else if bosBear
        score := 30.0

    float pd = 50.0
    if not na(lastHigh) and not na(lastLow) and (lastHigh - lastLow) > 0
        pd := f_clamp((close - lastLow) / (lastHigh - lastLow) * 100.0, 0.0, 100.0)

    StructureState.new(score, bosBull, bosBear, chochBull, chochBear, mssBull, mssBear, lastHigh, lastLow, pd)

f_liquidity_engine(float ph, float pl, float atr, float[] sHighs, float[] sLows, float volDeltaVal, float absVolDeltaSMAVal) =>
    if not na(ph)
        array.unshift(sHighs, ph)
        if array.size(sHighs) > 80
            array.pop(sHighs)

    if not na(pl)
        array.unshift(sLows, pl)
        if array.size(sLows) > 80
            array.pop(sLows)

    float ssl = na
    float bsl = na
    bool sweepBull = false
    bool sweepBear = false
    float sweepScore = 0.0
    float eqh = na
    float eql = na

    float absDeltaAvg = nz(absVolDeltaSMAVal, math.abs(volDeltaVal))
    bool volConfirmed = absDeltaAvg <= 0 ? true : math.abs(volDeltaVal) > absDeltaAvg * 1.05

    if array.size(sLows) > 0
        float recentLow = array.get(sLows, 0)
        ssl := recentLow
        if low < recentLow and close > recentLow and volConfirmed
            sweepBull := true
            sweepScore := f_norm((recentLow - low) / (atr + 1e-10), 0.0, 2.0)

    if array.size(sHighs) > 0
        float recentHigh = array.get(sHighs, 0)
        bsl := recentHigh
        if high > recentHigh and close < recentHigh and volConfirmed
            sweepBear := true
            sweepScore := f_norm((high - recentHigh) / (atr + 1e-10), 0.0, 2.0)

    if array.size(sHighs) >= 2
        bool foundEQH = false
        int limH = math.min(10, array.size(sHighs) - 1)
        for i = 0 to limH - 1
            for j = i + 1 to limH
                if not foundEQH and math.abs(array.get(sHighs, i) - array.get(sHighs, j)) <= atr * i_liqTolerance
                    eqh := array.get(sHighs, i)
                    foundEQH := true

    if array.size(sLows) >= 2
        bool foundEQL = false
        int limL = math.min(10, array.size(sLows) - 1)
        for i = 0 to limL - 1
            for j = i + 1 to limL
                if not foundEQL and math.abs(array.get(sLows, i) - array.get(sLows, j)) <= atr * i_liqTolerance
                    eql := array.get(sLows, i)
                    foundEQL := true

    float score = 50.0
    if sweepBull
        score := 50.0 + sweepScore * 0.50
    else if sweepBear
        score := 50.0 - sweepScore * 0.50
    else if not na(eql)
        score := 58.0
    else if not na(eqh)
        score := 42.0

    LiquidityState.new(f_clamp(score, 0.0, 100.0), ssl, bsl, sweepBull, sweepBear, sweepScore, eqh, eql)

f_ob_fvg_engine(float atr, BlockZone[] zones, color bullCol, color bearCol, int currentCounter, bool sweepBull, bool sweepBear) =>
    int updatedCounter = currentCounter
    float candleRange = high - low
    float displacement = candleRange / (atr + 1e-10)

    if barstate.isconfirmed and displacement > i_obDisplacement and candleRange > atr * 0.5
        int bullIdx = na
        int bearIdx = na

        if close > open
            for j = 1 to 5
                if na(bullIdx) and close[j] < open[j]
                    bullIdx := j

        if close < open
            for j = 1 to 5
                if na(bearIdx) and close[j] > open[j]
                    bearIdx := j

        if not na(bullIdx)
            float top = math.max(open[bullIdx], close[bullIdx])
            float bottom = math.min(open[bullIdx], close[bullIdx])
            box bx = na
            if i_showZones and i_showBoxes
                bx := box.new(bar_index - bullIdx, top, bar_index + 5, bottom, bgcolor=color.new(bullCol, 88), border_color=color.new(bullCol, 45))
            array.unshift(zones, BlockZone.new(updatedCounter, 0, true, top, bottom, (top + bottom) / 2.0, displacement, bar_index, false, 0, bx))
            updatedCounter += 1

        if not na(bearIdx)
            float top = math.max(open[bearIdx], close[bearIdx])
            float bottom = math.min(open[bearIdx], close[bearIdx])
            box bx = na
            if i_showZones and i_showBoxes
                bx := box.new(bar_index - bearIdx, top, bar_index + 5, bottom, bgcolor=color.new(bearCol, 88), border_color=color.new(bearCol, 45))
            array.unshift(zones, BlockZone.new(updatedCounter, 0, false, top, bottom, (top + bottom) / 2.0, displacement, bar_index, false, 0, bx))
            updatedCounter += 1

    if barstate.isconfirmed and bar_index > 2
        float bullGap = low - high[2]
        if bullGap > atr * i_fvgMinSize
            box bx = na
            if i_showZones and i_showBoxes
                bx := box.new(bar_index - 2, low, bar_index + 5, high[2], bgcolor=color.new(bullCol, 92), border_color=color.new(bullCol, 65))
            array.unshift(zones, BlockZone.new(updatedCounter, 3, true, low, high[2], (low + high[2]) / 2.0, bullGap / (atr + 1e-10), bar_index, false, 0, bx))
            updatedCounter += 1

        float bearGap = low[2] - high
        if bearGap > atr * i_fvgMinSize
            box bx = na
            if i_showZones and i_showBoxes
                bx := box.new(bar_index - 2, low[2], bar_index + 5, high, bgcolor=color.new(bearCol, 92), border_color=color.new(bearCol, 65))
            array.unshift(zones, BlockZone.new(updatedCounter, 3, false, low[2], high, (low[2] + high) / 2.0, bearGap / (atr + 1e-10), bar_index, false, 0, bx))
            updatedCounter += 1

    f_prune_zones(zones, MAX_ACTIVE_ZONES)

    int i = array.size(zones) - 1
    while i >= 0
        BlockZone zone = array.get(zones, i)

        if not zone.isMitigated and bar_index > zone.createdBar
            bool overlapped = low <= zone.top and high >= zone.bottom

            if zone.zoneType != 3
                if zone.isBullish and close < zone.bottom
                    zone.isBullish := false
                    zone.zoneType := sweepBear ? 1 : 2
                    zone.strength *= 0.8
                    if not na(zone.visualBox)
                        box.set_bgcolor(zone.visualBox, color.new(bearCol, 90))
                        box.set_border_color(zone.visualBox, color.new(bearCol, 55))
                else if not zone.isBullish and close > zone.top
                    zone.isBullish := true
                    zone.zoneType := sweepBull ? 1 : 2
                    zone.strength *= 0.8
                    if not na(zone.visualBox)
                        box.set_bgcolor(zone.visualBox, color.new(bullCol, 90))
                        box.set_border_color(zone.visualBox, color.new(bullCol, 55))

            if overlapped
                zone.isMitigated := true
                zone.mitigatedBar := bar_index
                if not na(zone.visualBox)
                    box.delete(zone.visualBox)
            else if bar_index - zone.createdBar > i_obMaxAge
                zone.isMitigated := true
                if not na(zone.visualBox)
                    box.delete(zone.visualBox)
            else
                if not na(zone.visualBox)
                    box.set_right(zone.visualBox, bar_index + 5)

            array.set(zones, i, zone)

        if zone.isMitigated
            array.remove(zones, i)

        i -= 1

    float blockScore = 50.0
    float bestDist = na
    if array.size(zones) > 0
        for k = 0 to array.size(zones) - 1
            BlockZone z = array.get(zones, k)
            float dist = math.min(math.abs(close - z.top), math.abs(close - z.bottom))
            if na(bestDist) or dist < bestDist
                bestDist := dist
                float raw = f_norm(z.strength / (dist / (atr + 1e-10) + 1.0), 0.0, 4.0)
                blockScore := z.isBullish ? raw : 100.0 - raw

    [f_clamp(blockScore, 0.0, 100.0), updatedCounter]

f_context_engine(MarketSnapshot snap, float htf1C, float htf1E, float htf2C, float htf2E, float htf3C, float htf3E, float btcC, float btcE) =>
    bool h1Bull = not na(htf1C) and not na(htf1E) and htf1C > htf1E
    bool h2Bull = not na(htf2C) and not na(htf2E) and htf2C > htf2E
    bool h3Bull = not na(htf3C) and not na(htf3E) and htf3C > htf3E
    bool h1Bear = not na(htf1C) and not na(htf1E) and htf1C < htf1E
    bool h2Bear = not na(htf2C) and not na(htf2E) and htf2C < htf2E
    bool h3Bear = not na(htf3C) and not na(htf3E) and htf3C < htf3E

    int bullVotes = (h1Bull ? 1 : 0) + (h2Bull ? 1 : 0) + (h3Bull ? 1 : 0)
    int bearVotes = (h1Bear ? 1 : 0) + (h2Bear ? 1 : 0) + (h3Bear ? 1 : 0)
    int htfDir = bullVotes >= 2 ? 1 : bearVotes >= 2 ? -1 : 0

    int btcDir = not na(btcC) and not na(btcE) ? btcC > btcE ? 1 : btcC < btcE ? -1 : 0 : htfDir
    bool btcAlign = btcDir == htfDir and htfDir != 0

    int vwapDir = close > snap.vwap ? 1 : close < snap.vwap ? -1 : 0
    float volAvg = ta.sma(volume, 20)
    float volRatio = volAvg > 0 ? volume / volAvg : 1.0

    float score = 50.0
    score += htfDir * 22.0
    score += btcDir * 10.0
    score += vwapDir * 8.0
    if volRatio > 1.2
        score += close >= open ? 5.0 : -5.0

    ContextState.new(f_clamp(score, 0.0, 100.0), btcAlign, htfDir != 0, htfDir, (close - snap.vwap) / (snap.vwap + 1e-10) * 100.0, volRatio)

f_quant_engine(MarketSnapshot snap, float rsiVal, float zScoreVal, float atrSMA20Val) =>
    float volExp = snap.atr / (atrSMA20Val + 1e-10) * 100.0
    float slope = f_linreg_slope(close, 20)
    float slopeNorm = f_clamp(slope / (snap.atr + 1e-10) * 50.0, -30.0, 30.0)
    float meanRev = math.abs(zScoreVal)

    float sumDir = 0.0
    for i = 0 to 9
        sumDir += nz(close[i], close) > nz(close[i + 1], close) ? 1.0 : -1.0

    float trendPers = 50.0 + sumDir / 10.0 * 50.0

    float path = 0.0
    for i = 1 to 20
        path += math.abs(nz(close[i - 1], close) - nz(close[i], close))

    float netMove = math.abs(close - nz(close[20], close))
    float eff = path > 0 ? netMove / path * 100.0 : 0.0

    float score = 50.0
    score += (rsiVal - 50.0) * 0.45
    score += f_clamp(zScoreVal * 8.0, -20.0, 20.0)
    score += slopeNorm * 0.60
    score += (trendPers - 50.0) * 0.25
    if meanRev > i_meanRevThresh
        score += zScoreVal > 0 ? -8.0 : 8.0

    QuantState.new(f_clamp(score, 0.0, 100.0), zScoreVal, rsiVal, volExp, slope, meanRev, trendPers, eff)

f_confluence_engine(RegimeState reg, StructureState st, LiquidityState liq, ContextState ctx, QuantState q) =>
    float wS = i_wStructure
    float wL = i_wLiquidity
    float wQ = i_wQuant
    float wC = i_wContext
    float wR = i_wRegime

    if reg.regimeType == "STRONG_TREND" or reg.regimeType == "WEAK_TREND"
        wS *= 1.35
        wQ *= 1.15
        wL *= 0.85
    else if reg.regimeType == "RANGE"
        wL *= 1.35
        wQ *= 1.20
        wS *= 0.85
    else if reg.regimeType == "EXPANSION"
        wS *= 1.25
        wC *= 1.15
    else if reg.regimeType == "COMPRESSION"
        wC *= 1.20
        wR *= 1.10

    if i_adaptLearning
        wS *= adaptStructWeight
        wL *= adaptLiquWeight
        wQ *= adaptQuantWeight
        wC *= adaptContextWeight
        wR *= adaptRegimeWeight

    float total = wS + wL + wQ + wC + wR
    total := total == 0 ? 1.0 : total

    wS /= total
    wL /= total
    wQ /= total
    wC /= total
    wR /= total

    float longScore = st.score * wS + liq.score * wL + q.score * wQ + ctx.score * wC + reg.regimeScore * wR
    float shortScore = (100.0 - st.score) * wS + (100.0 - liq.score) * wL + (100.0 - q.score) * wQ + (100.0 - ctx.score) * wC + (100.0 - reg.regimeScore) * wR

    int la = 0
    int sa = 0
    la += st.score > 55 ? 1 : 0
    la += liq.score > 55 ? 1 : 0
    la += q.score > 55 ? 1 : 0
    la += ctx.score > 55 ? 1 : 0
    la += reg.regimeScore > 55 ? 1 : 0

    sa += st.score < 45 ? 1 : 0
    sa += liq.score < 45 ? 1 : 0
    sa += q.score < 45 ? 1 : 0
    sa += ctx.score < 45 ? 1 : 0
    sa += reg.regimeScore < 45 ? 1 : 0

    float agreement = math.max(la, sa) / 5.0 * 100.0
    ConfluenceState.new(f_clamp(longScore, 0.0, 100.0), f_clamp(shortScore, 0.0, 100.0), (longScore + shortScore) / 2.0, agreement)

f_mtf_alignment(float htf1C, float htf1E, float htf2C, float htf2E, float htf3C, float htf3E) =>
    int bullVotes = 0
    int bearVotes = 0
    bullVotes += not na(htf1C) and not na(htf1E) and htf1C > htf1E ? 1 : 0
    bullVotes += not na(htf2C) and not na(htf2E) and htf2C > htf2E ? 1 : 0
    bullVotes += not na(htf3C) and not na(htf3E) and htf3C > htf3E ? 1 : 0
    bearVotes += not na(htf1C) and not na(htf1E) and htf1C < htf1E ? 1 : 0
    bearVotes += not na(htf2C) and not na(htf2E) and htf2C < htf2E ? 1 : 0
    bearVotes += not na(htf3C) and not na(htf3E) and htf3C < htf3E ? 1 : 0
    bullVotes >= 2 ? 1 : bearVotes >= 2 ? -1 : 0

f_probability_engine(RegimeState reg, StructureState st, LiquidityState liq, ContextState ctx, QuantState q, ConfluenceState conf, MarketSnapshot snap) =>
    bool isTrend = reg.regimeType == "STRONG_TREND" or reg.regimeType == "WEAK_TREND"
    float relStruct = isTrend ? 0.92 : 0.70
    float relQuant  = isTrend ? 0.85 : 0.78
    float relLiqu   = isTrend ? 0.72 : 0.88
    float relCtx    = 0.78
    float relReg    = 0.82

    float dirLong = (st.score / 100.0) * relStruct * 0.26 + (liq.score / 100.0) * relLiqu * 0.20 + (q.score / 100.0) * relQuant * 0.20 + (ctx.score / 100.0) * relCtx * 0.16 + (reg.regimeScore / 100.0) * relReg * 0.18
    float dirShort = ((100.0 - st.score) / 100.0) * relStruct * 0.26 + ((100.0 - liq.score) / 100.0) * relLiqu * 0.20 + ((100.0 - q.score) / 100.0) * relQuant * 0.20 + ((100.0 - ctx.score) / 100.0) * relCtx * 0.16 + ((100.0 - reg.regimeScore) / 100.0) * relReg * 0.18

    float longRaw = dirLong * 0.55 + (conf.longScore / 100.0) * 0.45
    float shortRaw = dirShort * 0.55 + (conf.shortScore / 100.0) * 0.45

    if st.bosBull or st.chochBull or st.mssBull
        longRaw *= 1.10
        shortRaw *= 0.92
    if st.bosBear or st.chochBear or st.mssBear
        shortRaw *= 1.10
        longRaw *= 0.92
    if liq.sweepBull
        longRaw *= 1.08
        shortRaw *= 0.94
    if liq.sweepBear
        shortRaw *= 1.08
        longRaw *= 0.94

    float neutralRaw = f_clamp((100.0 - conf.agreement) / 100.0 * 0.12, 0.0, 0.12)
    longRaw := f_clamp(longRaw, 0.0, 1.0)
    shortRaw := f_clamp(shortRaw, 0.0, 1.0)

    float sum = longRaw + shortRaw + neutralRaw
    sum := sum <= 0 ? 1.0 : sum

    float longProb = longRaw / sum
    float shortProb = shortRaw / sum
    float neutralProb = neutralRaw / sum
    float confidence = math.abs(longProb - shortProb) * 100.0
    float regimeFactor = reg.regimeType == "EXPANSION" ? 1.5 : reg.regimeType == "COMPRESSION" ? 0.8 : 1.0
    float expectedMove = snap.atr * (snap.volatility / 100.0 + 1.0) * regimeFactor

    ProbabilityState.new(longProb, shortProb, neutralProb, confidence, expectedMove)

f_ranking_engine(ProbabilityState prob, ConfluenceState conf, StructureState st, LiquidityState liq, ContextState ctx, QuantState q, MarketSnapshot snap, RegimeState reg) =>
    int dir = prob.longProb >= prob.shortProb ? 1 : -1
    float directionalProb = math.max(prob.longProb, prob.shortProb) * 100.0
    float directionalConf = dir == 1 ? conf.longScore : conf.shortScore
    float stopDist = snap.atr * i_slAtrMult
    float expRR = stopDist > 0 ? prob.expectedMove / stopDist : 0.0

    float remAfterTp1 = math.max(0.0, 100.0 - i_tp1Pct)
    float remAfterTp2 = math.max(0.0, remAfterTp1 - i_tp2Pct)
    float tp3Pct = remAfterTp2 * 0.50
    float tp4Pct = remAfterTp2 - tp3Pct
    float planRR = i_tp1R * i_tp1Pct / 100.0 + i_tp2R * i_tp2Pct / 100.0 + i_tp3R * tp3Pct / 100.0 + i_tp4R * tp4Pct / 100.0
    float rr = math.max(expRR, planRR)

    float structQual = dir == 1 ? f_clamp((st.score - 50.0) / 30.0, 0.0, 1.0) : f_clamp((50.0 - st.score) / 30.0, 0.0, 1.0)
    float liqQual = dir == 1 ? f_clamp((liq.score - 50.0) / 30.0, 0.0, 1.0) : f_clamp((50.0 - liq.score) / 30.0, 0.0, 1.0)
    float ctxQual = dir == 1 ? f_clamp((ctx.score - 50.0) / 35.0, 0.0, 1.0) : f_clamp((50.0 - ctx.score) / 35.0, 0.0, 1.0)
    float quantQual = dir == 1 ? f_clamp((q.score - 50.0) / 35.0, 0.0, 1.0) : f_clamp((50.0 - q.score) / 35.0, 0.0, 1.0)

    if dir == 1 and (st.bosBull or st.chochBull or st.mssBull)
        structQual := math.max(structQual, 0.85)
    if dir == -1 and (st.bosBear or st.chochBear or st.mssBear)
        structQual := math.max(structQual, 0.85)
    if dir == 1 and liq.sweepBull
        liqQual := math.max(liqQual, 0.90)
    if dir == -1 and liq.sweepBear
        liqQual := math.max(liqQual, 0.90)

    float score = directionalProb * 0.35 + directionalConf * 0.25 + rr * 8.0 + structQual * 12.0 + liqQual * 8.0 + ctxQual * 8.0 + quantQual * 4.0
    score := f_clamp(score, 0.0, 100.0)

    string rank = "REJECT"
    if score >= 86.0 and rr >= 2.5 and directionalProb >= 66.0
        rank := "A+"
    else if score >= 76.0 and rr >= 2.0 and directionalProb >= 62.0
        rank := "A"
    else if score >= 64.0 and rr >= 1.5 and directionalProb >= 58.0
        rank := "B"
    else if score >= 52.0 and rr >= 1.1
        rank := "C"
    else if score >= 42.0
        rank := "D"

    string setup = "REJECT"
    if rank != "REJECT" and rank != "D"
        if (liq.sweepBull and dir == 1) or (liq.sweepBear and dir == -1)
            setup := "LIQUIDITY_REVERSAL"
        else if reg.regimeType == "EXPANSION"
            setup := "BREAKOUT_EXPANSION"
        else if reg.regimeType == "STRONG_TREND" or reg.regimeType == "WEAK_TREND"
            setup := "TREND_CONTINUATION"
        else if math.abs(q.zscore) > i_meanRevThresh
            setup := "MEAN_REVERSION"
        else
            setup := "CONFLUENCE_CONTINUATION"

    [rank, rr, setup, directionalProb, structQual, liqQual, score]

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: EXECUTION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

f_stop_loss_calc(int dir, float entry, float atr, float swingHigh, float swingLow) =>
    float atrStop = atr * i_slAtrMult
    float sl = dir == 1 ? entry - atrStop : entry + atrStop
    if dir == 1 and not na(swingLow) and swingLow < entry and (entry - swingLow) < atrStop * 2.0
        sl := math.min(sl, swingLow - atr * 0.2)
    if dir == -1 and not na(swingHigh) and swingHigh > entry and (swingHigh - entry) < atrStop * 2.0
        sl := math.max(sl, swingHigh + atr * 0.2)
    sl

f_position_size(string rank, float entry, float sl, float baseRiskPct, float currentEquity, float winRate, float profitFactor) =>
    float riskPct = baseRiskPct
    if winRate > 0 and profitFactor > 0
        float wr = winRate / 100.0
        float kelly = wr - ((1.0 - wr) / (profitFactor + 1e-10))
        float fractionalKelly = kelly * 0.25
        if fractionalKelly > 0
            riskPct := f_clamp(fractionalKelly * 100.0, 0.25, 3.0)

    float riskAmount = currentEquity * riskPct / 100.0
    float stopDist = math.abs(entry - sl)
    float size = stopDist > 0 ? riskAmount / stopDist : 0.0
    float rankMult = rank == "A+" ? 1.2 : rank == "A" ? 1.0 : rank == "B" ? 0.75 : rank == "C" ? 0.50 : 0.0
    size *= rankMult
    float maxSize = currentEquity * 3.0 / (entry + 1e-10)
    math.min(size, maxSize)

f_execution_engine(bool longCond, bool shortCond, string rank, string setup, MarketSnapshot snap, float swingHigh, float swingLow, TradeState trade, float currentEquity, float slippagePct, float winRate, float profitFactor) =>
    float closedTradePnl = na
    float slipFactor = slippagePct / 100.0

    if not trade.active
        if longCond
            float entry = open
            float sl = f_stop_loss_calc(1, entry, snap.atr, swingHigh, swingLow)
            float size = f_position_size(rank, entry, sl, i_riskPerTrade, currentEquity, winRate, profitFactor)
            float risk = math.abs(entry - sl)

            trade.active := true
            trade.direction := 1
            trade.rank := rank
            trade.setupType := setup
            trade.entryPrice := entry
            trade.stopLoss := sl
            trade.tp1 := entry + risk * i_tp1R
            trade.tp2 := entry + risk * i_tp2R
            trade.tp3 := entry + risk * i_tp3R
            trade.tp4 := entry + risk * i_tp4R
            trade.posSize := size
            trade.currentQty := size
            trade.accPnL := 0.0
            trade.entryBar := bar_index
            trade.tp1Hit := false
            trade.tp2Hit := false
            trade.breakevenActive := false
            trade.trailActive := false
            trade.trailStop := sl

        else if shortCond
            float entry = open
            float sl = f_stop_loss_calc(-1, entry, snap.atr, swingHigh, swingLow)
            float size = f_position_size(rank, entry, sl, i_riskPerTrade, currentEquity, winRate, profitFactor)
            float risk = math.abs(entry - sl)

            trade.active := true
            trade.direction := -1
            trade.rank := rank
            trade.setupType := setup
            trade.entryPrice := entry
            trade.stopLoss := sl
            trade.tp1 := entry - risk * i_tp1R
            trade.tp2 := entry - risk * i_tp2R
            trade.tp3 := entry - risk * i_tp3R
            trade.tp4 := entry - risk * i_tp4R
            trade.posSize := size
            trade.currentQty := size
            trade.accPnL := 0.0
            trade.entryBar := bar_index
            trade.tp1Hit := false
            trade.tp2Hit := false
            trade.breakevenActive := false
            trade.trailActive := false
            trade.trailStop := sl

    else
        if trade.direction == 1
            if low <= trade.stopLoss
                float exitPrice = trade.stopLoss
                float pnl = (exitPrice - trade.entryPrice) * trade.currentQty
                float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                trade.accPnL += pnl - fee
                closedTradePnl := trade.accPnL
                trade.active := false
            else
                if not trade.tp1Hit and high >= trade.tp1
                    trade.tp1Hit := true
                    float exitQty = trade.posSize * i_tp1Pct / 100.0
                    float pnl = (trade.tp1 - trade.entryPrice) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp1 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty
                    trade.stopLoss := trade.entryPrice
                    trade.breakevenActive := true

                if not trade.tp2Hit and high >= trade.tp2 and trade.tp1Hit
                    trade.tp2Hit := true
                    float exitQty = trade.posSize * i_tp2Pct / 100.0
                    float pnl = (trade.tp2 - trade.entryPrice) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp2 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty
                    if i_trailAfterTP2
                        trade.trailActive := true
                        trade.trailStop := not na(swingLow) ? math.max(trade.stopLoss, swingLow) : trade.stopLoss

                if trade.trailActive
                    if not na(swingLow) and swingLow > trade.trailStop
                        trade.trailStop := swingLow
                    if low <= trade.trailStop
                        float exitPrice = trade.trailStop
                        float pnl = (exitPrice - trade.entryPrice) * trade.currentQty
                        float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                        trade.accPnL += pnl - fee
                        closedTradePnl := trade.accPnL
                        trade.active := false

                if trade.active and high >= trade.tp4
                    float exitPrice = trade.tp4
                    float pnl = (exitPrice - trade.entryPrice) * trade.currentQty
                    float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                    trade.accPnL += pnl - fee
                    closedTradePnl := trade.accPnL
                    trade.active := false
                else if trade.active and high >= trade.tp3 and trade.currentQty > trade.posSize * 0.2
                    float exitQty = trade.currentQty * 0.5
                    float pnl = (trade.tp3 - trade.entryPrice) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp3 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty

        else
            if high >= trade.stopLoss
                float exitPrice = trade.stopLoss
                float pnl = (trade.entryPrice - exitPrice) * trade.currentQty
                float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                trade.accPnL += pnl - fee
                closedTradePnl := trade.accPnL
                trade.active := false
            else
                if not trade.tp1Hit and low <= trade.tp1
                    trade.tp1Hit := true
                    float exitQty = trade.posSize * i_tp1Pct / 100.0
                    float pnl = (trade.entryPrice - trade.tp1) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp1 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty
                    trade.stopLoss := trade.entryPrice
                    trade.breakevenActive := true

                if not trade.tp2Hit and low <= trade.tp2 and trade.tp1Hit
                    trade.tp2Hit := true
                    float exitQty = trade.posSize * i_tp2Pct / 100.0
                    float pnl = (trade.entryPrice - trade.tp2) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp2 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty
                    if i_trailAfterTP2
                        trade.trailActive := true
                        trade.trailStop := not na(swingHigh) ? math.min(trade.stopLoss, swingHigh) : trade.stopLoss

                if trade.trailActive
                    if not na(swingHigh) and swingHigh < trade.trailStop
                        trade.trailStop := swingHigh
                    if high >= trade.trailStop
                        float exitPrice = trade.trailStop
                        float pnl = (trade.entryPrice - exitPrice) * trade.currentQty
                        float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                        trade.accPnL += pnl - fee
                        closedTradePnl := trade.accPnL
                        trade.active := false

                if trade.active and low <= trade.tp4
                    float exitPrice = trade.tp4
                    float pnl = (trade.entryPrice - exitPrice) * trade.currentQty
                    float fee = (trade.entryPrice * trade.currentQty + exitPrice * trade.currentQty) * slipFactor
                    trade.accPnL += pnl - fee
                    closedTradePnl := trade.accPnL
                    trade.active := false
                else if trade.active and low <= trade.tp3 and trade.currentQty > trade.posSize * 0.2
                    float exitQty = trade.currentQty * 0.5
                    float pnl = (trade.entryPrice - trade.tp3) * exitQty
                    float fee = (trade.entryPrice * exitQty + trade.tp3 * exitQty) * slipFactor
                    trade.accPnL += pnl - fee
                    trade.currentQty -= exitQty

    closedTradePnl

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: ANALYTICS / DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════

f_monte_carlo_drawdown_prob(float winRate, float avgWin, float avgLoss, int consecutiveLossLimit) =>
    float p = f_clamp(winRate / 100.0, 0.0, 1.0)
    float q = 1.0 - p
    int n = 100
    float probConsecRun = 1.0 - math.pow(1.0 - math.pow(q, consecutiveLossLimit), n / consecutiveLossLimit)
    f_clamp(probConsecRun * 100.0, 0.0, 100.0)

f_draw_dashboard(RegimeState reg, StructureState st, LiquidityState liq, ContextState ctx, QuantState q, ConfluenceState conf, ProbabilityState prob, string rankVal, string setupVal, float rrVal, float scoreVal, float structQualVal, float liqQualVal, float winRateVal, float profitFactorVal, float netProfitVal, float maxDDVal, float expectancyVal, float avgWinVal, float avgLossVal, float sharpeVal, int totalTradesVal, bool killSwitchActive, float mcRisk, float rollingWR, float rollingPFVal) =>
    var table dash = table.new(f_table_pos(i_dbPos), 5, 20, bgcolor=C_DB_BG, border_color=C_GRID, border_width=1)

    if i_showTable and i_showDashboard and barstate.islast
        table.merge_cells(dash, 0, 0, 4, 0)
        table.cell(dash, 0, 0, "OMEGA-X BTC SYSTEM DASHBOARD", bgcolor=C_PANEL, text_color=C_TEXT, text_size=size.small, text_halign=text.align_center)

        color regColor = reg.direction == 1 ? C_BULL : reg.direction == -1 ? C_BEAR : C_GOLD
        table.cell(dash, 0, 1, "REGIME", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 1, reg.regimeType, text_color=regColor, text_size=size.tiny)
        table.cell(dash, 2, 1, "Conf", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 1, str.tostring(math.round(reg.confidence)) + "%", text_color=C_TEXT, text_size=size.tiny)

        string structText = st.bosBull ? "BOS BULL" : st.bosBear ? "BOS BEAR" : st.chochBull ? "CHoCH BULL" : st.chochBear ? "CHoCH BEAR" : "NEUTRAL"
        table.cell(dash, 0, 2, "STRUCTURE", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 2, structText, text_color=st.score > 55 ? C_BULL : st.score < 45 ? C_BEAR : C_MUTED, text_size=size.tiny)
        table.cell(dash, 2, 2, "Score", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 2, str.tostring(math.round(st.score)), text_color=C_TEXT, text_size=size.tiny)

        string liqText = liq.sweepBull ? "SWEEP ▲" : liq.sweepBear ? "SWEEP ▼" : "STABLE"
        table.cell(dash, 0, 3, "LIQUIDITY", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 3, liqText, text_color=liq.score > 55 ? C_BULL : liq.score < 45 ? C_BEAR : C_MUTED, text_size=size.tiny)
        table.cell(dash, 2, 3, "Score", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 3, str.tostring(math.round(liq.score)), text_color=C_TEXT, text_size=size.tiny)

        table.cell(dash, 0, 4, "QUANT", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 4, "Z " + str.tostring(q.zscore, "0.00"), text_color=C_TEXT, text_size=size.tiny)
        table.cell(dash, 2, 4, "Score", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 4, str.tostring(math.round(q.score)), text_color=q.score > 55 ? C_BULL : q.score < 45 ? C_BEAR : C_TEXT, text_size=size.tiny)

        table.cell(dash, 0, 5, "CONTEXT", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 5, ctx.htfDirection == 1 ? "HTF BULL" : ctx.htfDirection == -1 ? "HTF BEAR" : "MIXED", text_color=ctx.htfDirection == 1 ? C_BULL : ctx.htfDirection == -1 ? C_BEAR : C_GOLD, text_size=size.tiny)
        table.cell(dash, 2, 5, "Score", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 5, str.tostring(math.round(ctx.score)), text_color=ctx.score > 55 ? C_BULL : ctx.score < 45 ? C_BEAR : C_TEXT, text_size=size.tiny)

        table.cell(dash, 0, 6, "CONFLUENCE", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 6, "L " + str.tostring(math.round(conf.longScore)) + "%", text_color=C_BULL, text_size=size.tiny)
        table.cell(dash, 2, 6, "S " + str.tostring(math.round(conf.shortScore)) + "%", text_color=C_BEAR, text_size=size.tiny)
        table.cell(dash, 3, 6, "Agr " + str.tostring(math.round(conf.agreement)) + "%", text_color=C_GOLD, text_size=size.tiny)

        table.cell(dash, 0, 7, "PROBABILITY", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 7, "L " + str.tostring(math.round(prob.longProb * 100)) + "%", text_color=C_BULL, text_size=size.tiny)
        table.cell(dash, 2, 7, "S " + str.tostring(math.round(prob.shortProb * 100)) + "%", text_color=C_BEAR, text_size=size.tiny)
        table.cell(dash, 3, 7, "Conf " + str.tostring(math.round(prob.confidence)) + "%", text_color=C_GOLD, text_size=size.tiny)

        color rankColor = rankVal == "A+" ? C_BULL : rankVal == "A" ? C_CYAN : rankVal == "B" ? C_GOLD : rankVal == "C" ? color.rgb(251, 146, 60) : C_BEAR
        table.cell(dash, 0, 8, "RANK / SETUP", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 8, rankVal, text_color=rankColor, text_size=size.tiny)
        table.cell(dash, 2, 8, "Setup", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 8, setupVal, text_color=C_TEXT, text_size=size.tiny)

        table.cell(dash, 0, 9, "RISK / RR", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 9, "SQ " + str.tostring(math.round(structQualVal * 100)) + "%", text_color=C_TEXT, text_size=size.tiny)
        table.cell(dash, 2, 9, "LQ " + str.tostring(math.round(liqQualVal * 100)) + "%", text_color=C_TEXT, text_size=size.tiny)
        table.cell(dash, 3, 9, "RR " + str.tostring(rrVal, "0.00"), text_color=C_GOLD, text_size=size.tiny)

        table.cell(dash, 0, 10, "TRADE STATUS", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 10, activeTrade.active ? "ACTIVE" : "IDLE", text_color=activeTrade.active ? C_BULL : C_MUTED, text_size=size.tiny)
        table.cell(dash, 2, 10, "Kill", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 10, killSwitchActive ? "ON" : "OFF", text_color=killSwitchActive ? C_BEAR : C_BULL, text_size=size.tiny)

        table.merge_cells(dash, 0, 11, 4, 11)
        table.cell(dash, 0, 11, "PERFORMANCE STATISTICS", bgcolor=C_PANEL, text_color=C_TEXT, text_size=size.tiny, text_halign=text.align_center)

        table.cell(dash, 0, 12, "Win Rate", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 12, str.tostring(math.round(winRateVal)) + "%", text_color=winRateVal >= 50 ? C_BULL : C_BEAR, text_size=size.tiny)
        table.cell(dash, 2, 12, "PF", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 12, str.tostring(profitFactorVal, "0.00"), text_color=profitFactorVal >= 1.5 ? C_BULL : C_BEAR, text_size=size.tiny)

        table.cell(dash, 0, 13, "Net Profit", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 13, str.tostring(netProfitVal, "0.00") + " " + i_baseCurrency, text_color=netProfitVal >= 0 ? C_BULL : C_BEAR, text_size=size.tiny)
        table.cell(dash, 2, 13, "Max DD", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 13, str.tostring(maxDDVal, "0.00") + "%", text_color=maxDDVal < 15 ? C_BULL : C_BEAR, text_size=size.tiny)

        table.cell(dash, 0, 14, "Avg W/L", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 14, str.tostring(avgWinVal, "0.0") + "/" + str.tostring(avgLossVal, "0.0"), text_color=C_TEXT, text_size=size.tiny)
        table.cell(dash, 2, 14, "Expect", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 14, str.tostring(expectancyVal, "0.00"), text_color=expectancyVal > 0 ? C_BULL : C_BEAR, text_size=size.tiny)

        table.merge_cells(dash, 0, 15, 4, 15)
        table.cell(dash, 0, 15, "ROLLING L30 / MONTE CARLO / ADAPTIVE", bgcolor=C_PANEL, text_color=C_TEXT, text_size=size.tiny, text_halign=text.align_center)

        table.cell(dash, 0, 16, "Roll WR", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 16, str.tostring(math.round(rollingWR)) + "%", text_color=rollingWR >= 50 ? C_BULL : C_BEAR, text_size=size.tiny)
        table.cell(dash, 2, 16, "Roll PF", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 16, str.tostring(rollingPFVal, "0.00"), text_color=rollingPFVal >= 1.5 ? C_BULL : C_BEAR, text_size=size.tiny)

        table.cell(dash, 0, 17, "MC Risk", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 17, str.tostring(mcRisk, "0.0") + "%", text_color=mcRisk < 20 ? C_BULL : C_BEAR, text_size=size.tiny)
        table.cell(dash, 2, 17, "Trades", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 3, 17, str.tostring(totalTradesVal), text_color=C_TEXT, text_size=size.tiny)

        table.cell(dash, 0, 18, "ADAPT", text_color=C_MUTED, text_size=size.tiny)
        table.cell(dash, 1, 18, "S " + str.tostring(adaptStructWeight, "0.00"), text_color=C_CYAN, text_size=size.tiny)
        table.cell(dash, 2, 18, "L " + str.tostring(adaptLiquWeight, "0.00"), text_color=C_CYAN, text_size=size.tiny)
        table.cell(dash, 3, 18, "Q " + str.tostring(adaptQuantWeight, "0.00"), text_color=C_CYAN, text_size=size.tiny)
        table.cell(dash, 4, 18, "C " + str.tostring(adaptContextWeight, "0.00"), text_color=C_CYAN, text_size=size.tiny)

        table.merge_cells(dash, 0, 19, 4, 19)
        table.cell(dash, 0, 19, syminfo.ticker + " | " + timeframe.period + " | Non-Repaint Close Confirmed", text_color=C_MUTED, text_size=size.tiny, text_halign=text.align_center)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 8: CORE CALCULATION LOOP
// ═══════════════════════════════════════════════════════════════════════════

float htf1Close = f_mtf_close(i_htf1)
float htf1Ema   = f_mtf_ema(i_htf1, 50)
float htf2Close = f_mtf_close(i_htf2)
float htf2Ema   = f_mtf_ema(i_htf2, 50)
float htf3Close = f_mtf_close(i_htf3)
float htf3Ema   = f_mtf_ema(i_htf3, 200)

float ph = ta.pivothigh(high, i_swingLen, i_swingLen)
float pl = ta.pivotlow(low, i_swingLen, i_swingLen)

MarketSnapshot snap = f_market_snapshot(cached_atr_14, cached_atr_50, cached_vwap)
RegimeState regime = f_regime_engine(snap, main_adx, cached_ema_50, cached_ema_200)
StructureState structure = f_structure_engine(ph, pl, htf1Close, htf1Ema)

int mtfAlignment = f_mtf_alignment(htf1Close, htf1Ema, htf2Close, htf2Ema, htf3Close, htf3Ema)

float volDelta = f_volume_delta()
float absVolDeltaSMA = ta.sma(math.abs(volDelta), 20)
LiquidityState liquidity = f_liquidity_engine(ph, pl, snap.atr, swingHighs, swingLows, volDelta, absVolDeltaSMA)

[obFvgScore, updatedZoneCounter] = f_ob_fvg_engine(snap.atr, activeZones, C_BULL, C_BEAR, zoneCounter, liquidity.sweepBull, liquidity.sweepBear)
zoneCounter := updatedZoneCounter

float btcClose = request.security("BINANCE:BTCUSDT", timeframe.period, close[1], barmerge.gaps_off, barmerge.lookahead_off)
float btcEma   = request.security("BINANCE:BTCUSDT", timeframe.period, ta.ema(close, 200)[1], barmerge.gaps_off, barmerge.lookahead_off)

ContextState context = f_context_engine(snap, htf1Close, htf1Ema, htf2Close, htf2Ema, htf3Close, htf3Ema, btcClose, btcEma)

float atrSMA20 = ta.sma(cached_atr_14, 20)
QuantState quant = f_quant_engine(snap, main_rsi, main_zscore, atrSMA20)

float structScore = structure.score
if not na(obFvgScore)
    structScore := structure.score == 50.0 ? (structure.score * 0.55 + obFvgScore * 0.45) : (structure.score * 0.75 + obFvgScore * 0.25)
structure.score := f_clamp(structScore, 0.0, 100.0)

ConfluenceState confluence = f_confluence_engine(regime, structure, liquidity, context, quant)
ProbabilityState probability = f_probability_engine(regime, structure, liquidity, context, quant, confluence, snap)

[rank, rr, setup, probVal, structQual, liqQual, score] = f_ranking_engine(probability, confluence, structure, liquidity, context, quant, snap, regime)

float swingHigh = array.size(swingHighs) > 0 ? array.get(swingHighs, 0) : na
float swingLow  = array.size(swingLows) > 0 ? array.get(swingLows, 0) : na

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 9: SIGNALS
// ═══════════════════════════════════════════════════════════════════════════

bool rankTradable = rank == "A+" or rank == "A" or rank == "B" or rank == "C"

bool longSignal = barstate.isconfirmed and probability.longProb > probability.shortProb and probability.longProb >= i_minProb / 100.0 and confluence.longScore >= i_minLongScore and confluence.longScore > confluence.shortScore + i_scoreDiff and rankTradable and setup != "REJECT" and not killActive and not activeTrade.active and mtfAlignment == 1
bool shortSignal = barstate.isconfirmed and probability.shortProb > probability.longProb and probability.shortProb >= i_minProb / 100.0 and confluence.shortScore >= i_minShortScore and confluence.shortScore > confluence.longScore + i_scoreDiff and rankTradable and setup != "REJECT" and not killActive and not activeTrade.active and mtfAlignment == -1

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 10: EXECUTION + PERFORMANCE (MODIFIED FOR NEXT-BAR OPEN ENTRY)
// ═══════════════════════════════════════════════════════════════════════════

var float globalWinRate = 0.0
var float globalProfitFactor = 0.0
var float globalNetProfit = 0.0
var float globalMaxDD = 0.0
var float globalExpectancy = 0.0
var float globalAvgWin = 0.0
var float globalAvgLoss = 0.0
var float globalSharpe = 0.0
var int globalTotalTrades = 0
var float rollingWinRate = 0.0
var float rollingPF = 0.0
var float mcProb = 0.0

float tradePnl = na

// معامله همواره روی کندل بعد از تایید سیگنال انجام می‌شود (Next Bar Open Entry)
bool execLong  = longSignal[1] and not activeTrade.active
bool execShort = shortSignal[1] and not activeTrade.active

if i_enableBacktest
    tradePnl := f_execution_engine(execLong, execShort, rank, setup, snap, swingHigh, swingLow, activeTrade, virtualEquity, i_slippagePct, globalWinRate, globalProfitFactor)

if killActive and bar_index >= killSwitchBar
    killActive := false
    consecutiveLosses := 0

if not na(tradePnl)
    virtualEquity += tradePnl
    bool isWin = tradePnl > 0.0

    HistoricalTrade ht = HistoricalTrade.new(regime.regimeType, setup, rank, isWin, tradePnl, activeTrade.entryPrice, close, rr)
    array.unshift(tradeHistory, ht)

    if array.size(tradeHistory) > 500
        array.pop(tradeHistory)

    if i_adaptLearning and array.size(tradeHistory) >= 10
        float structWin = 0.0
        float structTotal = 0.0
        float liqWin = 0.0
        float liqTotal = 0.0
        float quantWin = 0.0
        float quantTotal = 0.0
        float regimeWin = 0.0
        float regimeTotal = 0.0

        int histLim = math.min(array.size(tradeHistory) - 1, 99)
        for i = 0 to histLim
            HistoricalTrade t = array.get(tradeHistory, i)

            if t.setupType == "TREND_CONTINUATION" or t.setupType == "BREAKOUT_EXPANSION" or t.setupType == "CONFLUENCE_CONTINUATION"
                structTotal += 1.0
                if t.isWin
                    structWin += 1.0

            if t.setupType == "LIQUIDITY_REVERSAL"
                liqTotal += 1.0
                if t.isWin
                    liqWin += 1.0

            if t.setupType == "MEAN_REVERSION"
                quantTotal += 1.0
                if t.isWin
                    quantWin += 1.0

            if t.regime == regime.regimeType
                regimeTotal += 1.0
                if t.isWin
                    regimeWin += 1.0

        float structRate = structTotal >= 3 ? structWin / structTotal : 0.5
        float liqRate = liqTotal >= 3 ? liqWin / liqTotal : 0.5
        float quantRate = quantTotal >= 3 ? quantWin / quantTotal : 0.5
        float regRate = regimeTotal >= 3 ? regimeWin / regimeTotal : 0.5

        adaptStructWeight := f_clamp(0.8 + structRate * 0.4, 0.6, 1.4)
        adaptLiquWeight := f_clamp(0.8 + liqRate * 0.4, 0.6, 1.4)
        adaptQuantWeight := f_clamp(0.8 + quantRate * 0.4, 0.6, 1.4)
        adaptRegimeWeight := f_clamp(0.8 + regRate * 0.4, 0.6, 1.4)

    if isWin
        consecutiveLosses := 0
    else
        consecutiveLosses += 1

    if consecutiveLosses >= i_maxConsecLoss and not killActive
        killActive := true
        killSwitchBar := bar_index + i_cooldownBars
        alert("OMEGA-X Risk Engine Halt: Maximum consecutive losses circuit breaker activated.", alert.freq_once_per_bar_close)

if virtualEquity > peakEquity
    peakEquity := virtualEquity

float currentDD = peakEquity > 0 ? (peakEquity - virtualEquity) / peakEquity * 100.0 : 0.0

if currentDD > maxDrawdown
    maxDrawdown := currentDD

if array.size(tradeHistory) > 0
    float totalProfit = 0.0
    int wins = 0
    float winSum = 0.0
    float lossSum = 0.0

    int rollWindowSize = math.min(array.size(tradeHistory), 30)
    float rollWinSum = 0.0
    float rollLossSum = 0.0
    int rollWins = 0

    for i = 0 to array.size(tradeHistory) - 1
        HistoricalTrade t = array.get(tradeHistory, i)
        totalProfit += t.pnl

        if t.isWin
            wins += 1
            winSum += t.pnl
        else
            lossSum += math.abs(t.pnl)

        if i < rollWindowSize
            if t.isWin
                rollWins += 1
                rollWinSum += t.pnl
            else
                rollLossSum += math.abs(t.pnl)

    int totalTrades = array.size(tradeHistory)
    int losses = totalTrades - wins

    globalWinRate := wins / float(totalTrades) * 100.0
    globalProfitFactor := lossSum > 0 ? winSum / lossSum : wins > 0 ? 999.0 : 0.0
    globalNetProfit := totalProfit
    globalMaxDD := maxDrawdown
    globalAvgWin := wins > 0 ? winSum / wins : 0.0
    globalAvgLoss := losses > 0 ? lossSum / losses : 0.0
    globalExpectancy := (globalWinRate / 100.0) * globalAvgWin - (1.0 - globalWinRate / 100.0) * globalAvgLoss

    rollingWinRate := rollWindowSize > 0 ? rollWins / float(rollWindowSize) * 100.0 : 0.0
    rollingPF := rollLossSum > 0 ? rollWinSum / rollLossSum : rollWins > 0 ? 999.0 : 0.0
    mcProb := f_monte_carlo_drawdown_prob(rollingWinRate, globalAvgWin, globalAvgLoss, i_maxConsecLoss)

    globalSharpe := 0.0
    if totalTrades > 1
        float meanPnl = totalProfit / totalTrades
        float sqSum = 0.0
        for i = 0 to totalTrades - 1
            sqSum += math.pow(array.get(tradeHistory, i).pnl - meanPnl, 2)
        float std = math.sqrt(sqSum / (totalTrades - 1))
        globalSharpe := std > 0 ? meanPnl / std : 0.0

    globalTotalTrades := totalTrades

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 11: VISUALS (MODIFIED TO SUPPORT NEXT-BAR OFFSET FOR SNIPER VISUALS)
// ═══════════════════════════════════════════════════════════════════════════

if i_showSignals and longSignal
    if i_showPaneLabels
        int alignedCount = 0
        alignedCount += structure.score > 50 ? 1 : 0
        alignedCount += liquidity.score > 50 ? 1 : 0
        alignedCount += quant.score > 50 ? 1 : 0
        alignedCount += context.score > 50 ? 1 : 0
        alignedCount += regime.regimeScore > 50 ? 1 : 0

        string txt = rank + " | " + setup + "\n" + "Prob: " + str.tostring(probability.longProb * 100, "0.0") + "% | Conf: " + str.tostring(confluence.longScore, "0.0") + "%\n" + "RR: " + str.tostring(rr, "0.00") + " | Align: " + str.tostring(alignedCount) + "/5"
        label lbl = label.new(bar_index, low - snap.atr * 0.85, txt, color=C_BULL_DARK, textcolor=C_TEXT, style=label.style_label_up, size=size.tiny)
        f_push_label(signalLabels, lbl, MAX_SIGNAL_LABELS)

// زمان اجرای معامله خرید (کندل بعد از سیگنال): گرافیک اسنایپر روی کندل ورود ترسیم می‌شود
if i_showRiskVisuals and execLong
    float entry = open
    float sl = f_stop_loss_calc(1, entry, snap.atr, swingHigh, swingLow)
    float risk = math.abs(entry - sl)
    float tp1 = entry + risk * i_tp1R
    float tp2 = entry + risk * i_tp2R
    float tp3 = entry + risk * i_tp3R
    float tp4 = entry + risk * i_tp4R
    array.push(activeVisuals, f_create_visual(bar_index, 1, entry, sl, tp1, tp2, tp3, tp4))

if i_showSignals and shortSignal
    if i_showPaneLabels
        int alignedCount = 0
        alignedCount += structure.score < 50 ? 1 : 0
        alignedCount += liquidity.score < 50 ? 1 : 0
        alignedCount += quant.score < 50 ? 1 : 0
        alignedCount += context.score < 50 ? 1 : 0
        alignedCount += regime.regimeScore < 50 ? 1 : 0

        string txt = rank + " | " + setup + "\n" + "Prob: " + str.tostring(probability.shortProb * 100, "0.0") + "% | Conf: " + str.tostring(confluence.shortScore, "0.0") + "%\n" + "RR: " + str.tostring(rr, "0.00") + " | Align: " + str.tostring(alignedCount) + "/5"
        label lbl = label.new(bar_index, high + snap.atr * 0.85, txt, color=C_BEAR_DARK, textcolor=C_TEXT, style=label.style_label_down, size=size.tiny)
        f_push_label(signalLabels, lbl, MAX_SIGNAL_LABELS)

// زمان اجرای معامله فروش (کندل بعد از سیگنال): گرافیک اسنایپر روی کندل ورود ترسیم می‌شود
if i_showRiskVisuals and execShort
    float entry = open
    float sl = f_stop_loss_calc(-1, entry, snap.atr, swingHigh, swingLow)
    float risk = math.abs(entry - sl)
    float tp1 = entry - risk * i_tp1R
    float tp2 = entry - risk * i_tp2R
    float tp3 = entry - risk * i_tp3R
    float tp4 = entry - risk * i_tp4R
    array.push(activeVisuals, f_create_visual(bar_index, -1, entry, sl, tp1, tp2, tp3, tp4))

if i_showPaneLabels and i_showStructure and barstate.isconfirmed
    if structure.bosBull or structure.bosBear
        string bosTxt = structure.bosBull ? "BOS ▲" : "BOS ▼"
        color bg = structure.bosBull ? color.new(C_BULL_DARK, 0) : color.new(C_BEAR_DARK, 0)
        label lbl = label.new(bar_index, structure.bosBull ? high + snap.atr * 0.30 : low - snap.atr * 0.30, bosTxt, color=bg, textcolor=C_TEXT, style=structure.bosBull ? label.style_label_down : label.style_label_up, size=size.tiny)
        f_push_label(structureLabels, lbl, MAX_STRUCTURE_LABELS)

    if structure.chochBull or structure.chochBear
        string chochTxt = structure.chochBull ? "CHoCH ▲" : "CHoCH ▼"
        color bg = structure.chochBull ? color.new(C_BLUE, 10) : color.new(C_GOLD, 10)
        label lbl = label.new(bar_index, structure.chochBull ? high + snap.atr * 0.50 : low - snap.atr * 0.50, chochTxt, color=bg, textcolor=C_TEXT, style=structure.chochBull ? label.style_label_down : label.style_label_up, size=size.tiny)
        f_push_label(structureLabels, lbl, MAX_STRUCTURE_LABELS)

    if structure.mssBull or structure.mssBear
        string mssTxt = structure.mssBull ? "MSS ▲" : "MSS ▼"
        color bg = structure.mssBull ? color.new(C_CYAN, 10) : color.new(color.fuchsia, 10)
        label lbl = label.new(bar_index, structure.mssBull ? high + snap.atr * 0.70 : low - snap.atr * 0.70, mssTxt, color=bg, textcolor=C_TEXT, style=structure.mssBull ? label.style_label_down : label.style_label_up, size=size.tiny)
        f_push_label(structureLabels, lbl, MAX_STRUCTURE_LABELS)

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 11.5: SNIPER VISUAL RISK MANAGEMENT ENGINE
// ═══════════════════════════════════════════════════════════════════════════

if array.size(activeVisuals) > i_maxRiskVisuals
    TradeVisual oldest = array.shift(activeVisuals)
    line.delete(oldest.entryLine)
    line.delete(oldest.slLine)
    line.delete(oldest.tp1Line)
    line.delete(oldest.tp2Line)
    line.delete(oldest.tp3Line)
    line.delete(oldest.tp4Line)
    label.delete(oldest.entryLabel)
    label.delete(oldest.slLabel)
    label.delete(oldest.tp1Label)
    label.delete(oldest.tp2Label)
    label.delete(oldest.tp3Label)
    label.delete(oldest.tp4Label)
    box.delete(oldest.profitBox)
    box.delete(oldest.lossBox)

if array.size(activeVisuals) > 0
    for i = 0 to array.size(activeVisuals) - 1
        TradeVisual vis = array.get(activeVisuals, i)
        bool isLast = (i == array.size(activeVisuals) - 1)
        int barsPassed = bar_index - vis.entryBar
        
        bool needsUpdate = not vis.isFinalized or (not isLast and vis.endBar > vis.entryBar + 20)
        
        if needsUpdate
            if vis.direction == 1 // Long
                vis.slHit  := vis.slHit  or low <= vis.sl
                vis.tp1Hit := vis.tp1Hit or high >= vis.tp1
                vis.tp2Hit := vis.tp2Hit or high >= vis.tp2
                vis.tp3Hit := vis.tp3Hit or high >= vis.tp3
                vis.tp4Hit := vis.tp4Hit or high >= vis.tp4
            else // Short
                vis.slHit  := vis.slHit  or high >= vis.sl
                vis.tp1Hit := vis.tp1Hit or low <= vis.tp1
                vis.tp2Hit := vis.tp2Hit or low <= vis.tp2
                vis.tp3Hit := vis.tp3Hit or low <= vis.tp3
                vis.tp4Hit := vis.tp4Hit or low <= vis.tp4
                
            if not vis.isFinalized
                if isLast
                    if vis.slHit or vis.tp4Hit
                        vis.isFinalized := true
                        vis.endBar := bar_index
                    else
                        vis.endBar := bar_index
                else
                    if barsPassed >= 20
                        vis.isFinalized := true
                        vis.endBar := vis.entryBar + 20
                    else if vis.slHit or vis.tp4Hit
                        vis.isFinalized := true
                        vis.endBar := bar_index
                    else
                        vis.endBar := bar_index
            else
                if not isLast and vis.endBar > vis.entryBar + 20
                    vis.endBar := vis.entryBar + 20

            string trigText = str.tostring(vis.entryPrice, "#.##")
            string slText   = vis.slHit  ? "✘" : str.tostring(vis.sl, "#.##")
            string tp1Text  = vis.tp1Hit ? "✔" : str.tostring(vis.tp1, "#.##")
            string tp2Text  = vis.tp2Hit ? "✔" : str.tostring(vis.tp2, "#.##")
            string tp3Text  = vis.tp3Hit ? "✔" : str.tostring(vis.tp3, "#.##")
            string tp4Text  = vis.tp4Hit ? "✔" : str.tostring(vis.tp4, "#.##")

            line.set_style(vis.entryLine, line.style_solid)
            line.set_style(vis.slLine, line.style_solid)
            line.set_style(vis.tp1Line, line.style_solid)
            line.set_style(vis.tp2Line, line.style_solid)
            line.set_style(vis.tp3Line, line.style_solid)
            line.set_style(vis.tp4Line, line.style_solid)

            line.set_x2(vis.entryLine, vis.endBar)
            line.set_x2(vis.slLine, vis.endBar)
            line.set_x2(vis.tp1Line, vis.endBar)
            line.set_x2(vis.tp2Line, vis.endBar)
            line.set_x2(vis.tp3Line, vis.endBar)
            line.set_x2(vis.tp4Line, vis.endBar)
            
            label.set_x(vis.entryLabel, vis.endBar)
            label.set_x(vis.slLabel, vis.endBar)
            label.set_x(vis.tp1Label, vis.endBar)
            label.set_x(vis.tp2Label, vis.endBar)
            label.set_x(vis.tp3Label, vis.endBar)
            label.set_x(vis.tp4Label, vis.endBar)

            label.set_text(vis.entryLabel, trigText)
            label.set_text(vis.slLabel, slText)
            label.set_text(vis.tp1Label, tp1Text)
            label.set_text(vis.tp2Label, tp2Text)
            label.set_text(vis.tp3Label, tp3Text)
            label.set_text(vis.tp4Label, tp4Text)

            box.set_right(vis.profitBox, vis.endBar)
            box.set_right(vis.lossBox, vis.endBar)

            bool showLines = i_showRiskVisuals and i_showLines
            bool showZones = i_showRiskVisuals

            if showLines
                if i_activeTrig
                    line.set_color(vis.entryLine, i_trigColor)
                    line.set_width(vis.entryLine, i_trigWidth)
                    label.set_color(vis.entryLabel, i_trigColor)
                    label.set_textcolor(vis.entryLabel, color.white)
                    label.set_size(vis.entryLabel, size.tiny)
                    label.set_style(vis.entryLabel, label.style_label_left)
                else
                    line.set_color(vis.entryLine, color.new(color.white, 100))
                    label.set_color(vis.entryLabel, color.new(color.white, 100))
                    label.set_textcolor(vis.entryLabel, color.new(color.white, 100))

                if i_activeSL
                    line.set_color(vis.slLine, i_slColor)
                    line.set_width(vis.slLine, i_slWidth)
                    label.set_color(vis.slLabel, i_slColor)
                    label.set_textcolor(vis.slLabel, color.white)
                    label.set_size(vis.slLabel, size.tiny)
                    label.set_style(vis.slLabel, label.style_label_left)
                else
                    line.set_color(vis.slLine, color.new(color.white, 100))
                    label.set_color(vis.slLabel, color.new(color.white, 100))
                    label.set_textcolor(vis.slLabel, color.new(color.white, 100))

                if i_activeTP1
                    line.set_color(vis.tp1Line, i_tp1Color)
                    line.set_width(vis.tp1Line, i_tpWidth)
                    label.set_color(vis.tp1Label, i_tp1Color)
                    label.set_textcolor(vis.tp1Label, color.white)
                    label.set_size(vis.tp1Label, size.tiny)
                    label.set_style(vis.tp1Label, label.style_label_left)
                else
                    line.set_color(vis.tp1Line, color.new(color.white, 100))
                    label.set_color(vis.tp1Label, color.new(color.white, 100))
                    label.set_textcolor(vis.tp1Label, color.new(color.white, 100))

                if i_activeTP2
                    line.set_color(vis.tp2Line, i_tp2Color)
                    line.set_width(vis.tp2Line, i_tpWidth)
                    label.set_color(vis.tp2Label, i_tp2Color)
                    label.set_textcolor(vis.tp2Label, color.white)
                    label.set_size(vis.tp2Label, size.tiny)
                    label.set_style(vis.tp2Label, label.style_label_left)
                else
                    line.set_color(vis.tp2Line, color.new(color.white, 100))
                    label.set_color(vis.tp2Label, color.new(color.white, 100))
                    label.set_textcolor(vis.tp2Label, color.new(color.white, 100))

                if i_activeTP3
                    line.set_color(vis.tp3Line, i_tp3Color)
                    line.set_width(vis.tp3Line, i_tpWidth)
                    label.set_color(vis.tp3Label, i_tp3Color)
                    label.set_textcolor(vis.tp3Label, color.white)
                    label.set_size(vis.tp3Label, size.tiny)
                    label.set_style(vis.tp3Label, label.style_label_left)
                else
                    line.set_color(vis.tp3Line, color.new(color.white, 100))
                    label.set_color(vis.tp3Label, color.new(color.white, 100))
                    label.set_textcolor(vis.tp3Label, color.new(color.white, 100))

                if i_activeTP4
                    line.set_color(vis.tp4Line, i_tp4Color)
                    line.set_width(vis.tp4Line, i_tpWidth)
                    label.set_color(vis.tp4Label, i_tp4Color)
                    label.set_textcolor(vis.tp4Label, color.white)
                    label.set_size(vis.tp4Label, size.tiny)
                    label.set_style(vis.tp4Label, label.style_label_left)
                else
                    line.set_color(vis.tp4Line, color.new(color.white, 100))
                    label.set_color(vis.tp4Label, color.new(color.white, 100))
                    label.set_textcolor(vis.tp4Label, color.new(color.white, 100))
            else
                line.set_color(vis.entryLine, color.new(color.white, 100))
                line.set_color(vis.slLine, color.new(color.white, 100))
                line.set_color(vis.tp1Line, color.new(color.white, 100))
                line.set_color(vis.tp2Line, color.new(color.white, 100))
                line.set_color(vis.tp3Line, color.new(color.white, 100))
                line.set_color(vis.tp4Line, color.new(color.white, 100))
                label.set_color(vis.entryLabel, color.new(color.white, 100))
                label.set_color(vis.slLabel, color.new(color.white, 100))
                label.set_color(vis.tp1Label, color.new(color.white, 100))
                label.set_color(vis.tp2Label, color.new(color.white, 100))
                label.set_color(vis.tp3Label, color.new(color.white, 100))
                label.set_color(vis.tp4Label, color.new(color.white, 100))
                label.set_textcolor(vis.entryLabel, color.new(color.white, 100))
                label.set_textcolor(vis.slLabel, color.new(color.white, 100))
                label.set_textcolor(vis.tp1Label, color.new(color.white, 100))
                label.set_textcolor(vis.tp2Label, color.new(color.white, 100))
                label.set_textcolor(vis.tp3Label, color.new(color.white, 100))
                label.set_textcolor(vis.tp4Label, color.new(color.white, 100))

            if showZones
                box.set_bgcolor(vis.profitBox, i_profitZoneColor)
                box.set_bgcolor(vis.lossBox, i_lossZoneColor)
                box.set_border_color(vis.profitBox, color.new(i_tp4Color, 80))
                box.set_border_color(vis.lossBox, color.new(i_slColor, 80))
            else
                box.set_bgcolor(vis.profitBox, color.new(color.white, 100))
                box.set_bgcolor(vis.lossBox, color.new(color.white, 100))
                box.set_border_color(vis.profitBox, color.new(color.white, 100))
                box.set_border_color(vis.lossBox, color.new(color.white, 100))

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 12: EXECUTE HUD DRAWING (RESOLVES ISSUE 0)
// ═══════════════════════════════════════════════════════════════════════════

f_draw_dashboard(
  regime, structure, liquidity, context, quant, confluence, probability, 
  rank, setup, rr, score, structQual, liqQual, 
  globalWinRate, globalProfitFactor, globalNetProfit, globalMaxDD, globalExpectancy, 
  globalAvgWin, globalAvgLoss, globalSharpe, globalTotalTrades, 
  killActive, mcProb, rollingWinRate, rollingPF
 )

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 14: ALERTS - FIXED JSON BUILDER
// ═══════════════════════════════════════════════════════════════════════════

f_alert_payload(string direction, string rankVal, string setupVal, float probVal, float entry, float sl, float tp1, float tp2, float tp3, float tp4) =>
    string p = "{"
    p += "\"symbol\":\"" + syminfo.tickerid + "\","
    p += "\"side\":\"" + direction + "\","
    p += "\"rank\":\"" + rankVal + "\","
    p += "\"setup\":\"" + setupVal + "\","
    p += "\"probability\":\"" + str.tostring(probVal, "0.00") + "\","
    p += "\"entry\":\"" + str.tostring(entry, "0.00") + "\","
    p += "\"stop\":\"" + str.tostring(sl, "0.00") + "\","
    p += "\"tp1\":\"" + str.tostring(tp1, "0.00") + "\","
    p += "\"tp2\":\"" + str.tostring(tp2, "0.00") + "\","
    p += "\"tp3\":\"" + str.tostring(tp3, "0.00") + "\","
    p += "\"tp4\":\"" + str.tostring(tp4, "0.00") + "\""
    p += "}"
    p

if longSignal
    float entry = close
    float sl = f_stop_loss_calc(1, entry, snap.atr, swingHigh, swingLow)
    float risk = math.abs(entry - sl)
    float tp1 = entry + risk * i_tp1R
    float tp2 = entry + risk * i_tp2R
    float tp3 = entry + risk * i_tp3R
    float tp4 = entry + risk * i_tp4R
    alert(f_alert_payload("LONG", rank, setup, probability.longProb * 100.0, entry, sl, tp1, tp2, tp3, tp4), alert.freq_once_per_bar_close)

if shortSignal
    float entry = close
    float sl = f_stop_loss_calc(-1, entry, snap.atr, swingHigh, swingLow)
    float risk = math.abs(entry - sl)
    float tp1 = entry - risk * i_tp1R
    float tp2 = entry - risk * i_tp2R
    float tp3 = entry - risk * i_tp3R
    float tp4 = entry - risk * i_tp4R
    alert(f_alert_payload("SHORT", rank, setup, probability.shortProb * 100.0, entry, sl, tp1, tp2, tp3, tp4), alert.freq_once_per_bar_close)
    
======================================================================

2. ULI - Ultimate Liquidity Intelligence (sina)  

//@version=6
indicator("ULI - Ultimate Liquidity Intelligence (sina)", 
     overlay = true, 
     max_bars_back = 5000, 
     max_lines_count = 500, 
     max_labels_count = 500, 
     max_boxes_count = 500)

// ═══════════════════════════════════════════════════════════════════════════
// 1. INPUT GROUPS
// ═══════════════════════════════════════════════════════════════════════════

// 1.1 Performance and Stability
grpPerf = "⚡ Performance and Stability"
perfMode       = input.bool(false, "Performance Mode (reduces objects)", group=grpPerf)
confirmOnClose = input.bool(true,  "Confirm signals at bar close only", group=grpPerf)

// 1.2 Liquidity Zones (BSL/SSL)
grpLiq = "💧 Liquidity Zones (BSL / SSL)"
liqLen   = input.int(5,    "Detection Length", minval=3, maxval=15, group=grpLiq, tooltip="Lowered to 5 for faster detection on 5m/15m")
liqMar   = input.float(6.0, "ATR Margin Divisor", minval=2, maxval=12, step=0.1, group=grpLiq)
visLiq   = input.int(4,    "Visible Levels / Side", minval=1, maxval=12, group=grpLiq)
showBSL  = input.bool(true,  "Show Buyside Liquidity (BSL)", group=grpLiq)
showSSL  = input.bool(true,  "Show Sellside Liquidity (SSL)", group=grpLiq)
colBSL   = input.color(color.new(#14b8a6, 10), "BSL Color", group=grpLiq)
colSSL   = input.color(color.new(#ef4444, 10), "SSL Color", group=grpLiq)

// 1.3 Equal High / Equal Low
grpEQL = "〰 Equal High / Equal Low"
showEQL   = input.bool(true,   "Show EQH / EQL Lines", group=grpEQL)
eqlTolAtr = input.float(0.08,  "Tolerance (ATR)", minval=0.01, maxval=1.0, step=0.01, group=grpEQL)
colEQH    = input.color(color.new(#f97316, 0), "EQH Color", group=grpEQL)
colEQL    = input.color(color.new(#06b6d4, 0), "EQL Color", group=grpEQL)

// 1.4 Sweep Failure Patterns
grpSFP = "🔁 Sweep Failure Patterns (SFP)"
showSFP   = input.bool(true,   "Show SFP Markers", group=grpSFP)
pLeft     = input.int(3,       "Pivot Left Bars", minval=1, group=grpSFP)
pRight    = input.int(2,       "Pivot Right Bars", minval=1, group=grpSFP)
wickTh    = input.float(0.33,  "Min Wick Ratio", minval=0, maxval=1, step=0.05, group=grpSFP)
keyVolZ   = input.float(0.8,   "Key SFP Min Volume Z-Score", group=grpSFP)

// 1.5 Sweep Engine and Scoring
grpSweep = "🌊 Sweep Engine and Scoring"
swingLen   = input.int(12,   "Swing Length", minval=3, maxval=40, group=grpSweep)
poolAtr    = input.float(0.40, "Zone Half-Width (ATR)", minval=0.1, maxval=2.0, step=0.05, group=grpSweep)
mergeAtr   = input.float(0.30, "Merge Distance (ATR)", minval=0.05, maxval=2.0, step=0.01, group=grpSweep)
volMaLen   = input.int(20,    "Volume MA Length", minval=5, group=grpSweep)
volSpkMt   = input.float(1.30, "Min Volume / MA", minval=0.5, step=0.1, group=grpSweep)
useDispC   = input.bool(false, "Require Displacement Confirm", group=grpSweep)
actScor    = input.bool(true,  "Activate Min Score Filter", group=grpSweep)
minScore   = input.float(60.0, "Minimum Score to Signal", minval=0, maxval=100, step=1, group=grpSweep)

// 1.6 Fair Value Gaps
grpFVG = "📐 Fair Value Gaps (FVG)"
showFVG  = input.bool(true,  "Show FVG Zones", group=grpFVG)
fvgAtrMn = input.float(0.18, "Min FVG Size (ATR)", minval=0, step=0.01, group=grpFVG)
colFVGB  = input.color(color.new(#14b8a6, 82), "Bull FVG", group=grpFVG)
colFVGBr = input.color(color.new(#ef4444, 82), "Bear FVG", group=grpFVG)

// 1.7 Liquidity Voids
grpVoid = "🕳️ Liquidity Voids"
showVoid = input.bool(false, "Show Liquidity Voids", group=grpVoid)
colVoidB = input.color(color.new(#14b8a6, 90), "Bull Void", group=grpVoid)
colVoidS = input.color(color.new(#ef4444, 90), "Bear Void", group=grpVoid)

// 1.8 Previous Day/Week Levels
grpPDW = "📅 Previous Day / Week Levels"
showPDH = input.bool(true, "Show PDH / PDL", group=grpPDW)
showPWH = input.bool(true, "Show PWH / PWL", group=grpPDW)
colPDH  = input.color(color.new(#f97316, 0),  "PDH Color", group=grpPDW)
colPDL  = input.color(color.new(#06b6d4, 0),  "PDL Color", group=grpPDW)
colPWH  = input.color(color.new(#f97316, 40), "PWH Color", group=grpPDW)
colPWL  = input.color(color.new(#06b6d4, 40), "PWL Color", group=grpPDW)

// 1.9 Impulse AVWAP
grpVWAP = "〽️ Impulse AVWAP"
showAVWP = input.bool(true, "Show Impulse AVWAP", group=grpVWAP)
anchorN  = input.int(100,   "Anchor Length (N-bar extreme)", minval=10, group=grpVWAP)
showDAVW = input.bool(true, "Show Daily AVWAP", group=grpVWAP)
colAVWP  = input.color(#00ffe5, "Impulse AVWAP Color", group=grpVWAP)

// 1.10 Market Structure
grpStr = "🏗️ Market Structure (BOS / CHoCH)"
showStr   = input.bool(true, "Show BOS / CHoCH Lines", group=grpStr)
msLen     = input.int(24,    "Swing Length", minval=10, group=grpStr)
showSwngs = input.bool(true, "Show HH / HL / LH / LL Labels", group=grpStr)
colBull   = input.color(#22c55e, "Bullish Structure", group=grpStr)
colBear   = input.color(#ef4444, "Bearish Structure", group=grpStr)

// 1.11 Order Blocks
grpOB = "📦 Order Blocks"
showOB    = input.bool(true,  "Show Order Blocks", group=grpOB)
obSLast   = input.int(5,      "Max OBs Visible", minval=1, maxval=20, group=grpOB)
hideOBMit = input.bool(true,  "Hide Mitigated OBs", group=grpOB)
colBullOB = input.color(color.new(#22c55e, 82), "Bull OB", group=grpOB)
colBearOB = input.color(color.new(#ef4444, 82), "Bear OB", group=grpOB)
colOBMit  = input.color(color.new(#888888, 88), "Mitigated OB", group=grpOB)

// 1.12 Session Kill Zones
grpSess = "🕐 Session Kill Zones"
showSess = input.bool(false, "Show Session Zones", group=grpSess)
colLon   = input.color(color.new(#ffd700, 88), "London (08-11 UTC)", group=grpSess)
colNY    = input.color(color.new(#00ff88, 88), "New York (13-16 UTC)", group=grpSess)
colAsia  = input.color(color.new(#ff6600, 88), "Asian (00-03 UTC)", group=grpSess)

// 1.13 Trade Levels
grpTrade = "📊 Trade Levels"
showLvls = input.bool(true,   "Show Trade Levels", group=grpTrade)
slMode   = input.string("Structural", "Invalidation Mode", options=["Structural", "ATR"], group=grpTrade)
slAtrM   = input.float(2.0,   "SL ATR Multiple (ATR mode)", minval=0.3, step=0.1, group=grpTrade)
slPadAtr = input.float(0.15,  "Structural SL Padding (ATR)", minval=0, step=0.05, group=grpTrade)
rrTP1    = input.float(1.0,   "TP1 R Multiple", minval=0.3, step=0.1, group=grpTrade)
rrTP2    = input.float(2.0,   "TP2 R Multiple", minval=0.5, step=0.1, group=grpTrade)
rrTP3    = input.float(3.0,   "TP3 R Multiple", minval=1.0, step=0.1, group=grpTrade)
fillZns  = input.bool(true,   "Fill Trade Zones", group=grpTrade)

// 1.14 Market Regime
grpRegim = "🧠 Market Regime"
adxLen   = input.int(14,   "ADX Length", minval=2, group=grpRegim)
adxTrMin = input.float(20.0, "Trend ADX ≥", minval=1, step=0.5, group=grpRegim)
adxRgMax = input.float(16.0, "Range ADX ≤", minval=1, step=0.5, group=grpRegim)

// 1.15 Dashboard
grpDash = "📺 Dashboard"
dashMode = input.string("Pro", "Mode", options=["Off", "Mini", "Pro"], group=grpDash)
dashPos  = input.string("Top Right", "Position", options=["Top Right", "Top Left", "Bottom Right", "Bottom Left"], group=grpDash)
dashSize = input.string("Tiny", "Dashboard Text Size", options=["Tiny", "Small", "Normal", "Large"], group=grpDash)

// 1.16 Alerts
grpAlert = "🚨 Alerts"
alertFmt = input.string("JSON", "Format", options=["Text", "JSON"], group=grpAlert)

// 1.17 Backtest Engine
grpBT = "📈 Backtest Engine"
showBT = input.bool(true, "Enable Live Backtest", group=grpBT)
btInitCap = input.float(10000, "Initial Capital ($)", minval=100, step=100, group=grpBT)
btRiskPer = input.float(1.0, "Risk Per Trade (%)", minval=0.1, maxval=100, step=0.1, group=grpBT)
btCommPer = input.float(0.05, "Commission (%)", minval=0, maxval=1, step=0.01, group=grpBT)
btSlipPts = input.int(0, "Slippage (Points)", minval=0, group=grpBT, tooltip="Set to 0 by default")

// 1.18 Signal Visual Settings (Cleaned Up)
grpSigVis = "🎨 Signal Visual Settings"
colLongSig  = input.color(#22c55e, "Long Signal Color", group=grpSigVis)
colShortSig = input.color(#ef4444, "Short Signal Color", group=grpSigVis)

// ═══════════════════════════════════════════════════════════════════════════
// 2. UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

f_gc_sfp() => float(na)

f_clamp(float v, float lo, float hi) =>
    math.max(lo, math.min(hi, v))

f_norm01(float x, float lo, float hi) =>
    span = math.max(hi - lo, 1e-6)
    f_clamp((x - lo) / span, 0.0, 1.0)

f_z(float src, int len) =>
    m = ta.sma(src, len)
    s = ta.stdev(src, len)
    s > 0 ? (src - m) / s : 0.0

f_tanh(float x) =>
    xc = f_clamp(x, -10.0, 10.0)
    e2 = math.exp(2.0 * xc)
    (e2 - 1.0) / (e2 + 1.0)

f_dashPos() =>
    switch dashPos
        "Top Left"      => position.top_left
        "Bottom Right"  => position.bottom_right
        "Bottom Left"   => position.bottom_left
        => position.top_right

f_getDashSize(string dSz) =>
    switch dSz
        "Tiny"   => size.tiny
        "Small"  => size.small
        "Normal" => size.normal
        "Large"  => size.large
        => size.tiny

scoreTag(float sc) =>
    sc >= 80 ? "Exhaustive" : sc >= 60 ? "Strong" : sc >= 40 ? "Moderate" : "Weak"

// ═══════════════════════════════════════════════════════════════════════════
// 3. CORE SERIES
// ═══════════════════════════════════════════════════════════════════════════

atr14   = ta.atr(14)
atr200  = ta.atr(200)
volMa   = ta.sma(volume, volMaLen)
volZ    = f_z(volume, 50)
hlc     = hlc3
isConf  = not confirmOnClose or barstate.isconfirmed
maxFVG  = perfMode ? 4 : 8
maxOB   = perfMode ? 5 : 12
maxSFP  = perfMode ? 20 : 50

// ═══════════════════════════════════════════════════════════════════════════
// 4. PREVIOUS DAY / WEEK LEVELS
// ═══════════════════════════════════════════════════════════════════════════

[dHigh, dLow] = request.security(syminfo.tickerid, "D", [high[1], low[1]], lookahead=barmerge.lookahead_on)
[wHigh, wLow] = request.security(syminfo.tickerid, "W", [high[1], low[1]], lookahead=barmerge.lookahead_on)

pdh = dHigh
pdl = dLow
pwh = wHigh
pwl = wLow

pdhOk = not na(pdh)
pdlOk = not na(pdl)
pwhOk = not na(pwh)
pwlOk = not na(pwl)

var line   lnPDH = na
var line   lnPDL = na
var line   lnPWH = na
var line   lnPWL = na
var label  lbPDH = na
var label  lbPDL = na
var label  lbPWH = na
var label  lbPWL = na

dChange = timeframe.change("D")
wChange = timeframe.change("W")

// Weekly levels update
if wChange and showPWH
    line.delete(lnPWH)
    label.delete(lbPWH)
    line.delete(lnPWL)
    label.delete(lbPWL)
    if pwhOk
        lnPWH := line.new(bar_index, pwh, bar_index+1, pwh, color=colPWH, width=2, extend=extend.right)
        lbPWH := label.new(bar_index, pwh, "PWH\n"+str.tostring(pwh, format.mintick), 
                          style=label.style_label_right, color=color.new(colPWH, 82), 
                          textcolor=color.white, size=size.small)
    if pwlOk
        lnPWL := line.new(bar_index, pwl, bar_index+1, pwl, color=colPWL, width=2, extend=extend.right)
        lbPWL := label.new(bar_index, pwl, "PWL\n"+str.tostring(pwl, format.mintick), 
                          style=label.style_label_right, color=color.new(colPWL, 82), 
                          textcolor=color.white, size=size.small)
    line.delete(na)

// Daily levels update
if dChange and showPDH
    line.delete(lnPDH)
    label.delete(lbPDH)
    line.delete(lnPDL)
    label.delete(lbPDL)
    if pdhOk
        lnPDH := line.new(bar_index, pdh, bar_index+1, pdh, color=colPDH, width=1, 
                          style=line.style_dashed, extend=extend.right)
        lbPDH := label.new(bar_index, pdh, "PDH\n"+str.tostring(pdh, format.mintick), 
                          style=label.style_label_right, color=color.new(colPDH, 82), 
                          textcolor=color.white, size=size.small)
    if pdlOk
        lnPDL := line.new(bar_index, pdl, bar_index+1, pdl, color=colPDL, width=1, 
                          style=line.style_dashed, extend=extend.right)
        lbPDL := label.new(bar_index, pdl, "PDL\n"+str.tostring(pdl, format.mintick), 
                          style=label.style_label_right, color=color.new(colPDL, 82), 
                          textcolor=color.white, size=size.small)
    line.delete(na)

// ═══════════════════════════════════════════════════════════════════════════
// 5. IMPULSE AVWAP and DAILY AVWAP
// ═══════════════════════════════════════════════════════════════════════════

var float impPV = na
var float impV  = na

isNewH = high > ta.highest(high, anchorN)[1]
isNewL = low  < ta.lowest(low, anchorN)[1]

if barstate.isfirst
    impPV := hlc * volume
    impV  := volume
else if isNewH or isNewL
    impPV := hlc * volume
    impV  := volume
else
    impPV += hlc * volume
    impV  += volume

impAVWAP = impPV / math.max(impV, 1.0)

var float dayPV = na
var float dayV  = na
newDay = ta.change(time("D")) != 0

if barstate.isfirst or newDay
    dayPV := hlc * volume
    dayV  := volume
else
    dayPV += hlc * volume
    dayV  += volume

dAVWAP = dayPV / math.max(dayV, 1.0)

stretchImp = (close - impAVWAP) / math.max(atr14, syminfo.mintick)
stretchDay = (close - dAVWAP) / math.max(atr14, syminfo.mintick)

// ═══════════════════════════════════════════════════════════════════════════
// 6. FVG ENGINE
// ═══════════════════════════════════════════════════════════════════════════

type FVGZone
    int     left
    float   top
    float   bot
    bool    isBull
    bool    mitigated
    box     bx

var array<FVGZone> fvgList = array.new<FVGZone>()

newBullFVG = low[1] > high[2] and (low[1] - high[2]) >= atr14 * fvgAtrMn and close[1] > open[1]
newBearFVG = high[1] < low[2] and (low[2] - high[1]) >= atr14 * fvgAtrMn and close[1] < open[1]

if newBullFVG and showFVG and barstate.isconfirmed
    if array.size(fvgList) > maxFVG * 2
        FVGZone ev = array.shift(fvgList)
        box.delete(ev.bx)
    bx = box.new(bar_index-2, low[1], bar_index+3, high[2], border_color=na, bgcolor=colFVGB)
    array.push(fvgList, FVGZone.new(bar_index-2, low[1], high[2], true, false, bx))

if newBearFVG and showFVG and barstate.isconfirmed
    if array.size(fvgList) > maxFVG * 2
        FVGZone ev = array.shift(fvgList)
        box.delete(ev.bx)
    bx = box.new(bar_index-2, low[2], bar_index+3, high[1], border_color=na, bgcolor=colFVGBr)
    array.push(fvgList, FVGZone.new(bar_index-2, low[2], high[1], false, false, bx))

bool fvgBullNear = false
bool fvgBearNear = false

if showFVG
    sz = array.size(fvgList)
    if sz > 0
        for i = 0 to sz-1
            FVGZone z = array.get(fvgList, i)
            if not z.mitigated
                if z.isBull and low[1] <= z.top
                    z.mitigated := true
                    box.delete(z.bx)
                    array.set(fvgList, i, z)
                else if not z.isBull and high[1] >= z.bot
                    z.mitigated := true
                    box.delete(z.bx)
                    array.set(fvgList, i, z)
                else
                    effLeft = math.max(z.left, bar_index-499)
                    box.delete(z.bx)
                    z.bx := box.new(effLeft, z.top, bar_index+3, z.bot, border_color=na, bgcolor=z.isBull ? colFVGB : colFVGBr)
                    array.set(fvgList, i, z)
                    if z.isBull
                        fvgBullNear := true
                    else
                        fvgBearNear := true

// ═══════════════════════════════════════════════════════════════════════════
// 7. LIQUIDITY ZONES (ZigZag Cluster)
// ═══════════════════════════════════════════════════════════════════════════

type LiqZone
    box     core
    box     zone
    line    lvl
    line    ext
    bool    broken
    bool    inZone

maxSz = 50
margin_atr = 10.0 / liqMar

var int[]   zzD = array.new<int>(maxSz, 0)
var int[]   zzX = array.new<int>(maxSz, 0)
var float[] zzY = array.new<float>(maxSz, na)

zzUpdate(int d, int x, float y) =>
    array.unshift(zzD, d)
    array.unshift(zzX, x)
    array.unshift(zzY, y)
    array.pop(zzD)
    array.pop(zzX)
    array.pop(zzY)

var LiqZone[] bslList = array.new<LiqZone>()
var LiqZone[] sslList = array.new<LiqZone>()

isPresent = last_bar_index - bar_index <= 600
ph_liq = ta.pivothigh(liqLen, 1)
pl_liq = ta.pivotlow(liqLen, 1)
pivX2 = bar_index - 1

// Process BSL
if not na(ph_liq)
    d0 = array.get(zzD, 0)
    y0 = array.get(zzY, 0)
    if d0 < 1
        zzUpdate(1, pivX2, nz(high[1]))
    else if d0 == 1 and ph_liq > y0
        array.set(zzX, 0, pivX2)
        array.set(zzY, 0, nz(high[1]))
    
    if isPresent
        cnt = 0
        stB = 0
        stP = 0.0
        minP = 0.0
        maxP = 10e6
        for i = 0 to maxSz-1
            if array.get(zzD, i) == 1
                yy = array.get(zzY, i)
                if yy > ph_liq + (atr14/margin_atr)
                    break
                if yy > ph_liq - (atr14/margin_atr) and yy < ph_liq + (atr14/margin_atr)
                    cnt += 1
                    stB := array.get(zzX, i)
                    stP := yy
                    if yy > minP
                        minP := yy
                    if yy < maxP
                        maxP := yy
        
        if cnt > 2 and showBSL
            mid = math.avg(minP, maxP)
            half = atr14/margin_atr
            sz = array.size(bslList)
            dup = false
            if sz > 0
                for j = 0 to sz-1
                    LiqZone z = array.get(bslList, j)
                    if not na(z.core) and math.abs(z.core.get_top() - mid - half) < atr14 * 0.2
                        dup := true
                        break
            if not dup
                c = box.new(stB, mid+half, bar_index+8, mid-half, 
                           bgcolor=color.new(colBSL, 86), border_color=color.new(colBSL, 20))
                z2 = box.new(stB, mid+half*1.8, bar_index+8, mid-half*1.8, 
                            bgcolor=color.new(colBSL, 95), border_color=na)
                lvl_line = line.new(stB, stP, bar_index-1, stP, color=color.new(colBSL, 0))
                ex = line.new(bar_index-1, stP, na, stP, color=color.new(colBSL, 0), style=line.style_dotted)
                array.unshift(bslList, LiqZone.new(c, z2, lvl_line, ex, false, false))
                
                if array.size(bslList) > visLiq
                    LiqZone old = array.pop(bslList)
                    box.delete(old.core)
                    box.delete(old.zone)
                    line.delete(old.lvl)
                    line.delete(old.ext)

// Process SSL
if not na(pl_liq)
    d0 = array.get(zzD, 0)
    y0 = array.get(zzY, 0)
    if d0 > -1
        zzUpdate(-1, pivX2, nz(low[1]))
    else if d0 == -1 and pl_liq < y0
        array.set(zzX, 0, pivX2)
        array.set(zzY, 0, nz(low[1]))
    
    if isPresent
        cnt = 0
        stB = 0
        stP = 0.0
        minP = 0.0
        maxP = 10e6
        for i = 0 to maxSz-1
            if array.get(zzD, i) == -1
                yy = array.get(zzY, i)
                if yy < pl_liq - (atr14/margin_atr)
                    break
                if yy > pl_liq - (atr14/margin_atr) and yy < pl_liq + (atr14/margin_atr)
                    cnt += 1
                    stB := array.get(zzX, i)
                    stP := yy
                    if yy > minP
                        minP := yy
                    if yy < maxP
                        maxP := yy
        
        if cnt > 2 and showSSL
            mid = math.avg(minP, maxP)
            half = atr14/margin_atr
            sz = array.size(sslList)
            dup = false
            if sz > 0
                for j = 0 to sz-1
                    LiqZone z = array.get(sslList, j)
                    if not na(z.core) and math.abs(z.core.get_bottom() - mid + half) < atr14 * 0.2
                        dup := true
                        break
            if not dup
                c = box.new(stB, mid+half, bar_index+8, mid-half, 
                           bgcolor=color.new(colSSL, 86), border_color=color.new(colSSL, 20))
                z2 = box.new(stB, mid+half*1.8, bar_index+8, mid-half*1.8, 
                            bgcolor=color.new(colSSL, 95), border_color=na)
                lvl_line = line.new(stB, stP, bar_index-1, stP, color=color.new(colSSL, 0))
                ex = line.new(bar_index-1, stP, na, stP, color=color.new(colSSL, 0), style=line.style_dotted)
                array.unshift(sslList, LiqZone.new(c, z2, lvl_line, ex, false, false))
                
                if array.size(sslList) > visLiq
                    LiqZone old = array.pop(sslList)
                    box.delete(old.core)
                    box.delete(old.zone)
                    line.delete(old.lvl)
                    line.delete(old.ext)

// Update BSL break/zones
bslSz = array.size(bslList)
if bslSz > 0
    for i = 0 to bslSz-1
        LiqZone z = array.get(bslList, i)
        if not z.broken
            z.ext.set_x2(bar_index)
            if high > z.lvl.get_y1()
                z.broken := true
                z.inZone := true
                z.zone.set_lefttop(bar_index-1, math.min(z.lvl.get_y1()+atr14*2, high))
                z.zone.set_rightbottom(bar_index+1, z.lvl.get_y1())
                z.zone.set_bgcolor(color.new(colBSL, 73))
                array.set(bslList, i, z)
        else if z.inZone
            if low > z.lvl.get_y1()-atr14*2.3 and high < z.lvl.get_y1()+atr14*2.3
                z.zone.set_right(bar_index+1)
                z.zone.set_top(math.max(high, z.zone.get_top()))
                z.ext.set_x2(bar_index+1)
                array.set(bslList, i, z)
            else
                z.inZone := false
                array.set(bslList, i, z)

// Update SSL break/zones
sslSz = array.size(sslList)
if sslSz > 0
    for i = 0 to sslSz-1
        LiqZone z = array.get(sslList, i)
        if not z.broken
            z.ext.set_x2(bar_index)
            if low < z.lvl.get_y1()
                z.broken := true
                z.inZone := true
                z.zone.set_lefttop(bar_index-1, z.lvl.get_y1())
                z.zone.set_rightbottom(bar_index+1, math.max(z.lvl.get_y1()-atr14*2, low))
                z.zone.set_bgcolor(color.new(colSSL, 73))
                array.set(sslList, i, z)
        else if z.inZone
            if low > z.lvl.get_y1()-atr14*2.3 and high < z.lvl.get_y1()+atr14*2.3
                z.zone.set_right(bar_index+1)
                z.zone.set_bottom(math.min(low, z.zone.get_bottom()))
                z.ext.set_x2(bar_index+1)
                array.set(sslList, i, z)
            else
                z.inZone := false
                array.set(sslList, i, z)

// ═══════════════════════════════════════════════════════════════════════════
// 8. EQUAL HIGHS / EQUAL LOWS
// ═══════════════════════════════════════════════════════════════════════════

var array<line>  eqhLines = array.new<line>()
var array<label> eqhLbls  = array.new<label>()
var array<float> eqhPrices= array.new<float>()
var array<line>  eqlLines = array.new<line>()
var array<label> eqlLbls  = array.new<label>()
var array<float> eqlPrices= array.new<float>()

ph_eq = ta.pivothigh(high, pLeft, pRight)
pl_eq = ta.pivotlow(low, pLeft, pRight)
eqlTol = atr14 * eqlTolAtr

// Equal Highs
if showEQL and not na(ph_eq)
    phBar = bar_index - pRight
    matched = false
    if array.size(eqhPrices) > 0
        for j = 0 to array.size(eqhPrices)-1
            if math.abs(ph_eq - array.get(eqhPrices, j)) <= eqlTol
                matched := true
                ln = array.get(eqhLines, j)
                ln.set_x2(phBar)
                lb = array.get(eqhLbls, j)
                lb.set_text("EQH x" + str.tostring(j+2))
                lb.set_x(phBar)
                break
    
    if not matched
        if array.size(eqhLines) >= 10
            line.delete(array.shift(eqhLines))
            label.delete(array.shift(eqhLbls))
            array.shift(eqhPrices)
        
        ln = line.new(phBar, ph_eq, phBar+1, ph_eq, color=colEQH, width=2, 
                      style=line.style_dotted, extend=extend.right)
        lb = label.new(phBar, ph_eq, "EQH", style=label.style_label_down, 
                       color=color.new(colEQH, 80), textcolor=color.white, size=size.tiny)
        array.push(eqhLines, ln)
        array.push(eqhLbls, lb)
        array.push(eqhPrices, ph_eq)

// Equal Lows
if showEQL and not na(pl_eq)
    plBar = bar_index - pRight
    matched = false
    if array.size(eqlPrices) > 0
        for j = 0 to array.size(eqlPrices)-1
            if math.abs(pl_eq - array.get(eqlPrices, j)) <= eqlTol
                matched := true
                ln = array.get(eqlLines, j)
                ln.set_x2(plBar)
                lb = array.get(eqlLbls, j)
                lb.set_text("EQL x" + str.tostring(j+2))
                lb.set_x(plBar)
                break
    
    if not matched
        if array.size(eqlLines) >= 10
            line.delete(array.shift(eqlLines))
            label.delete(array.shift(eqlLbls))
            array.shift(eqlPrices)
        
        ln = line.new(plBar, pl_eq, plBar+1, pl_eq, color=colEQL, width=2, 
                      style=line.style_dotted, extend=extend.right)
        lb = label.new(plBar, pl_eq, "EQL", style=label.style_label_up, 
                       color=color.new(colEQL, 80), textcolor=color.white, size=size.tiny)
        array.push(eqlLines, ln)
        array.push(eqlLbls, lb)
        array.push(eqlPrices, pl_eq)

// ═══════════════════════════════════════════════════════════════════════════
// 9. SFP (SWEEP FAILURE PATTERN)
// ═══════════════════════════════════════════════════════════════════════════

ph_sfp = ta.pivothigh(high, pLeft, pRight)
pl_sfp = ta.pivotlow(low, pLeft, pRight)

var float lastPH = na
var int   lastPH_idx = na
var float lastPL = na
var int   lastPL_idx = na

if not na(ph_sfp)
    lastPH := ph_sfp
    lastPH_idx := bar_index - pRight
if not na(pl_sfp)
    lastPL := pl_sfp
    lastPL_idx := bar_index - pRight

tr = ta.tr
uWick = high - math.max(open, close)
lWick = math.min(open, close) - low

bearSFP = not na(lastPH) and high > lastPH and close < lastPH and tr>0 and (uWick/tr) >= wickTh
bullSFP = not na(lastPL) and low < lastPL and close > lastPL and tr>0 and (lWick/tr) >= wickTh
isKeySFP = volZ >= keyVolZ and math.abs(stretchImp) >= 0.8

var array<label> sfpLbls = array.new<label>()
var array<line>  sfpLins = array.new<line>()
var array<box>   sfpBxes = array.new<box>()
var int lastBearSFPBar = -999
var int lastBullSFPBar = -999

if showSFP and isConf
    if bearSFP and bar_index - lastBearSFPBar >= 3
        lastBearSFPBar := bar_index
        bx = box.new(bar_index-1, high, bar_index, math.max(open, close), 
                     bgcolor=color.new(#ef4444, 90), border_color=color.new(#ef4444, 60))
        ln = line.new(bar_index-8, lastPH, bar_index+12, lastPH, 
                      color=color.new(#ef4444, 0), width=1, style=line.style_dotted)
        sy = isKeySFP ? label.style_label_down : label.style_triangledown
        lb = label.new(bar_index, high+atr14*0.2, isKeySFP ? "KEY SFP" : "", 
                       style=sy, color=color.new(#ef4444, isKeySFP?10:30), 
                       textcolor=color.white, size=size.tiny) // Minimalist: changed size to tiny
        array.push(sfpBxes, bx)
        array.push(sfpLins, ln)
        array.push(sfpLbls, lb)
    
    if bullSFP and bar_index - lastBullSFPBar >= 3
        lastBullSFPBar := bar_index
        bx = box.new(bar_index-1, math.min(open, close), bar_index, low, 
                     bgcolor=color.new(#14b8a6, 90), border_color=color.new(#14b8a6, 60))
        ln = line.new(bar_index-8, lastPL, bar_index+12, lastPL, 
                      color=color.new(#14b8a6, 0), width=1, style=line.style_dotted)
        sy = isKeySFP ? label.style_label_up : label.style_triangleup
        lb = label.new(bar_index, low-atr14*0.2, isKeySFP ? "KEY SFP" : "", 
                       style=sy, color=color.new(#14b8a6, isKeySFP?10:30), 
                       textcolor=color.white, size=size.tiny) // Minimalist: changed size to tiny
        array.push(sfpBxes, bx)
        array.push(sfpLins, ln)
        array.push(sfpLbls, lb)

// ═══════════════════════════════════════════════════════════════════════════
// 10. MARKET STRUCTURE (BOS / CHoCH)
// ═══════════════════════════════════════════════════════════════════════════

swingCalc(int len) =>
    var int os = 0
    upper = ta.highest(len)
    lower = ta.lowest(len)
    os := high[len] > upper ? 0 : low[len] < lower ? 1 : os[1]
    top = os == 0 and os[1] != 0 ? high[len] : 0.0
    btm = os == 1 and os[1] != 1 ? low[len] : 0.0
    [top, btm]

[swTop, swBtm] = swingCalc(msLen)

var int    msTrend = 0
var float  topY = 0.0
var int    topX = 0
var float  btmY = 0.0
var int    btmX = 0
var bool   topCross = true
var bool   btmCross = true
var float  trailUp = high
var int    trailUpX = 0
var float  trailDn = low
var int    trailDnX = 0
var string txtTop = ""
var string txtBtm = ""

n = bar_index
TRANSP = #ffffff00

if swTop > 0
    topCross := true
    txtTop := swTop > topY ? "HH" : "LH"
    if showSwngs
        label.new(n-msLen, swTop, txtTop, color=TRANSP, textcolor=colBear, 
                  style=label.style_label_down, size=size.small)
    topY := swTop
    topX := n-msLen
    trailUp := swTop
    trailUpX := n-msLen

if swBtm > 0
    txtBtm := swBtm < btmY ? "LL" : "HL"
    if showSwngs
        label.new(n-msLen, swBtm, txtBtm, color=TRANSP, textcolor=colBull, 
                  style=label.style_label_up, size=size.small)
    btmY := swBtm
    btmX := n-msLen
    trailDn := swBtm
    trailDnX := n-msLen

trailUp := math.max(high, trailUp)
trailUpX := trailUp == high ? n : trailUpX
trailDn := math.min(low, trailDn)
trailDnX := trailDn == low ? n : trailDnX

displayStructure(int x, float y, string txt, color css, bool dashed, bool down) =>
    if showStr
        line.new(x, y, n, y, color=css, style=dashed ? line.style_dashed : line.style_solid)
        label.new(int(math.avg(x, n)), y, txt, color=TRANSP, textcolor=css, 
                  style=down ? label.style_label_down : label.style_label_up, size=size.small)

if ta.crossover(close, topY) and topCross
    bool choch = msTrend < 0
    txt = choch ? "CHoCH" : "BOS"
    displayStructure(topX, topY, txt, colBull, false, true)
    topCross := false
    msTrend := 1

if ta.crossunder(close, btmY) and btmCross
    bool choch = msTrend > 0
    txt = choch ? "CHoCH" : "BOS"
    displayStructure(btmX, btmY, txt, colBear, false, false)
    btmCross := false
    msTrend := -1

// ═══════════════════════════════════════════════════════════════════════════
// 11. ORDER BLOCKS
// ═══════════════════════════════════════════════════════════════════════════

type OBBlock
    int     lft
    int     rgt
    float   top
    float   bottom 
    bool    isBull
    bool    mitigated
    box     bx

var array<OBBlock> obList = array.new<OBBlock>()

f_addOB(bool bull, float t, float b, int lft) =>
    if array.size(obList) >= maxOB
        OBBlock old = array.shift(obList)
        box.delete(old.bx)
    bx = box.new(lft, t, bar_index+10, b, border_color=na, 
                 bgcolor=bull ? colBullOB : colBearOB)
    array.push(obList, OBBlock.new(lft, bar_index+10, t, b, bull, false, bx))

if ta.crossover(close, topY) and topCross and showOB
    f_addOB(true, btmY + atr14*0.5, btmY, btmX)

if ta.crossunder(close, btmY) and btmCross and showOB
    f_addOB(false, topY, topY - atr14*0.5, topX)

obSz = array.size(obList)
if obSz > 0
    for i = 0 to obSz-1
        OBBlock ob = array.get(obList, i)
        if not ob.mitigated
            hitBull = ob.isBull and low[1] <= ob.bottom
            hitBear = not ob.isBull and high[1] >= ob.top
            if hitBull or hitBear
                ob.mitigated := true
                if hideOBMit
                    box.delete(ob.bx)
                else
                    ob.bx.set_bgcolor(colOBMit)
                array.set(obList, i, ob)

// ═══════════════════════════════════════════════════════════════════════════
// 12. SESSION KILL ZONES
// ═══════════════════════════════════════════════════════════════════════════

var box   lonBox = na
var float lonH = na
var float lonL = na
var int   lonLeft = na
var box   nyBox = na
var float nyH = na
var float nyL = na
var int   nyLeft = na
var box   asBox = na
var float asH = na
var float asL = na
var int   asLeft = na
var bool  wasLon = false
var bool  wasNY = false
var bool  wasAs = false

hrUTC = hour(time, "UTC")
nowLon  = hrUTC >= 8  and hrUTC < 11
nowNY   = hrUTC >= 13 and hrUTC < 16
nowAsia = hrUTC >= 0  and hrUTC < 3
inSess  = nowLon or nowNY or nowAsia

if showSess
    if nowLon and not wasLon
        lonLeft := bar_index
        lonH := high
        lonL := low
    if nowLon and not na(lonLeft)
        lonH := math.max(lonH, high)
        lonL := math.min(lonL, low)
        box.delete(lonBox)
        lonBox := box.new(lonLeft, lonH, bar_index+1, lonL, border_color=na, bgcolor=colLon)
    
    if nowNY and not wasNY
        nyLeft := bar_index
        nyH := high
        nyL := low
    if nowNY and not na(nyLeft)
        nyH := math.max(nyH, high)
        nyL := math.min(nyL, low)
        box.delete(nyBox)
        nyBox := box.new(nyLeft, nyH, bar_index+1, nyL, border_color=na, bgcolor=colNY)
    
    if nowAsia and not wasAs
        asLeft := bar_index
        asH := high
        asL := low
    if nowAsia and not na(asLeft)
        asH := math.max(asH, high)
        asL := math.min(asL, low)
        box.delete(asBox)
        asBox := box.new(asLeft, asH, bar_index+1, asL, border_color=na, bgcolor=colAsia)
    
    wasLon := nowLon
    wasNY  := nowNY
    wasAs  := nowAsia

// ═══════════════════════════════════════════════════════════════════════════
// 13. SWEEP DETECTION + SCORING ENGINE
// ═══════════════════════════════════════════════════════════════════════════

var float[] hMid = array.new<float>()
var float[] lMid = array.new<float>()
var float[] hTop = array.new<float>()
var float[] lTop = array.new<float>()
var float[] hBot = array.new<float>()
var float[] lBot = array.new<float>()
var int[]   hSt  = array.new<int>()
var int[]   lSt  = array.new<int>()
var int[]   hHits= array.new<int>()
var int[]   lHits= array.new<int>()
var int[]   hBar = array.new<int>()
var int[]   lBar = array.new<int>()
var box[]   hCore= array.new<box>()
var box[]   lCore= array.new<box>()
var line[]  hLn  = array.new<line>()
var line[]  lLn  = array.new<line>()

ema200 = ta.ema(close, 200)

// Extract ta.lowest and ta.highest to global scope
float lowest8 = ta.lowest(low, 8)[1]
float highest8 = ta.highest(high, 8)[1]

scorePen      = 16.0
scoreReclaim  = 18.0
scoreWick     = 14.0
scoreBody     = 8.0
scoreEma      = 10.0
scoreLen      = 12.0
scoreMSS      = 16.0
scoreEffort   = 12.0

f_scorePenetration(float penatr) =>
    lo = 0.05
    hi = 1.20
    target = lo + (hi - lo) * 0.35
    halfspan = math.max((hi - lo) * 0.65, 0.20)
    f_clamp(1.0 - math.abs(penatr - target) / halfspan, 0.0, 1.0)

f_scoreReclaim(float reclaimPct) =>
    f_norm01(reclaimPct, 30.0, 100.0)

f_scoreWick(float wickRatio) =>
    f_clamp(wickRatio / 1.5, 0.0, 1.0)

f_scoreEMA(int dir, float closePx, float emaPx, float atrRef) =>
    atrRef <= 0 ? 0.5 : (dir == 1 ? f_clamp((emaPx - closePx) / atrRef / 1.8, 0.0, 1.0) 
                                   : f_clamp((closePx - emaPx) / atrRef / 1.8, 0.0, 1.0))

f_scoreMSS(int dir, float reflvl, float closePx, float atrRef) =>
    na(reflvl) or atrRef <= 0 ? 0.0 : (dir == -1 ? f_clamp((reflvl - closePx) / atrRef / 1.2, 0.0, 1.0) 
                                                 : f_clamp((closePx - reflvl) / atrRef / 1.2, 0.0, 1.0))

f_scoreEffort(float rangeAtr, float volRatio) =>
    volSc = na(volRatio) ? 0.5 : f_norm01(volRatio, 0.7, math.max(volSpkMt, 0.8))
    rangSc = f_norm01(rangeAtr, 0.0, 0.80)
    f_clamp(volSc * 0.60 + rangSc * 0.40, 0.0, 1.0)

f_totalScore(float base, float mss, float effort) =>
    tw = scorePen + scoreReclaim + scoreWick + scoreBody + scoreEma + scoreLen + scoreMSS + scoreEffort
    tp = base + scoreMSS * mss + scoreEffort * effort
    tw > 0 ? tp / tw * 100.0 : 0.0

ph_sw = ta.pivothigh(swingLen, swingLen)
pl_sw = ta.pivotlow(swingLen, swingLen)

f_regPool(float price, bool isHigh, float atrRef) =>
    half = math.max(atrRef * poolAtr, syminfo.mintick * 5)
    mergeB = math.max(atrRef * mergeAtr, syminfo.mintick * 8)
    
    mid_arr = isHigh ? hMid : lMid
    top_arr = isHigh ? hTop : lTop
    bot_arr = isHigh ? hBot : lBot
    st_arr  = isHigh ? hSt  : lSt
    hit_arr = isHigh ? hHits: lHits
    bar_arr = isHigh ? hBar : lBar
    core_arr= isHigh ? hCore: lCore
    ln_arr  = isHigh ? hLn  : lLn
    
    near = -1
    bestD = 10e10
    sz = array.size(mid_arr)
    if sz > 0
        for i = 0 to sz-1
            if array.get(st_arr, i) < 2
                d = math.abs(price - array.get(mid_arr, i))
                if d <= mergeB and d < bestD
                    bestD := d
                    near := i
    
    if near == -1
        c = box.new(bar_index-swingLen, price+half, bar_index+swingLen, price-half, 
                    bgcolor=color.new(isHigh ? colSSL : colBSL, 88), 
                    border_color=color.new(isHigh ? colSSL : colBSL, 62))
        l = line.new(bar_index-swingLen, price, bar_index+swingLen, price, 
                     color=color.new(isHigh ? colSSL : colBSL, 0), style=line.style_dotted)
        array.push(mid_arr, price)
        array.push(top_arr, price+half)
        array.push(bot_arr, price-half)
        array.push(st_arr, 0)
        array.push(hit_arr, 1)
        array.push(bar_arr, bar_index)
        array.push(core_arr, c)
        array.push(ln_arr, l)
        
        while array.size(mid_arr) > 14
            box.delete(array.shift(core_arr))
            line.delete(array.shift(ln_arr))
            array.shift(mid_arr)
            array.shift(top_arr)
            array.shift(bot_arr)
            array.shift(st_arr)
            array.shift(hit_arr)
            array.shift(bar_arr)
        void_val = 0
    else
        oldMid = array.get(mid_arr, near)
        oldHits = array.get(hit_arr, near)
        nHits = oldHits + 1
        nMid = (oldMid * oldHits + price) / nHits
        nHalf = math.max(atrRef * poolAtr * (1 + math.min(nHits, 8) * 0.05), syminfo.mintick * 5)
        array.set(mid_arr, near, nMid)
        array.set(top_arr, near, nMid + nHalf)
        array.set(bot_arr, near, nMid - nHalf)
        array.set(hit_arr, near, nHits)
        void_val = 0

if not na(ph_sw)
    f_regPool(high[swingLen], true, nz(atr14[swingLen], atr14))
if not na(pl_sw)
    f_regPool(low[swingLen], false, nz(atr14[swingLen], atr14))

bool newBullSweep = false
bool newBearSweep = false

type SweepResult
    bool newBull
    bool newBear
    float score

f_processSweeps(bool isHigh, float lowest8_val, float highest8_val) =>
    mid_arr = isHigh ? hMid : lMid
    top_arr = isHigh ? hTop : lTop
    bot_arr = isHigh ? hBot : lBot
    st_arr  = isHigh ? hSt  : lSt
    hit_arr = isHigh ? hHits: lHits
    bar_arr = isHigh ? hBar : lBar
    core_arr= isHigh ? hCore: lCore
    ln_arr  = isHigh ? hLn  : lLn
    
    bool resultBull = false
    bool resultBear = false
    float resultScore = 0.0
    int dummy = 0  
    
    sz = array.size(mid_arr)
    if sz > 0
        for i = sz-1 to 0
            mid  = array.get(mid_arr, i)
            top  = array.get(top_arr, i)
            bot  = array.get(bot_arr, i)
            st   = array.get(st_arr, i)
            stBar= array.get(bar_arr, i)
            age  = bar_index - stBar
            bx   = array.get(core_arr, i)
            ln   = array.get(ln_arr, i)
            
            if age > 1800 or (st == 2)
                box.delete(bx)
                line.delete(ln)
                array.remove(mid_arr, i)
                array.remove(top_arr, i)
                array.remove(bot_arr, i)
                array.remove(st_arr, i)
                array.remove(hit_arr, i)
                array.remove(bar_arr, i)
                array.remove(core_arr, i)
                array.remove(ln_arr, i)
                dummy := 0  
            else
                bx.set_right(bar_index+10)
                ln.set_x2(bar_index+10)
                
                if st < 2
                    sweepRaw = isHigh ? (high > top and close < mid) : (low < bot and close > mid)
                    if sweepRaw and st == 0
                        float penatr = atr14 > 0 ? (isHigh ? math.max(high-top, 0)/atr14 : math.max(bot-low, 0)/atr14) : 0.0
                        float reclaimPct = high > low ? (isHigh ? (high-close)/(high-low)*100 : (close-low)/(high-low)*100) : 0.0
                        bool bodyOk = isHigh ? close < open : close > open
                        float bAbs = math.abs(close-open)
                        float wk = isHigh ? high - math.max(open, close) : math.min(open, close) - low
                        float wickRatio = wk / math.max(bAbs, syminfo.mintick)
                        float mssRef = isHigh ? lowest8_val : highest8_val
                        float rangeAtr = atr14 > 0 ? (high - low)/atr14 : 0.0
                        float volRatio = not na(volMa) and volMa > 0 ? volume/volMa : na
                        
                        baseW = scorePen * f_scorePenetration(penatr) +   scoreReclaim * f_scoreReclaim(reclaimPct) +    scoreWick * f_scoreWick(wickRatio) +    scoreBody * (bodyOk ? 1.0 : 0.3) +   scoreEma * f_scoreEMA(isHigh ? -1 : 1, close, ema200, atr14) +    scoreLen * f_norm01(float(age), 0.0, 50.0)
                        mssScore = f_scoreMSS(isHigh ? -1 : 1, mssRef, close, atr14)
                        effScore = f_scoreEffort(rangeAtr, volRatio)
                        fScore = f_totalScore(baseW, mssScore, effScore)
                        
                        if not actScor or fScore >= minScore
                            array.set(st_arr, i, 1)
                            bx.set_bgcolor(color.new(#f59e0b, 82))
                            bx.set_border_color(color.new(#f59e0b, 40))
                            ln.set_color(color.new(#f59e0b, 0))
                            ln.set_style(line.style_dashed)
                            resultScore := fScore
                            if isHigh
                                resultBear := true
                            else
                                resultBull := true
                    
                    broken = isHigh ? close > top : close < bot
                    if broken
                        array.set(st_arr, i, 2)
                        bx.set_bgcolor(na)
                        bx.set_border_color(na)
                        ln.set_color(na)
                dummy := 0  
    
    SweepResult.new(resultBull, resultBear, resultScore)

// Call functions and collect results with pre-calculated values
SweepResult highResult = f_processSweeps(true, lowest8, highest8)
SweepResult lowResult = f_processSweeps(false, lowest8, highest8)

newBearSweep := highResult.newBear
newBullSweep := lowResult.newBull

// Use the highest score from either direction
float sweepScoreLast = math.max(highResult.score, lowResult.score)

// ═══════════════════════════════════════════════════════════════════════════
// 14. CONFLUENCE SCORE (0-100)
// ═══════════════════════════════════════════════════════════════════════════

volBoost = math.max(volZ, 0.0)
exhScore = ta.ema(stretchImp + 0.8*stretchDay + 0.7*(uWick-lWick)/math.max(tr, syminfo.mintick) + 0.35*volBoost*math.sign(stretchImp), 5)
emaC = ta.ema(close, 34)
rocPct = ta.roc(emaC, 9)
curvature = -(rocPct - ta.ema(rocPct, 3)[1])
sfpScr = (bullSFP ? 1 : 0) - (bearSFP ? 1 : 0)
rawScore = 1.1*exhScore + 0.9*curvature + 1.2*sfpScr + (fvgBullNear ? 0.4 : 0.0) - (fvgBearNear ? 0.4 : 0.0)
compScore = 100.0 * f_tanh(rawScore)
prankScore = ta.percentrank(compScore, 250)

// ═══════════════════════════════════════════════════════════════════════════
// 15. MARKET REGIME DETECTION
// ═══════════════════════════════════════════════════════════════════════════

[dmi_plus, dmi_minus, adx_val] = ta.dmi(adxLen, adxLen)
atrAvg = ta.sma(atr14, 50)
bodyRatio = atr14 > 0 ? math.abs(close-open)/atr14 : 0.0

regimeTrend = adx_val >= adxTrMin
regimeRange = adx_val <= adxRgMax

string regimeLabel = regimeTrend ? "Trend" : regimeRange ? "Range" : "Transition"
color regimeColor = regimeTrend ? #22c55e : regimeRange ? #f59e0b : #94a3b8

// ═══════════════════════════════════════════════════════════════════════════
// 16. SIGNAL GENERATION + TRADE LEVEL LIFECYCLE
// ═══════════════════════════════════════════════════════════════════════════

var float entryPx = na
var float invalPx = na
var float ref1Px = na
var float ref2Px = na
var float ref3Px = na
var int   activeDir = 0
var int   activeSBar = na
var line  lnEntry = na
var line  lnInval = na
var line  lnRef1 = na
var line  lnRef2 = na
var line  lnRef3 = na
var label lbEntry = na
var label lbInval = na
var label lbRef1 = na
var label lbRef2 = na
var label lbRef3 = na
var box   refBox = na
var box   invalBox = na

colRef = color.rgb(0, 191, 255)
colInval = color.rgb(255, 82, 82)
colLabelB = color.new(#0f172a, 15)
labelOff = 22

f_computeInval(int dir, float ep, float atrR) =>
    float result = dir == 1 ? ep - slAtrM * atrR : ep + slAtrM * atrR
    if slMode == "Structural"
        wRef = dir == 1 ? (not na(lastPL) ? lastPL : na) : (not na(lastPH) ? lastPH : na)
        if not na(wRef)
            pad = slPadAtr * atrR
            cand = dir == 1 ? wRef - pad : wRef + pad
            dist = math.abs(ep - cand)
            dist := f_clamp(dist, 0.4 * atrR, 4.0 * atrR)
            result := dir == 1 ? ep - dist : ep + dist
    result

// Modified: clearLevels now takes objects as parameters
f_clearLevels(line lnEntry_in, line lnInval_in, line lnRef1_in, line lnRef2_in, line lnRef3_in,
              label lbEntry_in, label lbInval_in, label lbRef1_in, label lbRef2_in, label lbRef3_in,
              box refBox_in, box invalBox_in) =>
    line.delete(lnEntry_in)
    line.delete(lnInval_in)
    line.delete(lnRef1_in)
    line.delete(lnRef2_in)
    line.delete(lnRef3_in)
    label.delete(lbEntry_in)
    label.delete(lbInval_in)
    label.delete(lbRef1_in)
    label.delete(lbRef2_in)
    label.delete(lbRef3_in)
    box.delete(refBox_in)
    box.delete(invalBox_in)

// Modified: drawLevels now returns all created objects in a type
type TradeLevels
    line  lnEntry_out
    line  lnInval_out
    line  lnRef1_out
    line  lnRef2_out
    line  lnRef3_out
    label lbEntry_out
    label lbInval_out
    label lbRef1_out
    label lbRef2_out
    label lbRef3_out
    box   refBox_out
    box   invalBox_out

f_drawLevels(int dir, float entryPx_in, float invalPx_in, float ref1Px_in, float ref2Px_in, float ref3Px_in) =>
    xR = bar_index + labelOff
    dirCol = dir == 1 ? colLongSig : colShortSig
    line lnE = line.new(bar_index, entryPx_in, xR, entryPx_in, color=dirCol, width=2)
    line lnI = line.new(bar_index, invalPx_in, xR, invalPx_in, color=colInval, width=1, style=line.style_dotted)
    line lnR1 = line.new(bar_index, ref1Px_in, xR, ref1Px_in, color=colRef, width=1, style=line.style_dashed)
    line lnR2 = line.new(bar_index, ref2Px_in, xR, ref2Px_in, color=colRef, width=1, style=line.style_dashed)
    line lnR3 = line.new(bar_index, ref3Px_in, xR, ref3Px_in, color=colRef, width=1, style=line.style_dashed)
    label lbE = label.new(xR, entryPx_in, "Entry " + str.tostring(entryPx_in, format.mintick), 
                         style=label.style_label_left, color=colLabelB, textcolor=dirCol, size=size.small)
    label lbI = label.new(xR, invalPx_in, "SL " + str.tostring(invalPx_in, format.mintick), 
                         style=label.style_label_left, color=colLabelB, textcolor=colInval, size=size.small)
    label lbR1 = label.new(xR, ref1Px_in, "TP1 " + str.tostring(ref1Px_in, format.mintick), 
                        style=label.style_label_left, color=colLabelB, textcolor=colRef, size=size.small)
    label lbR2 = label.new(xR, ref2Px_in, "TP2 " + str.tostring(ref2Px_in, format.mintick), 
                        style=label.style_label_left, color=colLabelB, textcolor=colRef, size=size.small)
    label lbR3 = label.new(xR, ref3Px_in, "TP3 " + str.tostring(ref3Px_in, format.mintick), 
                        style=label.style_label_left, color=colLabelB, textcolor=colRef, size=size.small)
    
    box rBox = na
    box iBox = na
    if fillZns
        int zoneRefOp = 87
        int zoneInvOp = 87
        if dir == 1
            rBox := box.new(bar_index, ref3Px_in, xR, entryPx_in, bgcolor=color.new(colRef, zoneRefOp), border_color=na)
            iBox := box.new(bar_index, entryPx_in, xR, invalPx_in, bgcolor=color.new(colInval, zoneInvOp), border_color=na)
        else
            rBox := box.new(bar_index, entryPx_in, xR, ref3Px_in, bgcolor=color.new(colRef, zoneRefOp), border_color=na)
            iBox := box.new(bar_index, invalPx_in, xR, entryPx_in, bgcolor=color.new(colInval, zoneInvOp), border_color=na)
    
    TradeLevels.new(lnE, lnI, lnR1, lnR2, lnR3, lbE, lbI, lbR1, lbR2, lbR3, rBox, iBox)

trigLong = isConf and newBullSweep and activeDir == 0 and (prankScore <= 20 or sweepScoreLast >= 55)
trigShort = isConf and newBearSweep and activeDir == 0 and (prankScore >= 80 or sweepScoreLast >= 55)

if trigLong and showLvls
    f_clearLevels(lnEntry, lnInval, lnRef1, lnRef2, lnRef3, lbEntry, lbInval, lbRef1, lbRef2, lbRef3, refBox, invalBox)
    entryPx := close
    invalPx := f_computeInval(1, entryPx, atr14)
    float risk = entryPx - invalPx
    ref1Px := entryPx + rrTP1 * risk
    ref2Px := entryPx + rrTP2 * risk
    ref3Px := entryPx + rrTP3 * risk
    activeDir := 1
    activeSBar := bar_index
    TradeLevels tl = f_drawLevels(1, entryPx, invalPx, ref1Px, ref2Px, ref3Px)
    lnEntry := tl.lnEntry_out
    lnInval := tl.lnInval_out
    lnRef1 := tl.lnRef1_out
    lnRef2 := tl.lnRef2_out
    lnRef3 := tl.lnRef3_out
    lbEntry := tl.lbEntry_out
    lbInval := tl.lbInval_out
    lbRef1 := tl.lbRef1_out
    lbRef2 := tl.lbRef2_out
    lbRef3 := tl.lbRef3_out
    refBox := tl.refBox_out
    invalBox := tl.invalBox_out

if trigShort and showLvls
    f_clearLevels(lnEntry, lnInval, lnRef1, lnRef2, lnRef3, lbEntry, lbInval, lbRef1, lbRef2, lbRef3, refBox, invalBox)
    entryPx := close
    invalPx := f_computeInval(-1, entryPx, atr14)
    float risk = invalPx - entryPx
    ref1Px := entryPx - rrTP1 * risk
    ref2Px := entryPx - rrTP2 * risk
    ref3Px := entryPx - rrTP3 * risk
    activeDir := -1
    activeSBar := bar_index
    TradeLevels tl = f_drawLevels(-1, entryPx, invalPx, ref1Px, ref2Px, ref3Px)
    lnEntry := tl.lnEntry_out
    lnInval := tl.lnInval_out
    lnRef1 := tl.lnRef1_out
    lnRef2 := tl.lnRef2_out
    lnRef3 := tl.lnRef3_out
    lbEntry := tl.lbEntry_out
    lbInval := tl.lbInval_out
    lbRef1 := tl.lbRef1_out
    lbRef2 := tl.lbRef2_out
    lbRef3 := tl.lbRef3_out
    refBox := tl.refBox_out
    invalBox := tl.invalBox_out

closedBull = activeDir == 1 and not na(activeSBar) and bar_index > activeSBar and (high >= ref3Px or low <= invalPx)
closedBear = activeDir == -1 and not na(activeSBar) and bar_index > activeSBar and (low <= ref3Px or high >= invalPx)

if closedBull or closedBear
    if not na(lnEntry)
        lnEntry.set_x2(bar_index)
    if not na(lnRef1)
        lnRef1.set_x2(bar_index)
    if not na(lnRef2)
        lnRef2.set_x2(bar_index)
    if not na(lnRef3)
        lnRef3.set_x2(bar_index)
    if not na(lnInval)
        lnInval.set_x2(bar_index)
    if not na(refBox)
        refBox.set_right(bar_index)
    if not na(invalBox)
        invalBox.set_right(bar_index)
    label.delete(lbEntry)
    label.delete(lbRef1)
    label.delete(lbRef2)
    label.delete(lbRef3)
    label.delete(lbInval)
    lnEntry := na
    lnRef1 := na
    lnRef2 := na
    lnRef3 := na
    lnInval := na
    refBox := na
    invalBox := na
    activeDir := 0
    activeSBar := na

if activeDir != 0 and barstate.islast and showLvls
    xR = bar_index + labelOff
    if not na(lnEntry)
        lnEntry.set_x2(xR)
    if not na(lnRef1)
        lnRef1.set_x2(xR)
    if not na(lnRef2)
        lnRef2.set_x2(xR)
    if not na(lnRef3)
        lnRef3.set_x2(xR)
    if not na(lnInval)
        lnInval.set_x2(xR)
    if not na(refBox)
        refBox.set_right(xR)
    if not na(invalBox)
        invalBox.set_right(xR)
    if not na(lbEntry)
        lbEntry.set_x(xR)
    if not na(lbRef1)
        lbRef1.set_x(xR)
    if not na(lbRef2)
        lbRef2.set_x(xR)
    if not na(lbRef3)
        lbRef3.set_x(xR)
    if not na(lbInval)
        lbInval.set_x(xR)

// ═══════════════════════════════════════════════════════════════════════════
// 17.5 LIVE BACKTEST ENGINE (LOCAL TIMEFRAME)
// ═══════════════════════════════════════════════════════════════════════════

// Backtest state variables
var float btBalance = btInitCap
var float btEquity = btInitCap
var float btHighWatermark = btInitCap
var float btMaxDrawdown = 0.0
var float btDrawdownPct = 0.0
var int   btTotalTrades = 0
var int   btWinningTrades = 0
var int   btLosingTrades = 0
var float btWinRate = 0.0
var float btProfitFactor = 0.0
var float btTotalProfit = 0.0
var float btTotalLoss = 0.0
var float btAvgWin = 0.0
var float btAvgLoss = 0.0
var float btMaxWin = 0.0
var float btMaxLoss = 0.0
var float btAvgRR = 0.0
var float btSharpeRatio = 0.0
var float btReturnPct = 0.0
var int   btConsecWins = 0
var int   btConsecLosses = 0
var int   btMaxConsecWins = 0
var int   btMaxConsecLosses = 0
var int   btActiveTrade = 0  
var float btEntryPrice = na
var float btEntryBar = na
var float btSL = na
var float btTP = na
var float btPositionSize = na
var float btTradeRisk = na
var float btTradeReward = na
var float btLastTradePnL = 0.0
var string btLastTradeType = "-"
var float btLastTradeBars = 0
var string btLastTradeDate = "-"

// Array to store trade history for analysis
type BTTrade
    string type_str 
    float entry
    float exit
    float pnl
    float pnlPct
    int bars
    string entryDate
    string exitDate

var array<BTTrade> btTradeHistory = array.new<BTTrade>()

// Calculate slippage in price terms
f_slippage(float price, int dir) =>
    slipAmount = syminfo.mintick * btSlipPts
    dir == 1 ? price + slipAmount : price - slipAmount

// Close active trade if conditions met
if btActiveTrade != 0 and showBT
    bool tradeClosed = false
    float exitPrice = na
    string closeReason = ""
    
    if btActiveTrade == 1  // Long trade
        if low <= btSL
            exitPrice := btSL
            closeReason := "SL"
            tradeClosed := true
        else if high >= btTP
            exitPrice := btTP
            closeReason := "TP"
            tradeClosed := true
        else if newBearSweep and sweepScoreLast >= 55  // Reverse signal
            exitPrice := close
            closeReason := "Signal"
            tradeClosed := true
    else  // Short trade
        if high >= btSL
            exitPrice := btSL
            closeReason := "SL"
            tradeClosed := true
        else if low <= btTP
            exitPrice := btTP
            closeReason := "TP"
            tradeClosed := true
        else if newBullSweep and sweepScoreLast >= 55  // Reverse signal
            exitPrice := close
            closeReason := "Signal"
            tradeClosed := true
    
    if tradeClosed
        // Apply commission
        float commission = btPositionSize * btCommPer / 100
        
        // Calculate P&L
        float pnl = btActiveTrade == 1 ? 
             (exitPrice - btEntryPrice) * btPositionSize / btEntryPrice - commission :
             (btEntryPrice - exitPrice) * btPositionSize / btEntryPrice - commission
        
        float pnlPct = btActiveTrade == 1 ?
             ((exitPrice - btEntryPrice) / btEntryPrice * 100) - btCommPer :
             ((btEntryPrice - exitPrice) / btEntryPrice * 100) - btCommPer
        
        // Update balance
        btBalance += pnl
        btEquity := btBalance
        
        // Update high watermark and drawdown
        if btBalance > btHighWatermark
            btHighWatermark := btBalance
            btMaxDrawdown := 0.0
        else
            float currentDD = (btHighWatermark - btBalance) / btHighWatermark * 100
            if currentDD > btMaxDrawdown
                btMaxDrawdown := currentDD
        
        btDrawdownPct := (btHighWatermark - btBalance) / btHighWatermark * 100
        
        // Update trade statistics
        btTotalTrades += 1
        btLastTradePnL := pnl
        btLastTradeType := btActiveTrade == 1 ? "Long" : "Short"
        btLastTradeBars := bar_index - btEntryBar
        btLastTradeDate := str.format("{0,date,yyyy-MM-dd HH:mm}", time)
        
        if pnl > 0
            btWinningTrades += 1
            btTotalProfit += pnl
            btAvgWin := btTotalProfit / btWinningTrades
            if pnl > btMaxWin
                btMaxWin := pnl
            btConsecWins += 1
            btConsecLosses := 0
            if btConsecWins > btMaxConsecWins
                btMaxConsecWins := btConsecWins
        else
            btLosingTrades += 1
            btTotalLoss += math.abs(pnl)
            btAvgLoss := btTotalLoss / btLosingTrades
            if math.abs(pnl) > btMaxLoss
                btMaxLoss := math.abs(pnl)
            btConsecLosses += 1
            btConsecWins := 0
            if btConsecLosses > btMaxConsecLosses
                btMaxConsecLosses := btConsecLosses
        
        // Calculate metrics
        btWinRate := btTotalTrades > 0 ? float(btWinningTrades) / btTotalTrades * 100 : 0.0
        btProfitFactor := btTotalLoss > 0 ? btTotalProfit / btTotalLoss : btTotalProfit > 0 ? 999.0 : 0.0
        btAvgRR := btAvgLoss > 0 ? btAvgWin / btAvgLoss : 0.0
        btReturnPct := (btBalance - btInitCap) / btInitCap * 100
        
        // Add to trade history
        BTTrade trade = BTTrade.new(
            btActiveTrade == 1 ? "Long" : "Short",
            btEntryPrice,
            exitPrice,
            pnl,
            pnlPct,
            int(bar_index - btEntryBar),
            str.format("{0,date,yyyy-MM-dd HH:mm}", time[bar_index - btEntryBar]),
            str.format("{0,date,yyyy-MM-dd HH:mm}", time)
        )
        array.push(btTradeHistory, trade)
        if array.size(btTradeHistory) > 50
            array.shift(btTradeHistory)
        
        // Reset trade
        btActiveTrade := 0
        btEntryPrice := na
        btEntryBar := na
        btSL := na
        btTP := na
        btPositionSize := na
        btTradeRisk := na
        btTradeReward := na

// Open new trade
if showBT and btActiveTrade == 0 and isConf
    if trigLong and activeDir == 1
        btActiveTrade := 1
        btEntryPrice := f_slippage(close, 1)
        btEntryBar := bar_index
        btSL := invalPx
        btTP := ref3Px
        btTradeRisk := math.abs(btEntryPrice - btSL) / btEntryPrice * 100
        btTradeReward := math.abs(btTP - btEntryPrice) / btEntryPrice * 100
        btPositionSize := btBalance * (btRiskPer / 100) / (btTradeRisk / 100)
    else if trigShort and activeDir == -1
        btActiveTrade := -1
        btEntryPrice := f_slippage(close, -1)
        btEntryBar := bar_index
        btSL := invalPx
        btTP := ref3Px
        btTradeRisk := math.abs(btSL - btEntryPrice) / btEntryPrice * 100
        btTradeReward := math.abs(btEntryPrice - btTP) / btEntryPrice * 100
        btPositionSize := btBalance * (btRiskPer / 100) / (btTradeRisk / 100)

// Calculate Sharpe Ratio 
if bar_index > 0 and btTotalTrades > 0 and array.size(btTradeHistory) > 1
    float sumReturns = 0.0
    float sumSqReturns = 0.0
    int tradeCount = 0
    
    for i = 0 to array.size(btTradeHistory) - 1
        BTTrade t = array.get(btTradeHistory, i)
        sumReturns += t.pnlPct
        sumSqReturns += t.pnlPct * t.pnlPct
        tradeCount += 1
    
    if tradeCount > 1
        float meanReturn = sumReturns / tradeCount
        float variance = (sumSqReturns - (sumReturns * sumReturns / tradeCount)) / (tradeCount - 1)
        float stdDev = math.sqrt(math.max(variance, 0.0))
        btSharpeRatio := stdDev > 0 ? (meanReturn / stdDev) * math.sqrt(tradeCount) : 0.0

// =============================================================================
// 17.6 MULTI-TIMEFRAME ENGINE WRAPPER (SANDBOX)
// =============================================================================
f_calc_bt_tf() =>
    atr14_fn = ta.atr(14)
    volMa_fn = ta.sma(volume, volMaLen)
    volZ_fn = f_z(volume, 50)
    ema200_fn = ta.ema(close, 200)
    lowest8_fn = ta.lowest(low, 8)[1]
    highest8_fn = ta.highest(high, 8)[1]
    int dummy = 0 
    
    var float[] hMid_fn = array.new_float(0)
    var float[] lMid_fn = array.new_float(0)
    var float[] hTop_fn = array.new_float(0)
    var float[] lTop_fn = array.new_float(0)
    var float[] hBot_fn = array.new_float(0)
    var float[] lBot_fn = array.new_float(0)
    var int[]   hSt_fn  = array.new_int(0)
    var int[]   lSt_fn  = array.new_int(0)
    var int[]   hHits_fn = array.new_int(0)
    var int[]   lHits_fn = array.new_int(0)
    var int[]   hBar_fn = array.new_int(0)
    var int[]   lBar_fn = array.new_int(0)

    ph_sw_fn = ta.pivothigh(swingLen, swingLen)
    pl_sw_fn = ta.pivotlow(swingLen, swingLen)
    
    if not na(ph_sw_fn)
        half = math.max(nz(atr14_fn[swingLen], atr14_fn) * poolAtr, syminfo.mintick * 5)
        mergeB = math.max(nz(atr14_fn[swingLen], atr14_fn) * mergeAtr, syminfo.mintick * 8)
        price = high[swingLen]
        near = -1
        bestD = 10e10
        if array.size(hMid_fn) > 0
            for i = 0 to array.size(hMid_fn)-1
                if array.get(hSt_fn, i) < 2
                    d = math.abs(price - array.get(hMid_fn, i))
                    if d <= mergeB and d < bestD
                        bestD := d
                        near := i
        if near == -1
            array.push(hMid_fn, price)
            array.push(hTop_fn, price+half)
            array.push(hBot_fn, price-half)
            array.push(hSt_fn, 0)
            array.push(hHits_fn, 1)
            array.push(hBar_fn, bar_index)
            while array.size(hMid_fn) > 14
                array.shift(hMid_fn)
                array.shift(hTop_fn)
                array.shift(hBot_fn)
                array.shift(hSt_fn)
                array.shift(hHits_fn)
                array.shift(hBar_fn)
            dummy_val = 0
        else
            oldMid = array.get(hMid_fn, near)
            oldHits = array.get(hHits_fn, near)
            nHits = oldHits + 1
            nMid = (oldMid * oldHits + price) / nHits
            nHalf = math.max(nz(atr14_fn[swingLen], atr14_fn) * poolAtr * (1 + math.min(nHits, 8) * 0.05), syminfo.mintick * 5)
            array.set(hMid_fn, near, nMid)
            array.set(hTop_fn, near, nMid + nHalf)
            array.set(hBot_fn, near, nMid - nHalf)
            array.set(hHits_fn, near, nHits)
            dummy_val = 0

    if not na(pl_sw_fn)
        half = math.max(nz(atr14_fn[swingLen], atr14_fn) * poolAtr, syminfo.mintick * 5)
        mergeB = math.max(nz(atr14_fn[swingLen], atr14_fn) * mergeAtr, syminfo.mintick * 8)
        price = low[swingLen]
        near = -1
        bestD = 10e10
        if array.size(lMid_fn) > 0
            for i = 0 to array.size(lMid_fn)-1
                if array.get(lSt_fn, i) < 2
                    d = math.abs(price - array.get(lMid_fn, i))
                    if d <= mergeB and d < bestD
                        bestD := d
                        near := i
        if near == -1
            array.push(lMid_fn, price)
            array.push(lTop_fn, price+half)
            array.push(lBot_fn, price-half)
            array.push(lSt_fn, 0)
            array.push(lHits_fn, 1)
            array.push(lBar_fn, bar_index)
            while array.size(lMid_fn) > 14
                array.shift(lMid_fn)
                array.shift(lTop_fn)
                array.shift(lBot_fn)
                array.shift(lSt_fn)
                array.shift(lHits_fn)
                array.shift(lBar_fn)
            dummy_val = 0
        else
            oldMid = array.get(lMid_fn, near)
            oldHits = array.get(lHits_fn, near)
            nHits = oldHits + 1
            nMid = (oldMid * oldHits + price) / nHits
            nHalf = math.max(nz(atr14_fn[swingLen], atr14_fn) * poolAtr * (1 + math.min(nHits, 8) * 0.05), syminfo.mintick * 5)
            array.set(lMid_fn, near, nMid)
            array.set(lTop_fn, near, nMid + nHalf)
            array.set(lBot_fn, near, nMid - nHalf)
            array.set(lHits_fn, near, nHits)
            dummy_val = 0

    bool newBullSweep_fn = false
    bool newBearSweep_fn = false
    float scoreBear_fn = 0.0
    float scoreBull_fn = 0.0

    if array.size(hMid_fn) > 0
        for i = array.size(hMid_fn)-1 to 0
            mid  = array.get(hMid_fn, i)
            top  = array.get(hTop_fn, i)
            st   = array.get(hSt_fn, i)
            stBar= array.get(hBar_fn, i)
            age  = bar_index - stBar
            if age > 1800 or (st == 2)
                array.remove(hMid_fn, i)
                array.remove(hTop_fn, i)
                array.remove(hBot_fn, i)
                array.remove(hSt_fn, i)
                array.remove(hHits_fn, i)
                array.remove(hBar_fn, i)
                dummy := 0  
            else
                if st < 2
                    sweepRaw = (high > top and close < mid)
                    if sweepRaw and st == 0
                        float penatr = atr14_fn > 0 ? math.max(high-top, 0)/atr14_fn : 0.0
                        float reclaimPct = high > low ? (high-close)/(high-low)*100 : 0.0
                        bool bodyOk = close < open
                        float bAbs = math.abs(close-open)
                        float wk = high - math.max(open, close)
                        float wickRatio = wk / math.max(bAbs, syminfo.mintick)
                        float mssRef = lowest8_fn
                        float rangeAtr = atr14_fn > 0 ? (high - low)/atr14_fn : 0.0
                        float volRatio = not na(volMa_fn) and volMa_fn > 0 ? volume/volMa_fn : na
                        baseW = scorePen * f_scorePenetration(penatr) + scoreReclaim * f_scoreReclaim(reclaimPct) + scoreWick * f_scoreWick(wickRatio) + scoreBody * (bodyOk ? 1.0 : 0.3) + scoreEma * f_scoreEMA(-1, close, ema200_fn, atr14_fn) + scoreLen * f_norm01(float(age), 0.0, 50.0)
                        mssScore = f_scoreMSS(-1, mssRef, close, atr14_fn)
                        effScore = f_scoreEffort(rangeAtr, volRatio)
                        fScore = f_totalScore(baseW, mssScore, effScore)
                        if not actScor or fScore >= minScore
                            array.set(hSt_fn, i, 1)
                            scoreBear_fn := fScore
                            newBearSweep_fn := true
                    if close > top
                        array.set(hSt_fn, i, 2)
                dummy := 0  

    if array.size(lMid_fn) > 0
        for i = array.size(lMid_fn)-1 to 0
            mid  = array.get(lMid_fn, i)
            bot  = array.get(lBot_fn, i)
            st   = array.get(lSt_fn, i)
            stBar= array.get(lBar_fn, i)
            age  = bar_index - stBar
            if age > 1800 or (st == 2)
                array.remove(lMid_fn, i)
                array.remove(lTop_fn, i)
                array.remove(lBot_fn, i)
                array.remove(lSt_fn, i)
                array.remove(lHits_fn, i)
                array.remove(lBar_fn, i)
                dummy := 0  
            else
                if st < 2
                    sweepRaw = (low < bot and close > mid)
                    if sweepRaw and st == 0
                        float penatr = atr14_fn > 0 ? math.max(bot-low, 0)/atr14_fn : 0.0
                        float reclaimPct = high > low ? (close-low)/(high-low)*100 : 0.0
                        bool bodyOk = close > open
                        float bAbs = math.abs(close-open)
                        float wk = math.min(open, close) - low
                        float wickRatio = wk / math.max(bAbs, syminfo.mintick)
                        float mssRef = highest8_fn
                        float rangeAtr = atr14_fn > 0 ? (high - low)/atr14_fn : 0.0
                        float volRatio = not na(volMa_fn) and volMa_fn > 0 ? volume/volMa_fn : na
                        baseW = scorePen * f_scorePenetration(penatr) + scoreReclaim * f_scoreReclaim(reclaimPct) + scoreWick * f_scoreWick(wickRatio) + scoreBody * (bodyOk ? 1.0 : 0.3) + scoreEma * f_scoreEMA(1, close, ema200_fn, atr14_fn) + scoreLen * f_norm01(float(age), 0.0, 50.0)
                        mssScore = f_scoreMSS(1, mssRef, close, atr14_fn)
                        effScore = f_scoreEffort(rangeAtr, volRatio)
                        fScore = f_totalScore(baseW, mssScore, effScore)
                        if not actScor or fScore >= minScore
                            array.set(lSt_fn, i, 1)
                            scoreBull_fn := fScore
                            newBullSweep_fn := true
                    if close < bot
                        array.set(lSt_fn, i, 2)
                dummy := 0  

    sweepScoreLast_fn = math.max(scoreBear_fn, scoreBull_fn)
    volBoost_fn = math.max(volZ_fn, 0.0)
    tr_fn = ta.tr
    uWick_fn = high - math.max(open, close)
    lWick_fn = math.min(open, close) - low
    stretchImp_fn = (close - (ta.ema(close * volume, anchorN) / ta.ema(volume, anchorN))) / math.max(atr14_fn, syminfo.mintick)
    stretchDay_fn = (close - (ta.ema(close * volume, 50) / ta.ema(volume, 50))) / math.max(atr14_fn, syminfo.mintick)
    exhScore_fn = ta.ema(stretchImp_fn + 0.8*stretchDay_fn + 0.7*(uWick_fn-lWick_fn)/math.max(tr_fn, syminfo.mintick) + 0.35*volBoost_fn*math.sign(stretchImp_fn), 5)
    emaC_fn = ta.ema(close, 34)
    rocPct_fn = ta.roc(emaC_fn, 9)
    curvature_fn = -(rocPct_fn - ta.ema(rocPct_fn, 3)[1])
    rawScore_fn = 1.1*exhScore_fn + 0.9*curvature_fn
    compScore_fn = 100.0 * f_tanh(rawScore_fn)
    prankScore_fn = ta.percentrank(compScore_fn, 250)

    bool bearSFP_fn = not na(highest8_fn) and high > highest8_fn and close < highest8_fn and tr_fn>0 and (uWick_fn/tr_fn) >= wickTh
    bool bullSFP_fn = not na(lowest8_fn) and low < lowest8_fn and close > lowest8_fn and tr_fn>0 and (lWick_fn/tr_fn) >= wickTh

    trigLong_fn = newBullSweep_fn and (prankScore_fn <= 20 or sweepScoreLast_fn >= 55)
    trigShort_fn = newBearSweep_fn and (prankScore_fn >= 80 or sweepScoreLast_fn >= 55)

    var float lastPL_fn = na
    var float lastPH_fn = na
    if bullSFP_fn
        lastPL_fn := low
    if bearSFP_fn
        lastPH_fn := high

    var float bal = btInitCap
    var float highWater = btInitCap
    var float maxDD = 0.0
    var int   totTrades = 0
    var int   winTrades = 0
    var int   losTrades = 0
    var float totProfit = 0.0
    var float totLoss = 0.0
    
    var int   activeTr = 0
    var float entPrice = na
    var float slPrice = na
    var float tpPrice = na
    var float pSize = na
    
    var float[] retHistory = array.new_float(0)
    if array.size(retHistory) > 100
        array.shift(retHistory)

    // Execute exits
    if activeTr != 0
        tradeClosed = false
        float exitPrice = na
        if activeTr == 1
            if low <= slPrice
                exitPrice := slPrice
                tradeClosed := true
            else if high >= tpPrice
                exitPrice := tpPrice
                tradeClosed := true
            else if trigShort_fn and sweepScoreLast_fn >= 55
                exitPrice := close
                tradeClosed := true
        else
            if high >= slPrice
                exitPrice := slPrice
                tradeClosed := true
            else if low <= tpPrice
                exitPrice := tpPrice
                tradeClosed := true
            else if trigLong_fn and sweepScoreLast_fn >= 55
                exitPrice := close
                tradeClosed := true
        
        if tradeClosed
            commission = pSize * btCommPer / 100
            pnl = activeTr == 1 ? 
                 (exitPrice - entPrice) * pSize / entPrice - commission :
                 (entPrice - exitPrice) * pSize / entPrice - commission
            
            pnlPct = activeTr == 1 ?
                 ((exitPrice - entPrice) / entPrice * 100) - btCommPer :
                 ((entPrice - exitPrice) / entPrice * 100) - btCommPer
            
            bal := bal + pnl
            if bal > highWater
                highWater := bal
            else
                currDD = (highWater - bal) / highWater * 100
                if currDD > maxDD
                    maxDD := currDD
            
            totTrades := totTrades + 1
            array.push(retHistory, pnlPct)
            if pnl > 0
                winTrades := winTrades + 1
                totProfit := totProfit + pnl
            else
                losTrades := losTrades + 1
                totLoss := totLoss + math.abs(pnl)
            
            activeTr := 0
            entPrice := na
            slPrice := na
            tpPrice := na
            pSize := na

    // Execute entries
    if activeTr == 0
        if trigLong_fn and not na(atr14_fn) and atr14_fn > 0
            activeTr := 1
            entPrice := close + (syminfo.mintick * btSlipPts)
            sl_dist = slMode == "Structural" and not na(lastPL_fn) ? 
                 math.max(math.abs(entPrice - (lastPL_fn - slPadAtr * atr14_fn)), 0.4 * atr14_fn) : 
                 slAtrM * atr14_fn
            slPrice := entPrice - sl_dist
            tpPrice := entPrice + rrTP3 * sl_dist
            tradeRisk = math.abs(entPrice - slPrice) / entPrice * 100
            pSize := tradeRisk > 0 ? bal * (btRiskPer / 100) / (tradeRisk / 100) : 0.0
            
        else if trigShort_fn and not na(atr14_fn) and atr14_fn > 0
            activeTr := -1
            entPrice := close - (syminfo.mintick * btSlipPts)
            sl_dist = slMode == "Structural" and not na(lastPH_fn) ? 
                 math.max(math.abs((lastPH_fn + slPadAtr * atr14_fn) - entPrice), 0.4 * atr14_fn) : 
                 slAtrM * atr14_fn
            slPrice := entPrice + sl_dist
            tpPrice := entPrice - rrTP3 * sl_dist
            tradeRisk = math.abs(slPrice - entPrice) / entPrice * 100
            pSize := tradeRisk > 0 ? bal * (btRiskPer / 100) / (tradeRisk / 100) : 0.0

    winRate = totTrades > 0 ? float(winTrades) / totTrades * 100 : 0.0
    profitFactor = totLoss > 0 ? totProfit / totLoss : totProfit > 0 ? 999.0 : 0.0
    netProfitPct = ((bal - btInitCap) / btInitCap) * 100
    
    sharpe = 0.0
    if totTrades > 1 and array.size(retHistory) > 1
        float sumRet = 0.0
        float sumSqRet = 0.0
        for k = 0 to array.size(retHistory) - 1
            r_val = array.get(retHistory, k)
            sumRet += r_val
            sumSqRet += r_val * r_val
        meanR = sumRet / totTrades
        variance = (sumSqRet - (sumRet * sumRet / totTrades)) / (totTrades - 1)
        stdD = math.sqrt(math.max(variance, 0.0))
        sharpe := stdD > 0 ? (meanR / stdD) * math.sqrt(totTrades) : 0.0

    [float(totTrades), float(winTrades), float(losTrades), profitFactor, winRate, netProfitPct, maxDD, sharpe]

// ═══════════════════════════════════════════════════════════════════════════
// 17.6 PARALLEL SECURITY REQUESTS (NON-REPAINTING)
// ═══════════════════════════════════════════════════════════════════════════
[t_1m, w_1m, l_1m, pf_1m, wr_1m, np_1m, dd_1m, sh_1m] = request.security(syminfo.tickerid, "1", f_calc_bt_tf(), barmerge.gaps_off, barmerge.lookahead_off)
[t_3m, w_3m, l_3m, pf_3m, wr_3m, np_3m, dd_3m, sh_3m] = request.security(syminfo.tickerid, "3", f_calc_bt_tf(), barmerge.gaps_off, barmerge.lookahead_off)
[t_5m, w_5m, l_5m, pf_5m, wr_5m, np_5m, dd_5m, sh_5m] = request.security(syminfo.tickerid, "5", f_calc_bt_tf(), barmerge.gaps_off, barmerge.lookahead_off)
[t_15m, w_15m, l_15m, pf_15m, wr_15m, np_15m, dd_15m, sh_15m] = request.security(syminfo.tickerid, "15", f_calc_bt_tf(), barmerge.gaps_off, barmerge.lookahead_off)
[t_1h, w_1h, l_1h, pf_1h, wr_1h, np_1h, dd_1h, sh_1h] = request.security(syminfo.tickerid, "60", f_calc_bt_tf(), barmerge.gaps_off, barmerge.lookahead_off)

// ═══════════════════════════════════════════════════════════════════════════
// 18. SIGNAL LABELS & SHAPES (FULLY CUSTOMIZABLE)
// ═══════════════════════════════════════════════════════════════════════════

// Customized Color Engine based on selected signal colors and score scaling
scoreColor(int dir, float sc, color cLong, color cShort) =>
    if dir == 1
        sc >= 80 ? cLong : sc >= 60 ? color.new(cLong, 15) : sc >= 40 ? #f59e0b : color.new(cLong, 40)
    else
        sc >= 80 ? cShort : sc >= 60 ? color.new(cShort, 15) : sc >= 40 ? #f59e0b : color.new(cShort, 40)

var array<label> trigLbls = array.new<label>()

if (trigLong or trigShort) and barstate.isconfirmed
    dir = trigLong ? 1 : -1
    tag = (dir == 1 ? "▲ LONG" : "▼ SHORT") + "\nScore: " + str.tostring(sweepScoreLast, "#.0") + 
          " | PR: " + str.tostring(prankScore, "#.0")
    sc = scoreColor(dir, sweepScoreLast, colLongSig, colShortSig) // FIXED: Uses direct direction mapping
    yy = dir == 1 ? low - atr14*0.6 : high + atr14*0.6
    sy = dir == 1 ? label.style_label_up : label.style_label_down
    lb = label.new(bar_index, yy, tag, style=sy, color=color.new(sc, 10), 
                   textcolor=color.white, size=size.small)
    array.push(trigLbls, lb)
    while array.size(trigLbls) > 60
        label.delete(array.shift(trigLbls))

// ═══════════════════════════════════════════════════════════════════════════
// 19. CONTEXT PLOTS
// ═══════════════════════════════════════════════════════════════════════════

plot(showAVWP ? impAVWAP : na, "Impulse AVWAP", color=colAVWP, linewidth=2)
plot(showDAVW ? dAVWAP : na, "Daily AVWAP", color=color.new(#22d3ee, 0), linewidth=2, style=plot.style_linebr)

// ═══════════════════════════════════════════════════════════════════════════
// 20. DASHBOARD (DYNAMIC SIZE CAPABILITIES)
// ═══════════════════════════════════════════════════════════════════════════

var table dash = na

f_cell(int c, int r, string txt, color tc, color bg, string sz) =>
    table.cell(dash, c, r, txt, text_color=tc, bgcolor=bg, text_size=sz)

// Helper formatting function to avoid NaN crashes
f_fmt_v(float val, string format_str, string fallback="-") =>
    na(val) ? fallback : str.tostring(val, format_str)

f_color_winrate(float val) =>
    na(val) ? color.white : (val >= 60.0 ? color.rgb(0, 230, 118) : (val >= 40.0 ? color.rgb(255, 215, 0) : color.rgb(255, 23, 68)))

f_color_pf(float val) =>
    na(val) ? color.white : (val >= 1.75 ? color.rgb(0, 230, 118) : (val >= 1.20 ? color.rgb(255, 215, 0) : color.rgb(255, 23, 68)))

f_color_sharpe(float val) =>
    na(val) ? color.white : (val >= 1.50 ? color.rgb(0, 230, 118) : (val >= 0.75 ? color.rgb(255, 215, 0) : color.rgb(255, 23, 68)))

f_color_dd(float val) =>
    na(val) ? color.white : (val < 10.0 ? color.rgb(0, 230, 118) : (val <= 20.0 ? color.rgb(255, 215, 0) : color.rgb(255, 23, 68)))

sweptBSL = bslSz > 0 ? array.get(bslList, 0).broken : false
sweptSSL = sslSz > 0 ? array.get(sslList, 0).broken : false
liveScoreTag = scoreTag(sweepScoreLast)
liveScoreCol = scoreColor(activeDir == 0 ? (trigLong ? 1 : trigShort ? -1 : 1) : activeDir, sweepScoreLast, colLongSig, colShortSig)
stateStr = activeDir == 1 ? "🟢 Long Active" : activeDir == -1 ? "🔴 Short Active" : 
           trigLong ? "⚡ LONG Trigger" : trigShort ? "⚡ SHORT Trigger" : "⏳ Idle"

if dashMode != "Off" and barstate.islast
    cols = dashMode == "Pro" ? 6 : 2  
    rows = dashMode == "Pro" ? 22 : 8 
    if na(dash)
        dash := table.new(f_dashPos(), cols, rows, bgcolor=color.new(#0f172a, 8), 
                          border_color=color.new(#334155, 20), frame_color=color.new(#334155, 30), 
                          border_width=1, frame_width=1)
    
    hdrBg = color.new(#1e293b, 0)
    rowBg = color.new(#0f172a, 30)
    white = color.white
    gray = color.new(color.white, 50)
    
    // Dynamic text size mapping
    sz = f_getDashSize(dashSize)
    szT = dashSize == "Large" ? size.normal : dashSize == "Normal" ? size.small : size.tiny
    
    // Header
    table.merge_cells(dash, 0, 0, cols-1, 0)
    table.cell(dash, 0, 0, "⚡ ULTIMATE LIQUIDITY INTEL — " + syminfo.ticker + " | " + timeframe.period, 
               text_color=white, bgcolor=hdrBg, text_size=sz)
    
    // SECTION 1: LIVE PERFORMANCE STATUS (TOP SECTION)
    f_cell(0, 1, "Regime", gray, rowBg, sz)
    f_cell(1, 1, regimeLabel, regimeColor, color.new(regimeColor, 80), sz)
    if dashMode == "Pro"
        f_cell(2, 1, "ADX: " + str.tostring(adx_val, "#.0"), gray, rowBg, sz)
        table.merge_cells(dash, 3, 1, 5, 1)
        f_cell(3, 1, "", gray, rowBg, sz)
    
    f_cell(0, 2, "Live Score", gray, rowBg, sz)
    f_cell(1, 2, str.tostring(sweepScoreLast, "#.0") + " | " + liveScoreTag, liveScoreCol, color.new(liveScoreCol, 75), sz)
    if dashMode == "Pro"
        f_cell(2, 2, "PR: " + str.tostring(prankScore, "#.0") + "%", gray, rowBg, sz)
        table.merge_cells(dash, 3, 2, 5, 2)
        f_cell(3, 2, "", gray, rowBg, sz)
    
    f_cell(0, 3, "Signal State", gray, rowBg, sz)
    statCol = activeDir == 1 ? colLongSig : activeDir == -1 ? colShortSig : color.new(white, 50)
    f_cell(1, 3, stateStr, statCol, color.new(statCol, 82), sz)
    if dashMode == "Pro"
        f_cell(2, 3, "Bars In: " + (activeDir != 0 and not na(activeSBar) ? str.tostring(bar_index-activeSBar) : "-"), gray, rowBg, sz)
        table.merge_cells(dash, 3, 3, 5, 3)
        f_cell(3, 3, "", gray, rowBg, sz)
    
    f_cell(0, 4, "PDH | PDL", gray, rowBg, sz)
    f_cell(1, 4, (pdhOk ? str.tostring(pdh, format.mintick) : "--") + " | " + (pdlOk ? str.tostring(pdl, format.mintick) : "--"), white, rowBg, sz)
    if dashMode == "Pro"
        f_cell(2, 4, "PWH: " + (pwhOk ? str.tostring(pwh, format.mintick) : "--"), white, rowBg, sz)
        table.merge_cells(dash, 3, 4, 5, 4)
        f_cell(3, 4, "", gray, rowBg, sz)
    
    bslMid = bslSz > 0 ? array.get(bslList, 0).core.get_top() - atr14/margin_atr : na
    sslMid = sslSz > 0 ? array.get(sslList, 0).core.get_bottom() + atr14/margin_atr : na
    f_cell(0, 5, "BSL | SSL", gray, rowBg, sz)
    f_cell(1, 5, (na(bslMid) ? "--" : str.tostring(bslMid, format.mintick) + " " + (sweptBSL ? "✓" : "")) + " | " + 
                 (na(sslMid) ? "--" : str.tostring(sslMid, format.mintick) + " " + (sweptSSL ? "✓" : "")), white, rowBg, szT)
    if dashMode == "Pro"
        f_cell(2, 5, "Zones: " + str.tostring(bslSz) + "/" + str.tostring(sslSz), gray, rowBg, sz)
        table.merge_cells(dash, 3, 5, 5, 5)
        f_cell(3, 5, "", gray, rowBg, sz)
    
    f_cell(0, 6, "Imp AVWAP", gray, rowBg, sz)
    f_cell(1, 6, str.tostring(impAVWAP, format.mintick) + " | Δ " + str.tostring(stretchImp, "#.00") + "σ", 
           stretchImp > 0 ? colShortSig : colLongSig, rowBg, szT)
    if dashMode == "Pro"
        f_cell(2, 6, "Day Δ " + str.tostring(stretchDay, "#.00") + "σ", gray, rowBg, sz)
        table.merge_cells(dash, 3, 6, 5, 6)
        f_cell(3, 6, "", gray, rowBg, sz)
    
    f_cell(0, 7, "FVG", gray, rowBg, sz)
    fvgTxt = fvgBullNear ? "🟢 Bull FVG Nearby" : fvgBearNear ? "🔴 Bear FVG Nearby" : "None"
    fvgCol = fvgBullNear ? colLongSig : fvgBearNear ? colShortSig : color.new(white, 50)
    f_cell(1, 7, fvgTxt, fvgCol, rowBg, sz)
    if dashMode == "Pro"
        f_cell(2, 7, "MS Trend: " + (msTrend == 1 ? "▲ Bull" : msTrend == -1 ? "▼ Bear" : "Neutral"), 
               msTrend == 1 ? colLongSig : msTrend == -1 ? colShortSig : gray, rowBg, sz)
        table.merge_cells(dash, 3, 7, 5, 7)
        f_cell(3, 7, "", gray, rowBg, sz)
    
    if dashMode == "Pro"
        f_cell(0, 8, "SFP", gray, rowBg, sz)
        f_cell(1, 8, bullSFP ? "🟢 Bullish SFP" : bearSFP ? "🔴 Bearish SFP" : "--", 
               bullSFP ? colLongSig : bearSFP ? colShortSig : gray, rowBg, sz)
        f_cell(2, 8, "Key: " + (isKeySFP ? "✓ YES" : "—"), isKeySFP ? #f59e0b : gray, rowBg, sz)
        table.merge_cells(dash, 3, 8, 5, 8)
        f_cell(3, 8, "", gray, rowBg, sz)
        
        f_cell(0, 9, "Volume Z", gray, rowBg, sz)
        f_cell(1, 9, str.tostring(volZ, "#.00") + " " + (volZ > 2 ? "🔥 Spike" : volZ > 1 ? "↑ High" : "Normal"), 
               volZ > 2 ? #f59e0b : volZ > 1 ? colLongSig : gray, rowBg, sz)
        f_cell(2, 9, "Ratio: " + str.tostring(not na(volMa) and volMa > 0 ? volume/volMa : 0, "#.0") + "x", gray, rowBg, sz)
        table.merge_cells(dash, 3, 9, 5, 9)
        f_cell(3, 9, "", gray, rowBg, sz)
        
        f_cell(0, 10, "Session", gray, rowBg, sz)
        sessTxt = nowNY ? "🗽 New York" : nowLon ? "🇬🇧 London" : nowAsia ? "🏯 Asian" : "Off-Hours"
        sessCol = nowNY ? colNY : nowLon ? color.new(#ffd700, 0) : nowAsia ? colAsia : gray
        f_cell(1, 10, sessTxt, sessCol, rowBg, sz)
        f_cell(2, 10, inSess ? "🟢 High Liq" : "⚪ Low Liq", inSess ? colLongSig : gray, rowBg, sz)
        table.merge_cells(dash, 3, 10, 5, 10)
        f_cell(3, 10, "", gray, rowBg, sz)
        
        f_cell(0, 11, "Trade Levels", gray, rowBg, sz)
        levTxt = activeDir != 0 and not na(entryPx) ? "E:" + str.tostring(entryPx, format.mintick) + 
                 " SL:" + str.tostring(invalPx, format.mintick) : "No Active Trade"
        f_cell(1, 11, levTxt, white, rowBg, szT)
        f_cell(2, 11, activeDir != 0 ? "TP3: " + str.tostring(ref3Px, format.mintick) : "—", colRef, rowBg, szT)
        table.merge_cells(dash, 3, 11, 5, 11)
        f_cell(3, 11, "", gray, rowBg, sz)
        
        // ═══════════════════════════════════════════════
        // SECTION 2: MULTI-TIMEFRAME BACKTEST MATRIX
        // ═══════════════════════════════════════════════
        
        // Row 12: Section Title
        table.merge_cells(dash, 0, 12, 5, 12)
        f_cell(0, 12, "📈 MULTI-TIMEFRAME BACKTEST MATRIX", color.new(color.orange, 20), white, szT)
        
        // Row 13: Columns Headers
        f_cell(0, 13, "Metric", gray, rowBg, szT)
        f_cell(1, 13, "1m", color.orange, rowBg, szT)
        f_cell(2, 13, "3m", color.orange, rowBg, szT)
        f_cell(3, 13, "5m", color.orange, rowBg, szT)
        f_cell(4, 13, "15m", color.orange, rowBg, szT)
        f_cell(5, 13, "1H", color.orange, rowBg, szT)
        
        // Row 14: Total Trades
        f_cell(0, 14, "Total Trades", gray, rowBg, szT)
        f_cell(1, 14, f_fmt_v(t_1m, "0"), white, rowBg, szT)
        f_cell(2, 14, f_fmt_v(t_3m, "0"), white, rowBg, szT)
        f_cell(3, 14, f_fmt_v(t_5m, "0"), white, rowBg, szT)
        f_cell(4, 14, f_fmt_v(t_15m, "0"), white, rowBg, szT)
        f_cell(5, 14, f_fmt_v(t_1h, "0"), white, rowBg, szT)
        
        // Row 15: Wins/Losses
        f_cell(0, 15, "Wins/Losses", gray, rowBg, szT)
        f_cell(1, 15, na(t_1m) ? "-" : f_fmt_v(w_1m, "0") + "/" + f_fmt_v(l_1m, "0"), white, rowBg, szT)
        f_cell(2, 15, na(t_3m) ? "-" : f_fmt_v(w_3m, "0") + "/" + f_fmt_v(l_3m, "0"), white, rowBg, szT)
        f_cell(3, 15, na(t_5m) ? "-" : f_fmt_v(w_5m, "0") + "/" + f_fmt_v(l_5m, "0"), white, rowBg, szT)
        f_cell(4, 15, na(t_15m) ? "-" : f_fmt_v(w_15m, "0") + "/" + f_fmt_v(l_15m, "0"), white, rowBg, szT)
        f_cell(5, 15, na(t_1h) ? "-" : f_fmt_v(w_1h, "0") + "/" + f_fmt_v(l_1h, "0"), white, rowBg, szT)
        
        // Row 16: Profit Factor
        f_cell(0, 16, "Profit Factor", gray, rowBg, szT)
        f_cell(1, 16, f_fmt_v(pf_1m, "0.00"), f_color_pf(pf_1m), rowBg, szT)
        f_cell(2, 16, f_fmt_v(pf_3m, "0.00"), f_color_pf(pf_3m), rowBg, szT)
        f_cell(3, 16, f_fmt_v(pf_5m, "0.00"), f_color_pf(pf_5m), rowBg, szT)
        f_cell(4, 16, f_fmt_v(pf_15m, "0.00"), f_color_pf(pf_15m), rowBg, szT)
        f_cell(5, 16, f_fmt_v(pf_1h, "0.00"), f_color_pf(pf_1h), rowBg, szT)
        
        // Row 17: Win Rate (%)
        f_cell(0, 17, "Win Rate (%)", gray, rowBg, szT)
        f_cell(1, 17, na(wr_1m) ? "-" : f_fmt_v(wr_1m, "0.0") + "%", f_color_winrate(wr_1m), rowBg, szT)
        f_cell(2, 17, na(wr_3m) ? "-" : f_fmt_v(wr_3m, "0.0") + "%", f_color_winrate(wr_3m), rowBg, szT)
        f_cell(3, 17, na(wr_5m) ? "-" : f_fmt_v(wr_5m, "0.0") + "%", f_color_winrate(wr_5m), rowBg, szT)
        f_cell(4, 17, na(wr_15m) ? "-" : f_fmt_v(wr_15m, "0.0") + "%", f_color_winrate(wr_15m), rowBg, szT)
        f_cell(5, 17, na(wr_1h) ? "-" : f_fmt_v(wr_1h, "0.0") + "%", f_color_winrate(wr_1h), rowBg, szT)
        
        // Row 18: Net Profit (%)
        f_cell(0, 18, "Net Profit (%)", gray, rowBg, szT)
        f_cell(1, 18, na(np_1m) ? "-" : f_fmt_v(np_1m, "0.0") + "%", np_1m >= 0 ? colLongSig : colShortSig, rowBg, szT)
        f_cell(2, 18, na(np_3m) ? "-" : f_fmt_v(np_3m, "0.0") + "%", np_3m >= 0 ? colLongSig : colShortSig, rowBg, szT)
        f_cell(3, 18, na(np_5m) ? "-" : f_fmt_v(np_5m, "0.0") + "%", np_5m >= 0 ? colLongSig : colShortSig, rowBg, szT)
        f_cell(4, 18, na(np_15m) ? "-" : f_fmt_v(np_15m, "0.0") + "%", np_15m >= 0 ? colLongSig : colShortSig, rowBg, szT)
        f_cell(5, 18, na(np_1h) ? "-" : f_fmt_v(np_1h, "0.0") + "%", np_1h >= 0 ? colLongSig : colShortSig, rowBg, szT)
        
        // Row 19: Max DrawDown (%)
        f_cell(0, 19, "Max DrawDown (%)", gray, rowBg, szT)
        f_cell(1, 19, na(dd_1m) ? "-" : f_fmt_v(dd_1m, "0.0") + "%", f_color_dd(dd_1m), rowBg, szT)
        f_cell(2, 19, na(dd_3m) ? "-" : f_fmt_v(dd_3m, "0.0") + "%", f_color_dd(dd_3m), rowBg, szT)
        f_cell(3, 19, na(dd_5m) ? "-" : f_fmt_v(dd_5m, "0.0") + "%", f_color_dd(dd_5m), rowBg, szT)
        f_cell(4, 19, na(dd_15m) ? "-" : f_fmt_v(dd_15m, "0.0") + "%", f_color_dd(dd_15m), rowBg, szT)
        f_cell(5, 19, na(dd_1h) ? "-" : f_fmt_v(dd_1h, "0.0") + "%", f_color_dd(dd_1h), rowBg, szT)
        
        // Row 20: Sharpe Ratio
        f_cell(0, 20, "Sharpe Ratio", gray, rowBg, szT)
        f_cell(1, 20, f_fmt_v(sh_1m, "0.00"), f_color_sharpe(sh_1m), rowBg, szT)
        f_cell(2, 20, f_fmt_v(sh_3m, "0.00"), f_color_sharpe(sh_3m), rowBg, szT)
        f_cell(3, 20, f_fmt_v(sh_5m, "0.00"), f_color_sharpe(sh_5m), rowBg, szT)
        f_cell(4, 20, f_fmt_v(sh_15m, "0.00"), f_color_sharpe(sh_15m), rowBg, szT)
        f_cell(5, 20, f_fmt_v(sh_1h, "0.00"), f_color_sharpe(sh_1h), rowBg, szT)
        
        // Row 21: Active Trade Status for Chart Timeframe
        if btActiveTrade != 0
            table.merge_cells(dash, 0, 21, 5, 21)
            float unrealizedPnL = btActiveTrade == 1 ?
                 (close - btEntryPrice) * btPositionSize / btEntryPrice :
                 (btEntryPrice - close) * btPositionSize / btEntryPrice
            string activeTradeText = btActiveTrade == 1 ? "🟢 ACTIVE LONG" : "🔴 ACTIVE SHORT"
            activeTradeText := activeTradeText + " | Entry: $" + str.tostring(btEntryPrice, "#.00") + " | TP: $" + str.tostring(btTP, "#.00") + " | SL: $" + str.tostring(btSL, "#.00")
            activeTradeText := activeTradeText + " | Unrealized: $" + str.tostring(unrealizedPnL, "#.00")
            color activeTradeCol = unrealizedPnL > 0 ? colLongSig : colShortSig
            f_cell(0, 21, activeTradeText, activeTradeCol, color.new(#1e293b, 0), szT)

// ═══════════════════════════════════════════════════════════════════════════
// 21. ALERTS
// ═══════════════════════════════════════════════════════════════════════════

f_alertMsg(string action) =>
    if alertFmt == "JSON"
        '{"action":"' + action + '","ticker":"' + syminfo.tickerid + '","tf":"' + timeframe.period +    '","entry":"' + str.tostring(close, format.mintick) + '","sl":"' + str.tostring(invalPx, format.mintick) +   '","tp1":"' + str.tostring(ref1Px, format.mintick) + '","tp2":"' + str.tostring(ref2Px, format.mintick) +   '","tp3":"' + str.tostring(ref3Px, format.mintick) + '","score":"' + str.tostring(sweepScoreLast, "#.0") +   '","regime":"' + regimeLabel + '"}'
    else
        action + " | " + syminfo.tickerid + " | " + timeframe.period + " | E: " + str.tostring(close, format.mintick) +  " | SL: " + str.tostring(invalPx, format.mintick) + " | TP1: " + str.tostring(ref1Px, format.mintick) +  " | Score: " + str.tostring(sweepScoreLast, "#.0") + " | " + regimeLabel

if trigLong and barstate.isconfirmed
    alert(f_alertMsg("LONG"), alert.freq_once_per_bar_close)
if trigShort and barstate.isconfirmed
    alert(f_alertMsg("SHORT"), alert.freq_once_per_bar_close)

alertcondition(trigLong,  "ULI — LONG Trigger",  "Long trigger: liquidity sweep confirmed with scoring.")
alertcondition(trigShort, "ULI — SHORT Trigger", "Short trigger: liquidity sweep confirmed with scoring.")
alertcondition(newBullSweep or newBearSweep, "ULI — Any Sweep", "Liquidity sweep detected.")
alertcondition(closedBull and high >= ref3Px, "ULI — TP3 Hit (Long)", "Long TP3 reached.")
alertcondition(closedBull and low <= invalPx, "ULI — SL Hit (Long)", "Long SL reached.")
alertcondition(closedBear and low <= ref3Px, "ULI — TP3 Hit (Short)", "Short TP3 reached.")
alertcondition(closedBear and high >= invalPx, "ULI — SL Hit (Short)", "Short SL reached.")

======================================================================

3. IQCE - Institutional Quantum Confluence Engine (sina)

//@version=6
strategy(
     title="IQCE - Institutional Quantum Confluence Engine (sina)", 
     overlay=true, 
     calc_on_every_tick=true, 
     precision=3, 
     pyramiding=5, 
     default_qty_type=strategy.percent_of_equity, 
     default_qty_value=3, 
     initial_capital=10000, 
     commission_type=strategy.commission.percent, 
     commission_value=0.02, 
     currency=currency.USDT, 
     process_orders_on_close=true, 
     max_lines_count=500, 
     max_labels_count=500, 
     max_boxes_count=200
 )

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                         PRESET & TIMEFRAME AUTO ENGINE                     ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

presetMode = input.string("Auto", "System Preset Mode", options=["Auto", "Manual"], group="══════════ SYSTEM ENGINE ══════════", tooltip="Auto: Automatically optimizes all lookback periods, thresholds, and risk parameters based on the current timeframe. Manual: Uses the user configuration below.")

// Detect Timeframe category
isScalping = timeframe.isminutes and timeframe.multiplier <= 5
isSwing    = timeframe.isdaily or timeframe.isweekly or (timeframe.isminutes and timeframe.multiplier >= 240)
isIntraday = not isScalping and not isSwing

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     USER INPUT CONFIGURATION (WITH TOOLTIPS)             ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 1: ICHIMOKU CLOUD CONFIGURATION                                    │
// └──────────────────────────────────────────────────────────────────────────┘
ichimokuGroup        = "══════════ 1. ICHIMOKU CLOUD ══════════"
ichimokuEnabled      = input.bool(true, "Enable Ichimoku Analysis", group=ichimokuGroup, tooltip="Enables trend-following filtering using Ichimoku Senkou Cloud boundaries.")
ichimokuTenkan       = input.int(9, "Tenkan-sen Period [Manual]", group=ichimokuGroup, minval=1, tooltip="Manual mode conversion line period. Auto recommends: 6 (Scalping), 9 (Intraday), 20 (Swing).")
ichimokuKijun        = input.int(26, "Kijun-sen Period [Manual]", group=ichimokuGroup, minval=1, tooltip="Manual mode baseline period. Auto recommends: 18 (Scalping), 26 (Intraday), 60 (Swing).")
ichimokuSenkouB      = input.int(52, "Senkou Span B Period [Manual]", group=ichimokuGroup, minval=1, tooltip="Manual mode leading span B period. Auto recommends: 36 (Scalping), 52 (Intraday), 120 (Swing).")
ichimokuDisplacement = input.int(26, "Displacement [Manual]", group=ichimokuGroup, minval=1, tooltip="Manual mode forward shifting length. Auto recommends: 18 (Scalping), 26 (Intraday), 30 (Swing).")
ichimokuCloudColor   = input.bool(true, "Show Cloud Fill on Chart", group=ichimokuGroup, tooltip="Toggle background cloud filling transparency.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 2: VOLUME PROFILE & FIBONACCI                                     │
// └──────────────────────────────────────────────────────────────────────────┘
vpGroup = "══════════ 2. VOLUME PROFILE & FIBONACCI ══════════"
vpEnabled   = input.bool(true, "Enable Volume Profile Analysis", group=vpGroup, tooltip="Calculates high-volume nodes (POC, VAH, VAL) inside the specified lookback block.")
vpLookback  = input.int(200, "Profile Lookback Bars [Manual]", group=vpGroup, minval=30, tooltip="Window size used to calculate the volume distribution. Auto recommends: 100 (Scalp), 200 (Intraday), 300 (Swing).")
vpNumRows   = input.int(50, "Profile Rows (Resolution) [Manual]", group=vpGroup, minval=10, tooltip="The row count dividing the pricing ranges. Auto recommends: 40 (Scalp), 50 (Intraday), 60 (Swing).")
fibEnabled  = input.bool(true, "Enable Fibonacci Confluence", group=vpGroup, tooltip="Verifies correlation between price action and the Golden pocket (0.5 - 0.618).")
fibLookback = input.int(100, "Fibonacci Swing Lookback [Manual]", group=vpGroup, minval=20, tooltip="The historical swing high/low lookback period to establish Fibonacci levels.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 3: DIVERGENCE DETECTION                                            │
// └──────────────────────────────────────────────────────────────────────────┘
divGroup = "══════════ 3. DIVERGENCE ENGINE ══════════"
divEnabled     = input.bool(true, "Enable Divergence Detection", group=divGroup, tooltip="Identifies momentum divergences using RSI, MACD, and OBV concurrently.")
divRsiPeriod   = input.int(14, "RSI Period for Divergence [Manual]", group=divGroup, minval=2, tooltip="Auto recommends: 10 (Scalping), 14 (Intraday), 21 (Swing).")
divMacdFast    = input.int(12, "MACD Fast Length [Manual]", group=divGroup, minval=2)
divMacdSlow    = input.int(26, "MACD Slow Length [Manual]", group=divGroup, minval=2)
divMacdSignal  = input.int(9, "MACD Signal Smoothing [Manual]", group=divGroup, minval=2)
divLookback    = input.int(50, "Divergence Lookback [Manual]", group=divGroup, minval=10, tooltip="Number of bars checked back for high/low swing structural pivots.")
divMinStrength = input.float(0.7, "Minimum Divergence Strength [Manual]", group=divGroup, minval=0.1, maxval=1.0, step=0.1, tooltip="A threshold representing divergence quality based on structural change steepness.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 4: MARKET CIPHER B                                                 │
// └──────────────────────────────────────────────────────────────────────────┘
cipherGroup = "══════════ 4. MARKET CIPHER B ══════════"
cipherEnabled = input.bool(true, "Enable Market Cipher B", group=cipherGroup, tooltip="Determines money flow index (MFI) crossovers and momentum waves alignment.")
cipherLength  = input.int(20, "Cipher B Wave Length [Manual]", group=cipherGroup, minval=5, tooltip="Auto recommends: 12 (Scalping), 20 (Intraday), 24 (Swing).")
cipherSmooth  = input.int(3, "Cipher B Smoothing [Manual]", group=cipherGroup, minval=1)
cipherSource  = input.source(hlc3, "Cipher B Source Price", group=cipherGroup)

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 5: INSTITUTIONAL SMC/ICT                                           │
// └──────────────────────────────────────────────────────────────────────────┘
smcGroup = "══════════ 5. INSTITUTIONAL SMC/ICT ══════════"
smcEnabled       = input.bool(true, "Enable SMC/ICT Analysis", group=smcGroup, tooltip="Analyses Market Structure Shifts (MSS), Fair Value Gaps (FVG) and Liquidity Sweeps.")
smcFvgMinSize    = input.float(0.1, "FVG Minimum Size (ATR %)", group=smcGroup, minval=0.01, step=0.05, tooltip="Filters minor or low-liquidity market gaps.")
smcShowFvg       = input.bool(true, "Visualize Fair Value Gaps", group=smcGroup, tooltip="Plots transparent structural boxes over unfilled fair value gaps.")
smcShowLiqSweeps = input.bool(true, "Visualize Liquidity Sweeps", group=smcGroup, tooltip="Highlights structural liquidity sweeps on price peaks and troughs.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 6: VOLUMETRIC REGIME FILTER                                        │
// └──────────────────────────────────────────────────────────────────────────┘
volGroup = "══════════ 6. VOLUMETRIC REGIME FILTER ══════════"
useRvolFilter = input.bool(true, "Enable Relative Volume (RVOL) Filter", group=volGroup, tooltip="Saves capital by filtering out signals that occur during low liquidity (e.g. weekends or bank holidays).")
rvolLength    = input.int(20, "RVOL Baseline Length", group=volGroup, minval=5, tooltip="The historical average volume period used to gauge relative spikes.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 7: CONFLUENCE SCORING & EXECUTION                                  │
// └──────────────────────────────────────────────────────────────────────────┘
execGroup = "══════════ 7. EXECUTION CONFIG ══════════"
minConfluenceScore   = input.float(65.0, "Minimum Confluence Entry Score", group=execGroup, minval=0, maxval=100, step=5, tooltip="The cumulative score required across all active analysis layers to initiate an order. Auto recommends: 60 (Scalping), 65 (Intraday), 70 (Swing).")
requireAllLayers     = input.bool(false, "Require All Layers Confirmed", group=execGroup, tooltip="Strict execution flag. If true, every single active module MUST have a constructive bullish/bearish alignment.")
useAdaptiveThreshold = input.bool(true, "Use Volatility-Adaptive Thresholds", group=execGroup, tooltip="Dynamically tightens or eases the confluence criteria depending on market volatility regimes.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 8: RISK MANAGEMENT                                                 │
// └──────────────────────────────────────────────────────────────────────────┘
riskGroup = "══════════ 8. RISK MANAGEMENT ══════════"
riskAtrPeriod       = input.int(14, "ATR Calculation Period", group=riskGroup, minval=2)
riskAtrMultiplier   = input.float(2.0, "Stop Loss (ATR Multiplier) [Manual]", group=riskGroup, minval=0.5, step=0.1, tooltip="Sets the distance of the Stop Loss based on ATR volatility.")
riskTp1Multiplier   = input.float(1.5, "Take Profit 1 (ATR Multiplier) [Manual]", group=riskGroup, minval=0.5, step=0.1)
riskTp2Multiplier   = input.float(3.0, "Take Profit 2 (ATR Multiplier) [Manual]", group=riskGroup, minval=0.5, step=0.1)
riskTp1Percent      = input.float(50.0, "TP1 Position Close %", group=riskGroup, minval=0, maxval=100, step=5, tooltip="Partial exit configuration. Closes the specified percentage of the position at TP1.")
riskUseTrailingStop = input.bool(true, "Enable Trailing Stop", group=riskGroup, tooltip="Locks in profits by trailing the Stop Loss in constructive trend movements.")
riskTrailActivation = input.float(1.0, "Trailing Activation (ATR Profit)", group=riskGroup, minval=0.5, step=0.1, tooltip="Specifies the profit threshold (in ATR multiples) to begin trailing the stop.")
riskMaxDailyLoss    = input.float(3.0, "Max Daily Loss Limit %", group=riskGroup, minval=0.5, step=0.5, tooltip="A safety circuit breaker that blocks entries if trading losses exceed this equity percentage in a single day.")
riskMaxConsecutive  = input.int(3, "Max Allowed Consecutive Losses", group=riskGroup, minval=1, tooltip="Circuit breaker blocking further trades if multiple stop outs occur in sequence.")

// ┌──────────────────────────────────────────────────────────────────────────┐
// │ GROUP 9: VISUALIZATION                                                   │
// └──────────────────────────────────────────────────────────────────────────┘
visGroup = "══════════ 9. VISUAL DESIGN ══════════"
visShowDashboard = input.bool(true, "Show Live Performance Dashboard", group=visGroup, tooltip="Renders a neat real-time table showing metrics and current confluence status.")
visShowSignals   = input.bool(true, "Show Entry Labels", group=visGroup, tooltip="Toggles minimalist visual green/red tags representing entry alerts.")
visMinimalMode   = input.bool(false, "Minimal Visual Mode (Fast Loading)", group=visGroup, tooltip="Enabling this hides all background drawings, clouds and indicators to prevent chart lag.")

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     GLOBAL STATEFUL CALCULATIONS                           ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================
// ALL calculations with dynamic historical references are placed in global scope.

// Volatility & ATR
atrValue = ta.atr(riskAtrPeriod)

// 1. Ichimoku Global Calculations (Constants for Preset / Manual compatibility)
scTenkanVal  = math.avg(ta.lowest(low, 6),   ta.highest(high, 6))
scKijunVal   = math.avg(ta.lowest(low, 18),  ta.highest(high, 18))
scSenkouBVal = math.avg(ta.lowest(low, 36),  ta.highest(high, 36))

idTenkanVal  = math.avg(ta.lowest(low, 9),   ta.highest(high, 9))
idKijunVal   = math.avg(ta.lowest(low, 26),  ta.highest(high, 26))
idSenkouBVal = math.avg(ta.lowest(low, 52),  ta.highest(high, 52))

swTenkanVal  = math.avg(ta.lowest(low, 20),  ta.highest(high, 20))
swKijunVal   = math.avg(ta.lowest(low, 60),  ta.highest(high, 60))
swSenkouBVal = math.avg(ta.lowest(low, 120), ta.highest(high, 120))

manTenkanVal  = math.avg(ta.lowest(low, ichimokuTenkan),  ta.highest(high, ichimokuTenkan))
manKijunVal   = math.avg(ta.lowest(low, ichimokuKijun),   ta.highest(high, ichimokuKijun))
manSenkouBVal = math.avg(ta.lowest(low, ichimokuSenkouB), ta.highest(high, ichimokuSenkouB))

// 2. Volume Profile Range Boundaries Calculations
high100 = ta.highest(high, 100)
low100  = ta.lowest(low, 100)
high200 = ta.highest(high, 200)
low200  = ta.lowest(low, 200)
high300 = ta.highest(high, 300)
low300  = ta.lowest(low, 300)
highMan = ta.highest(high, vpLookback)
lowMan  = ta.lowest(low, vpLookback)

// 3. Fibonacci Swing Boundaries Calculations
fibHigh50  = ta.highest(high, 50),  fibLow50  = ta.lowest(low, 50)
fibHigh100 = ta.highest(high, 100), fibLow100 = ta.lowest(low, 100)
fibHigh150 = ta.highest(high, 150), fibLow150 = ta.lowest(low, 150)
fibHighMan = ta.highest(high, fibLookback), fibLowMan = ta.lowest(low, fibLookback)

// 4. Divergence Base Oscillators Calculations
rsiSC  = ta.rsi(close, 10)
rsiID  = ta.rsi(close, 14)
rsiSW  = ta.rsi(close, 21)
rsiMan = ta.rsi(close, divRsiPeriod)

[macd_F_SC, macd_S_SC, macd_H_SC] = ta.macd(close, 8, 21, 5)
[macd_F_ID, macd_S_ID, macd_H_ID] = ta.macd(close, 12, 26, 9)
[macd_F_SW, macd_S_SW, macd_H_SW] = ta.macd(close, 19, 39, 9)
[macd_F_Man, macd_S_Man, macd_H_Man] = ta.macd(close, divMacdFast, divMacdSlow, divMacdSignal)

obvValue = ta.cum(math.sign(ta.change(close)) * (volume > 0 ? volume : 0))

// 5. Market Cipher B Base Oscillators Calculations
esaSC  = ta.ema(cipherSource, 12),  d_SC  = ta.ema(math.abs(cipherSource - esaSC), 12)
esaID  = ta.ema(cipherSource, 20),  d_ID  = ta.ema(math.abs(cipherSource - esaID), 20)
esaSW  = ta.ema(cipherSource, 24),  d_SW  = ta.ema(math.abs(cipherSource - esaSW), 24)
esaMan = ta.ema(cipherSource, cipherLength), d_Man = ta.ema(math.abs(cipherSource - esaMan), cipherLength)

// 6. SMC Pivot Swings Calculations
swingHigh5  = ta.pivothigh(high, 5, 5)
swingLow5   = ta.pivotlow(low, 5, 5)
swingHigh20 = ta.pivothigh(high, 20, 20)
swingLow20  = ta.pivotlow(low, 20, 20)

// Volume Delta Calculation (RVOL Filter)
avgVolume = ta.sma(volume > 0 ? volume : 0, rvolLength)
rvol = avgVolume > 0 ? (volume > 0 ? volume : 0) / avgVolume : 1.0
rvolConfirmed = not useRvolFilter or rvol >= 1.0

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     DYNAMIC PARAMETER ASSIGNMENT (PRESETS)               ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

// Dynamic Resolution of Parameters
tenkanSen    = presetMode == "Auto" ? (isScalping ? scTenkanVal : (isSwing ? swTenkanVal : idTenkanVal)) : manTenkanVal
kijunSen     = presetMode == "Auto" ? (isScalping ? scKijunVal : (isSwing ? swKijunVal : idKijunVal)) : manKijunVal
senkouSpanA  = math.avg(tenkanSen, kijunSen)
senkouSpanB  = presetMode == "Auto" ? (isScalping ? scSenkouBVal : (isSwing ? swSenkouBVal : idSenkouBVal)) : manSenkouBVal
displacement = presetMode == "Auto" ? (isScalping ? 18 : (isSwing ? 30 : 26)) : ichimokuDisplacement

// Cloud Offset Variables for Plots (Strict Global Scope)
senkouSpanA_forward = senkouSpanA[displacement]
senkouSpanB_forward = senkouSpanB[displacement]
chikouSpan          = close[displacement]
ichimokuCloudTop    = math.max(senkouSpanA_forward, senkouSpanB_forward)
ichimokuCloudBottom = math.min(senkouSpanA_forward, senkouSpanB_forward)

// Resolved Volume Profile Range & Rows
vpRangeHigh = presetMode == "Auto" ? (isScalping ? high100 : (isSwing ? high300 : high200)) : highMan
vpRangeLow  = presetMode == "Auto" ? (isScalping ? low100 : (isSwing ? low300 : low200)) : lowMan
resolvedVpLookback = presetMode == "Auto" ? (isScalping ? 100 : (isSwing ? 300 : 200)) : vpLookback
resolvedVpRows     = presetMode == "Auto" ? (isScalping ? 40 : (isSwing ? 60 : 50)) : vpNumRows

// Resolved Fibonacci Levels
fibSwingHigh = presetMode == "Auto" ? (isScalping ? fibHigh50 : (isSwing ? fibHigh150 : fibHigh100)) : fibHighMan
fibSwingLow  = presetMode == "Auto" ? (isScalping ? fibLow50 : (isSwing ? fibLow150 : fibLow100)) : fibLowMan
resolvedFibLookback = presetMode == "Auto" ? (isScalping ? 50 : (isSwing ? 150 : 100)) : fibLookback

// Resolved Divergence Oscillators
rsiValue       = presetMode == "Auto" ? (isScalping ? rsiSC : (isSwing ? rsiSW : rsiID)) : rsiMan
macdLine       = presetMode == "Auto" ? (isScalping ? macd_F_SC : (isSwing ? macd_F_SW : macd_F_ID)) : macd_F_Man
macdSignalLine = presetMode == "Auto" ? (isScalping ? macd_S_SC : (isSwing ? macd_S_SW : macd_S_ID)) : macd_S_Man
macdHist       = presetMode == "Auto" ? (isScalping ? macd_H_SC : (isSwing ? macd_H_SW : macd_H_ID)) : macd_H_Man
resolvedDivLookback    = presetMode == "Auto" ? (isScalping ? 30 : (isSwing ? 80 : 50)) : divLookback
resolvedDivMinStrength = presetMode == "Auto" ? (isScalping ? 0.6 : (isSwing ? 0.8 : 0.7)) : divMinStrength

// Resolved Market Cipher B
resolvedCipherLength = presetMode == "Auto" ? (isScalping ? 12 : (isSwing ? 24 : 20)) : cipherLength
resolvedCipherSmooth = presetMode == "Auto" ? (isScalping ? 2 : (isSwing ? 4 : 3)) : cipherSmooth

esa = presetMode == "Auto" ? (isScalping ? esaSC : (isSwing ? esaSW : esaID)) : esaMan
d   = presetMode == "Auto" ? (isScalping ? d_SC : (isSwing ? d_SW : d_ID)) : d_Man

// Resolved Confluence Execution Values
resolvedMinConfluence = presetMode == "Auto" ? (isScalping ? 60.0 : (isSwing ? 70.0 : 65.0)) : minConfluenceScore
resolvedSLMult        = presetMode == "Auto" ? (isScalping ? 1.5 : (isSwing ? 2.5 : 2.0)) : riskAtrMultiplier
resolvedTp1Mult       = presetMode == "Auto" ? (isScalping ? 1.2 : (isSwing ? 1.8 : 1.5)) : riskTp1Multiplier
resolvedTp2Mult       = presetMode == "Auto" ? (isScalping ? 2.5 : (isSwing ? 3.5 : 3.0)) : riskTp2Multiplier

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     VOLATILITY REGIME CLASSIFIER                          ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

var float[] atrHistory = array.new<float>(0)
array.push(atrHistory, atrValue)
if array.size(atrHistory) > 100
    array.shift(atrHistory)

getVolatilityRegime(float[] history, float currentAtr) =>
    regime = 1  // Default: NORMAL
    size = array.size(history)
    if size > 20
        sortedAtr = array.copy(history)
        array.sort(sortedAtr)
        p25 = array.get(sortedAtr, math.floor(size * 0.25))
        p75 = array.get(sortedAtr, math.floor(size * 0.75))
        p90 = array.get(sortedAtr, math.floor(size * 0.90))
        
        if currentAtr > p90
            regime := 3  // EXTREME
        else if currentAtr > p75
            regime := 2  // HIGH
        else if currentAtr < p25
            regime := 0  // LOW
    regime

volRegime = getVolatilityRegime(atrHistory, atrValue)
volRegimeNames = array.from("LOW", "NORMAL", "HIGH", "EXTREME")
volRegimeName = array.get(volRegimeNames, volRegime)

adaptiveAtrMult = switch volRegime
    0 => resolvedSLMult * 1.35
    1 => resolvedSLMult
    2 => resolvedSLMult * 0.85
    3 => resolvedSLMult * 0.70
    => resolvedSLMult

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                   LAYER 1: ICHIMOKU CLOUD SYSTEM                         ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

type IchimokuState
    bool isBullish = false
    bool isBearish = false
    bool isStrongBull = false
    bool isStrongBear = false
    bool tkCrossBull = false
    bool tkCrossBear = false
    bool priceAboveCloud = false
    bool priceBelowCloud = false
    bool priceInCloud = false
    bool chikouAbovePrice = false
    bool chikouAboveCloud = false
    float cloudTop = na
    float cloudBottom = na
    bool cloudGreen = false
    bool cloudRed = false
    int signal = 0 

getIchimokuState(float cloudTop, float cloudBottom) =>
    state = IchimokuState.new()
    state.cloudTop := cloudTop
    state.cloudBottom := cloudBottom
    state.cloudGreen := senkouSpanA_forward > senkouSpanB_forward
    state.cloudRed := senkouSpanA_forward < senkouSpanB_forward
    state.priceAboveCloud := close > state.cloudTop
    state.priceBelowCloud := close < state.cloudBottom
    state.priceInCloud := not state.priceAboveCloud and not state.priceBelowCloud
    
    // Global non-conditional crossover calculations
    state.tkCrossBull := ta.crossover(tenkanSen, kijunSen)
    state.tkCrossBear := ta.crossunder(tenkanSen, kijunSen)
    
    tkBull = tenkanSen > kijunSen
    tkBear = tenkanSen < kijunSen
    state.chikouAbovePrice := chikouSpan > close[displacement]
    state.chikouAboveCloud := chikouSpan > cloudTop[displacement]
    
    state.isStrongBull := state.priceAboveCloud and tkBull and state.chikouAboveCloud and state.cloudGreen
    state.isStrongBear := state.priceBelowCloud and tkBear and not state.chikouAboveCloud and state.cloudRed
    state.isBullish := state.priceAboveCloud and tkBull
    state.isBearish := state.priceBelowCloud and tkBear
    
    if state.isStrongBull
        state.signal := 2
    else if state.isBullish
        state.signal := 1
    else if state.isStrongBear
        state.signal := -2
    else if state.isBearish
        state.signal := -1
    else
        state.signal := 0
    state

ichiState = ichimokuEnabled ? getIchimokuState(ichimokuCloudTop, ichimokuCloudBottom) : IchimokuState.new()

// Plotting Cloud
plotTenkan   = (ichimokuEnabled and not visMinimalMode) ? tenkanSen : na
plotKijun    = (ichimokuEnabled and not visMinimalMode) ? kijunSen : na
plotSenkouA  = (ichimokuEnabled and not visMinimalMode) ? senkouSpanA_forward : na
plotSenkouB  = (ichimokuEnabled and not visMinimalMode) ? senkouSpanB_forward : na

plot(plotTenkan, "Tenkan-sen", color=color.new(#E91E63, 0), linewidth=1)
plot(plotKijun, "Kijun-sen", color=color.new(#2196F3, 0), linewidth=2)
pA = plot(plotSenkouA, "Senkou A", color=color.new(#4CAF50, 60), linewidth=1, offset=displacement)
pB = plot(plotSenkouB, "Senkou B", color=color.new(#FF5722, 60), linewidth=1, offset=displacement)

fillColor = (ichimokuEnabled and not visMinimalMode and ichimokuCloudColor) ? (senkouSpanA_forward > senkouSpanB_forward ? color.new(#00E676, 92) : color.new(#FF1744, 92)) : color.new(color.white, 100)
fill(pA, pB, color=fillColor, title="Ichimoku Cloud")

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║            LAYER 2: VOLUME PROFILE & FIBONACCI CONFLUENCE                ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

type VolumeProfile
    float poc = na
    float vah = na
    float val = na
    float[] distribution = na

getVolumeProfile(int lookback, int numRows, float rangeHigh, float rangeLow) =>
    vp = VolumeProfile.new()
    if bar_index >= lookback and rangeHigh > rangeLow and numRows > 0
        priceRange = rangeHigh - rangeLow
        rowSize = priceRange / numRows
        dist = array.new<float>(numRows, 0.0)
        totalVolume = 0.0
        
        for i = 0 to lookback - 1
            priceLevel = close[i]
            volumeAtBar = volume[i]
            if not na(priceLevel) and not na(volumeAtBar) and volumeAtBar > 0 and rowSize > 0
                rowIndex = math.floor((priceLevel - rangeLow) / rowSize)
                rowIndex := math.max(0, math.min(numRows - 1, rowIndex))
                if rowIndex >= 0 and rowIndex < numRows
                    array.set(dist, rowIndex, array.get(dist, rowIndex) + volumeAtBar)
                    totalVolume += volumeAtBar
        
        maxVol = 0.0
        pocIndex = 0
        for i = 0 to numRows - 1
            volAtRow = array.get(dist, i)
            if volAtRow > maxVol
                maxVol := volAtRow
                pocIndex := i
        
        vp.poc := rangeLow + (pocIndex + 0.5) * rowSize
        vp.distribution := dist
        
        if totalVolume > 0 and numRows > 0
            targetVol = totalVolume * 0.70
            accumulated = array.get(dist, pocIndex)
            upperIdx = pocIndex
            lowerIdx = pocIndex
            
            for iteration = 0 to numRows
                if accumulated >= targetVol
                    break
                upperVol = upperIdx < numRows - 1 ? array.get(dist, upperIdx + 1) : -1.0
                lowerVol = lowerIdx > 0 ? array.get(dist, lowerIdx - 1) : -1.0
                
                if upperVol >= lowerVol and upperIdx < numRows - 1
                    upperIdx += 1
                    accumulated += upperVol
                else if lowerIdx > 0
                    lowerIdx -= 1
                    accumulated += lowerVol
                else
                    break
            
            vp.vah := rangeLow + (upperIdx + 0.5) * rowSize
            vp.val := rangeLow + (lowerIdx + 0.5) * rowSize
    vp

volumeProfile = vpEnabled ? getVolumeProfile(resolvedVpLookback, resolvedVpRows, vpRangeHigh, vpRangeLow) : VolumeProfile.new()

type FibonacciLevels
    float swingHigh = na
    float swingLow = na
    bool isUptrend = false
    float goldenTop = na
    float goldenBottom = na

getFibonacciLevels(int lookback, float highSrc, float lowSrc) =>
    fib = FibonacciLevels.new()
    if bar_index >= lookback
        fib.swingHigh := highSrc
        fib.swingLow := lowSrc
        fib.isUptrend := close > math.avg(highSrc, lowSrc)
        
        rangeVal = highSrc - lowSrc
        if fib.isUptrend
            fib.goldenTop := lowSrc + rangeVal * 0.618
            fib.goldenBottom := lowSrc + rangeVal * 0.500
        else
            fib.goldenTop := highSrc - rangeVal * 0.500
            fib.goldenBottom := highSrc - rangeVal * 0.618
    fib

fibLevels = fibEnabled ? getFibonacciLevels(resolvedFibLookback, fibSwingHigh, fibSwingLow) : FibonacciLevels.new()

isInConfluenceZone(float price, VolumeProfile vp, FibonacciLevels fib, bool isLong) =>
    inZone = false
    if isLong
        nearFibGolden = price <= fib.goldenTop and price >= fib.goldenBottom
        nearPoc = not na(vp.poc) and math.abs(price - vp.poc) <= atrValue * 0.5
        nearVal = not na(vp.val) and price <= vp.val and price >= vp.val - atrValue * 0.3
        inZone := nearFibGolden and (nearPoc or nearVal)
    else
        nearFibGolden = price >= fib.goldenBottom and price <= fib.goldenTop
        nearPoc = not na(vp.poc) and math.abs(price - vp.poc) <= atrValue * 0.5
        nearVah = not na(vp.vah) and price >= vp.vah and price <= vp.vah + atrValue * 0.3
        inZone := nearFibGolden and (nearPoc or nearVah)
    inZone

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                 LAYER 3: MULTI-INDICATOR DIVERGENCE ENGINE               ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

type DivergenceSignal
    int rsiDiv = 0      
    int macdDiv = 0
    int obvDiv = 0
    float rsiStrength = 0.0
    float macdStrength = 0.0
    float obvStrength = 0.0
    int consensus = 0   

detectDivergence(float priceSrc, float indicatorSrc, int lookback, float minStrengthVal) =>
    div = 0
    strength = 0.0
    
    priceHigh = ta.highest(priceSrc, lookback)
    priceLow  = ta.lowest(priceSrc, lookback)
    indHigh   = ta.highest(indicatorSrc, lookback)
    indLow    = ta.lowest(indicatorSrc, lookback)
    
    if priceSrc <= priceLow * 1.01 and indicatorSrc > indLow
        priceDecline = (priceSrc[lookback] - priceSrc) / (priceSrc[lookback] > 0 ? priceSrc[lookback] : 1.0)
        indRise = (indicatorSrc - indLow) / (math.abs(indLow) > 0 ? math.abs(indLow) : 1.0)
        strength := math.min(1.0, (priceDecline + indRise) / 2)
        if strength >= minStrengthVal
            div := 1
            
    if priceSrc >= priceHigh * 0.99 and indicatorSrc < indHigh
        priceRise = (priceSrc - priceSrc[lookback]) / (priceSrc[lookback] > 0 ? priceSrc[lookback] : 1.0)
        indDecline = (indHigh - indicatorSrc) / (indHigh > 0 ? indHigh : 1.0)
        strength := math.min(1.0, (priceRise + indDecline) / 2)
        if strength >= minStrengthVal
            div := -1
            
    [div, strength]

getDivergenceSignals(int lookback, float minStrengthVal) =>
    divSignal = DivergenceSignal.new()
    [rsiD, rsiS]   = detectDivergence(close, rsiValue, lookback, minStrengthVal)
    [macdD, macdS] = detectDivergence(close, macdLine, lookback, minStrengthVal)
    [obvD, obvS]   = detectDivergence(close, obvValue, lookback, minStrengthVal)
    
    divSignal.rsiDiv := rsiD
    divSignal.macdDiv := macdD
    divSignal.obvDiv := obvD
    divSignal.rsiStrength := rsiS
    divSignal.macdStrength := macdS
    divSignal.obvStrength := obvS
    
    bullCount = (rsiD == 1 ? 1 : 0) + (macdD == 1 ? 1 : 0) + (obvD == 1 ? 1 : 0)
    bearCount = (rsiD == -1 ? 1 : 0) + (macdD == -1 ? 1 : 0) + (obvD == -1 ? 1 : 0)
    
    if bullCount >= 2
        divSignal.consensus := 1
    else if bearCount >= 2
        divSignal.consensus := -1
    else
        divSignal.consensus := 0
    divSignal

divSignals = divEnabled ? getDivergenceSignals(resolvedDivLookback, resolvedDivMinStrength) : DivergenceSignal.new()

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                   LAYER 4: MARKET CIPHER B ENGINE                        ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

type CipherBSignal
    float momentumWave = 0.0
    float moneyFlow = 0.0
    bool squeezeActive = false
    bool diamondBull = false
    bool diamondBear = false
    int direction = 0  

getCipherBSignals(int length, int smooth) =>
    c = CipherBSignal.new()
    
    ci = (cipherSource - esa) / (0.015 * (d > 0 ? d : 1.0))
    tci = ta.ema(ci, smooth)
    
    c.momentumWave := tci
    c.direction := tci > 0 ? 1 : -1
    
    wt1 = tci
    wt2 = ta.sma(wt1, 4)
    c.moneyFlow := wt1 - wt2
    
    bbBasis = ta.sma(cipherSource, 20)
    bbDev   = ta.stdev(cipherSource, 20) * 2
    kcBasis = ta.sma(cipherSource, 20)
    kcRange = ta.sma(ta.tr, 20) * 1.5
    
    bbHigh = bbBasis + bbDev
    bbLow  = bbBasis - bbDev
    kcHigh = kcBasis + kcRange
    kcLow  = kcBasis - kcRange
    c.squeezeActive := bbHigh < kcHigh and bbLow > kcLow
    
    // Global crossovers calculated out of functions
    c.diamondBull := ta.crossover(tci, 0) and c.moneyFlow > 0 and not c.squeezeActive
    c.diamondBear := ta.crossunder(tci, 0) and c.moneyFlow < 0 and not c.squeezeActive
    c

cipherSignal = cipherEnabled ? getCipherBSignals(resolvedCipherLength, resolvedCipherSmooth) : CipherBSignal.new()

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                  LAYER 5: INSTITUTIONAL SMC/ICT ENGINE                   ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

type SMCState
    bool fvgBull = false
    bool fvgBear = false
    float fvgTop = na
    float fvgBottom = na
    bool liquiditySweepBull = false
    bool liquiditySweepBear = false
    bool mssBull = false   
    bool mssBear = false   

detectFVG() =>
    float fvgTop = na      
    float fvgBottom = na   
    isBull = false
    isBear = false
    
    if low > high[2]
        fvgBottom := high[2]
        fvgTop := low
        isBull := true
    if high < low[2]
        fvgTop := low[2]
        fvgBottom := high
        isBear := true
        
    if not na(fvgTop) and not na(fvgBottom)
        gapSize = fvgTop - fvgBottom
        if gapSize < atrValue * smcFvgMinSize
            fvgTop := na
            fvgBottom := na
            isBull := false
            isBear := false
    [fvgTop, fvgBottom, isBull, isBear]

[fvgTopVal, fvgBottomVal, fvgBull, fvgBear] = detectFVG()

detectLiquiditySweep() =>
    sweepBull = false
    sweepBear = false
    if not na(swingLow5)
        sweepBull := low <= swingLow5 and close > swingLow5
    if not na(swingHigh5)
        sweepBear := high >= swingHigh5 and close < swingHigh5
    [sweepBull, sweepBear]

[liqSweepBull, liqSweepBear] = detectLiquiditySweep()

mssPrevHigh = ta.valuewhen(not na(swingHigh20), swingHigh20, 0)
mssPrevLow  = ta.valuewhen(not na(swingLow20), swingLow20, 0)

detectMSS(float prevHigh, float prevLow) =>
    mssBull = false
    mssBear = false
    if not na(swingHigh20)
        if close > prevHigh and close[1] <= prevHigh
            mssBull := true
    if not na(swingLow20)
        if close < prevLow and close[1] >= prevLow
            mssBear := true
    [mssBull, mssBear]

[mssBull, mssBear] = detectMSS(mssPrevHigh, mssPrevLow)

getSMCState() =>
    smc = SMCState.new()
    smc.fvgBull := fvgBull
    smc.fvgBear := fvgBear
    smc.fvgTop := fvgTopVal
    smc.fvgBottom := fvgBottomVal
    smc.liquiditySweepBull := liqSweepBull
    smc.liquiditySweepBear := liqSweepBear
    smc.mssBull := mssBull
    smc.mssBear := mssBear
    smc

smcState = smcEnabled ? getSMCState() : SMCState.new()

// Managed Drawing Lists (Garbage Collection)
var box[] fvgBoxes = array.new<box>()
var label[] sweepLabels = array.new<label>()

manageBoxes(box newBox) =>
    array.push(fvgBoxes, newBox)
    if array.size(fvgBoxes) > 10
        box.delete(array.shift(fvgBoxes))

manageLabels(label newLabel) =>
    array.push(sweepLabels, newLabel)
    if array.size(sweepLabels) > 10
        label.delete(array.shift(sweepLabels))

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                    CONFLUENCE SCORING ENGINE                             ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

getIchimokuScore(IchimokuState ichi, bool isLong) =>
    score = 0.0
    if isLong
        if ichi.isStrongBull
            score := 20.0
        else if ichi.isBullish
            score := 15.0
        else if ichi.priceAboveCloud
            score := 10.0
        if ichi.isBearish
            score := math.max(0, score - 8.0)
    else
        if ichi.isStrongBear
            score := 20.0
        else if ichi.isBearish
            score := 15.0
        else if ichi.priceBelowCloud
            score := 10.0
        if ichi.isBullish
            score := math.max(0, score - 8.0)
    score

getConfluenceScore(VolumeProfile vp, FibonacciLevels fib, DivergenceSignal div, CipherBSignal cipher, SMCState smc, bool isLong) =>
    score = 0.0
    layersConfirmed = 0
    
    // Layer 1: Ichimoku
    ichiScore = getIchimokuScore(ichiState, isLong)
    score += ichiScore
    if ichiScore >= 10.0
        layersConfirmed += 1
    
    // Layer 2: Volume & Fibonacci Zone
    inZone = isInConfluenceZone(close, vp, fib, isLong)
    if inZone
        score += 20.0
        layersConfirmed += 1
    else
        nearFibGolden = close <= fib.goldenTop and close >= fib.goldenBottom
        nearPoc = not na(vp.poc) and math.abs(close - vp.poc) <= atrValue
        if nearFibGolden
            score += 10.0
            layersConfirmed += 1
        if nearPoc
            score += 10.0
            if not nearFibGolden
                layersConfirmed += 1
            
    // Layer 3: Divergence
    if divEnabled
        divScore = 0.0
        if isLong
            if div.rsiDiv == 1
                divScore += 7.0 * div.rsiStrength
            if div.macdDiv == 1
                divScore += 7.0 * div.macdStrength
            if div.obvDiv == 1
                divScore += 6.0 * div.obvStrength
        else
            if div.rsiDiv == -1
                divScore += 7.0 * div.rsiStrength
            if div.macdDiv == -1
                divScore += 7.0 * div.macdStrength
            if div.obvDiv == -1
                divScore += 6.0 * div.obvStrength
        score += divScore
        if divScore >= 5.0
            layersConfirmed += 1
            
    // Layer 4: Market Cipher B
    if cipherEnabled
        cipherScore = 0.0
        if isLong
            if cipher.diamondBull
                cipherScore += 20.0
            else if cipher.direction == 1 and cipher.moneyFlow > 0
                cipherScore += 12.0
            else if cipher.direction == 1
                cipherScore += 6.0
        else
            if cipher.diamondBear
                cipherScore += 20.0
            else if cipher.direction == -1 and cipher.moneyFlow < 0
                cipherScore += 12.0
            else if cipher.direction == -1
                cipherScore += 6.0
        score += cipherScore
        if cipherScore >= 8.0
            layersConfirmed += 1
            
    // Layer 5: SMC Struct
    if smcEnabled
        smcScore = 0.0
        if isLong
            if smc.mssBull
                smcScore += 10.0
            if smc.liquiditySweepBull
                smcScore += 7.0
            if smc.fvgBull
                smcScore += 3.0
        else
            if smc.mssBear
                smcScore += 10.0
            if smc.liquiditySweepBear
                smcScore += 7.0
            if smc.fvgBear
                smcScore += 3.0
        score += smcScore
        if smcScore >= 5.0
            layersConfirmed += 1
            
    [math.min(100.0, score), layersConfirmed]

[confluenceScoreLong, layersLong]   = getConfluenceScore(volumeProfile, fibLevels, divSignals, cipherSignal, smcState, true)
[confluenceScoreShort, layersShort] = getConfluenceScore(volumeProfile, fibLevels, divSignals, cipherSignal, smcState, false)

adaptiveThreshold = useAdaptiveThreshold ? (volRegime == 3 ? resolvedMinConfluence * 1.2 : volRegime == 2 ? resolvedMinConfluence * 1.1 : volRegime == 0 ? resolvedMinConfluence * 0.85 : resolvedMinConfluence) : resolvedMinConfluence

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                       SIGNAL GENERATION ENGINE                           ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

signalLong  = confluenceScoreLong >= adaptiveThreshold and rvolConfirmed
signalShort = confluenceScoreShort >= adaptiveThreshold and rvolConfirmed

antiFakeoutLong  = volRegime >= 2 ? (signalLong and signalLong[1]) : signalLong
antiFakeoutShort = volRegime >= 2 ? (signalShort and signalShort[1]) : signalShort

if requireAllLayers
    layersLongConfirmed = ichiState.isBullish and 
                          isInConfluenceZone(close, volumeProfile, fibLevels, true) and
                          divSignals.consensus == 1 and
                          cipherSignal.direction == 1 and
                          (smcState.mssBull or smcState.liquiditySweepBull)
    
    layersShortConfirmed = ichiState.isBearish and
                           isInConfluenceZone(close, volumeProfile, fibLevels, false) and
                           divSignals.consensus == -1 and
                           cipherSignal.direction == -1 and
                           (smcState.mssBear or smcState.liquiditySweepBear)
    
    antiFakeoutLong  := antiFakeoutLong and layersLongConfirmed
    antiFakeoutShort := antiFakeoutShort and layersShortConfirmed

finalLong  = antiFakeoutLong and not antiFakeoutLong[1]  
finalShort = antiFakeoutShort and not antiFakeoutShort[1]

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                    RISK MANAGEMENT & EXECUTION                           ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

var float entryPrice = na
var float stopLoss = na
var float takeProfit1 = na
var float takeProfit2 = na
var int entryBar = na
var bool inPosition = false
var int positionDirection = 0  
var int consecutiveLosses = 0
var float dailyPnL = 0.0

isNewDay = ta.change(time("D")) != 0
if isNewDay
    dailyPnL := 0.0

dailyLossLimit = strategy.equity * riskMaxDailyLoss / 100
killSwitch = dailyPnL <= -dailyLossLimit or consecutiveLosses >= riskMaxConsecutive
tradeAllowed = not killSwitch

lowestLow10   = ta.lowest(low, 10)
highestHigh10 = ta.highest(high, 10)

getStopLoss(bool isLong, float atrMult, float low10, float high10) =>
    if isLong
        math.min(low10, close - atrValue * atrMult)  
    else
        math.max(high10, close + atrValue * atrMult)

getTakeProfitLevels(float entry, float sl, bool isLong) =>
    float tp1 = na  
    float tp2 = na  
    if isLong
        tp1 := entry + (entry - sl) * resolvedTp1Mult
        tp2 := entry + (entry - sl) * resolvedTp2Mult
    else
        tp1 := entry - (sl - entry) * resolvedTp1Mult
        tp2 := entry - (sl - entry) * resolvedTp2Mult
    [tp1, tp2]

// Position Entry Execution
if finalLong and tradeAllowed and strategy.position_size == 0
    sl = getStopLoss(true, adaptiveAtrMult, lowestLow10, highestHigh10)
    sl := math.min(sl, close * 0.995) 
    [tp1, tp2] = getTakeProfitLevels(close, sl, true)
    
    entryPrice := close
    stopLoss := sl
    takeProfit1 := tp1
    takeProfit2 := tp2
    entryBar := bar_index
    inPosition := true
    positionDirection := 1
    
    strategy.entry("Long", strategy.long)
    strategy.exit("TP1_Long", "Long", limit=tp1, stop=sl, qty_percent=riskTp1Percent)
    strategy.exit("TP2_Long", "Long", limit=tp2, stop=sl)

if finalShort and tradeAllowed and strategy.position_size == 0
    sl = getStopLoss(false, adaptiveAtrMult, lowestLow10, highestHigh10)
    sl := math.max(sl, close * 1.005) 
    [tp1, tp2] = getTakeProfitLevels(close, sl, false)
    
    entryPrice := close
    stopLoss := sl
    takeProfit1 := tp1
    takeProfit2 := tp2
    entryBar := bar_index
    inPosition := true
    positionDirection := -1
    
    strategy.entry("Short", strategy.short)
    strategy.exit("TP1_Short", "Short", limit=tp1, stop=sl, qty_percent=riskTp1Percent)
    strategy.exit("TP2_Short", "Short", limit=tp2, stop=sl)

// Trailing logic
if inPosition and riskUseTrailingStop
    profitInAtr = positionDirection == 1 ? (close - entryPrice) / (atrValue > 0 ? atrValue : 1.0) : (entryPrice - close) / (atrValue > 0 ? atrValue : 1.0)
    if profitInAtr >= riskTrailActivation
        if positionDirection == 1
            newTrailStop = close - atrValue * adaptiveAtrMult * 0.5
            if newTrailStop > stopLoss
                stopLoss := newTrailStop
                strategy.exit("Trail_Long", "Long", stop=stopLoss)
        else
            newTrailStop = close + atrValue * adaptiveAtrMult * 0.5
            if newTrailStop < stopLoss
                stopLoss := newTrailStop
                strategy.exit("Trail_Short", "Short", stop=stopLoss)

// Clear trades stats
if strategy.position_size == 0
    if inPosition
        tradePnl = strategy.netprofit - strategy.netprofit[1]
        dailyPnL += tradePnl
        if tradePnl < 0
            consecutiveLosses += 1
        else
            consecutiveLosses := 0
    inPosition := false
    entryPrice := na
    stopLoss := na
    takeProfit1 := na
    takeProfit2 := na
    positionDirection := 0
    entryBar := na

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                       MINIMALIST VISUALIZATION                             ║
// ╚════════════════════════════════════════════════════════════════════════════╗
// =============================================================================

// Signal Markers
if visShowSignals and not visMinimalMode
    if finalLong
        label.new(bar_index, low, "▲ LONG\nScore: " + str.tostring(confluenceScoreLong, "#") + "%\nLayers: " + str.tostring(layersLong) + "/5", 
                 color=color.new(#00E676, 15), textcolor=color.white,
                 style=label.style_label_up, size=size.small, yloc=yloc.belowbar)
    if finalShort
        label.new(bar_index, high, "▼ SHORT\nScore: " + str.tostring(confluenceScoreShort, "#") + "%\nLayers: " + str.tostring(layersShort) + "/5",
                 color=color.new(#FF1744, 15), textcolor=color.white,
                 style=label.style_label_down, size=size.small, yloc=yloc.abovebar)

// SMC FVG / Sweeps Drawing
if smcEnabled and smcShowFvg and not visMinimalMode
    if fvgBull
        bx = box.new(bar_index - 1, fvgBottomVal, bar_index + 4, fvgTopVal, 
               bgcolor=color.new(#00E5FF, 93), border_color=color.new(#00E5FF, 60),
               text="FVG+", text_size=size.tiny, text_color=color.white)
        manageBoxes(bx)
    if fvgBear
        bx = box.new(bar_index - 1, fvgBottomVal, bar_index + 4, fvgTopVal,
               bgcolor=color.new(#FF6D00, 93), border_color=color.new(#FF6D00, 60),
               text="FVG-", text_size=size.tiny, text_color=color.white)
        manageBoxes(bx)

if smcEnabled and smcShowLiqSweeps and not visMinimalMode
    if liqSweepBull
        lbl = label.new(bar_index, low, "• SWEEP", color=color.new(#00E5FF, 15), textcolor=color.white, style=label.style_label_up, size=size.tiny, yloc=yloc.belowbar)
        manageLabels(lbl)
    if liqSweepBear
        lbl = label.new(bar_index, high, "• SWEEP", color=color.new(#FF6D00, 15), textcolor=color.white, style=label.style_label_down, size=size.tiny, yloc=yloc.abovebar)
        manageLabels(lbl)

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     INSTITUTIONAL LIVE DASHBOARD TABLE                     ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

var table dashTable = table.new(position.top_right, columns=4, rows=9, 
     bgcolor=color.new(#0D0E15, 10), 
     border_color=color.new(#2A2E39, 40), 
     border_width=1)

if visShowDashboard and barstate.islast
    // Color definitions
    c_white = color.new(#E0E3EB, 0)
    c_green = color.new(#00E676, 0)
    c_red   = color.new(#FF1744, 0)
    c_gray  = color.new(#B2B5BE, 0)
    c_blue  = color.new(#2196F3, 0)
    
    // Header Row (Spans 4 columns)
    table.cell(dashTable, 0, 0, "IQCE INSTITUTIONAL QUANTUM CONFLUENCE ENGINE", bgcolor=color.new(#131722, 0), text_color=c_blue, text_size=size.small, width=100)
    table.merge_cells(dashTable, 0, 0, 3, 0)
    
    // Column Headers
    table.cell(dashTable, 0, 1, "Confluence Metric", bgcolor=color.new(#171B26, 0), text_color=c_white, text_size=size.tiny)
    table.cell(dashTable, 1, 1, "State / Score", bgcolor=color.new(#171B26, 0), text_color=c_white, text_size=size.tiny)
    table.cell(dashTable, 2, 1, "Live Backtest", bgcolor=color.new(#171B26, 0), text_color=c_white, text_size=size.tiny)
    table.cell(dashTable, 3, 1, "Value", bgcolor=color.new(#171B26, 0), text_color=c_white, text_size=size.tiny)
    
    // Rows 2: Ichimoku Cloud Status
    table.cell(dashTable, 0, 2, "Ichimoku Cloud Trend", text_color=c_gray, text_size=size.tiny)
    ichiText = ichiState.isStrongBull ? "STRONG BULL" : ichiState.isBullish ? "BULL" : ichiState.isStrongBear ? "STRONG BEAR" : ichiState.isBearish ? "BEAR" : "NEUTRAL"
    ichiColor = ichiState.isBullish ? c_green : ichiState.isBearish ? c_red : c_gray
    table.cell(dashTable, 1, 2, ichiText, text_color=ichiColor, text_size=size.tiny)
    
    // Live Backtest Metric - Net Profit
    netProfitRaw = strategy.netprofit
    netProfitPercent = (netProfitRaw / strategy.initial_capital) * 100
    table.cell(dashTable, 2, 2, "Net Profit", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 2, str.tostring(netProfitPercent, "0.00") + "% (" + str.tostring(netProfitRaw, "$0") + ")", text_color=netProfitRaw >= 0 ? c_green : c_red, text_size=size.tiny)
    
    // Rows 3: Vol Regime
    table.cell(dashTable, 0, 3, "Volatility Regime", text_color=c_gray, text_size=size.tiny)
    regimeCol = volRegime == 3 ? c_red : volRegime == 2 ? color.orange : volRegime == 0 ? color.rgb(0, 255, 255) : c_green
    table.cell(dashTable, 1, 3, volRegimeName, text_color=regimeCol, text_size=size.tiny)
    
    // Live Backtest Metric - Win Rate
    totalTrades = strategy.closedtrades
    winRate = totalTrades > 0 ? (strategy.wintrades / totalTrades) * 100 : 0.0
    table.cell(dashTable, 2, 3, "Win Rate %", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 3, str.tostring(winRate, "0.00") + "%", text_color=winRate >= 50 ? c_green : c_red, text_size=size.tiny)
    
    // Rows 4: Market Cipher B
    table.cell(dashTable, 0, 4, "Market Cipher B Direction", text_color=c_gray, text_size=size.tiny)
    cipherText = cipherSignal.direction == 1 ? "BULLISH WAVE" : "BEARISH WAVE"
    table.cell(dashTable, 1, 4, cipherText, text_color=cipherSignal.direction == 1 ? c_green : c_red, text_size=size.tiny)
    
    // Live Backtest Metric - Profit Factor
    profitFactor = strategy.grossprofit / (strategy.grossloss > 0 ? strategy.grossloss : 1.0)
    table.cell(dashTable, 2, 4, "Profit Factor", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 4, str.tostring(profitFactor, "0.00"), text_color=profitFactor >= 1.5 ? c_green : c_red, text_size=size.tiny)
    
    // Rows 5: Multi-Divergences
    table.cell(dashTable, 0, 5, "Multi-Divergence Consensus", text_color=c_gray, text_size=size.tiny)
    divText = divSignals.consensus == 1 ? "BULLISH DIV" : divSignals.consensus == -1 ? "BEARISH DIV" : "NO DIVERGENCE"
    table.cell(dashTable, 1, 5, divText, text_color=divSignals.consensus == 1 ? c_green : divSignals.consensus == -1 ? c_red : c_gray, text_size=size.tiny)
    
    // Live Backtest Metric - Total Trades
    table.cell(dashTable, 2, 5, "Total Trades", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 5, str.tostring(totalTrades), text_color=c_white, text_size=size.tiny)
    
    // Rows 6: SMC Structure
    table.cell(dashTable, 0, 6, "SMC Structural State", text_color=c_gray, text_size=size.tiny)
    smcText = smcState.mssBull ? "BULL MSS" : smcState.mssBear ? "BEAR MSS" : smcState.liquiditySweepBull ? "BULL SWEEP" : smcState.liquiditySweepBear ? "BEAR SWEEP" : "CONSOLIDATION"
    smcCol = (smcState.mssBull or smcState.liquiditySweepBull) ? c_green : (smcState.mssBear or smcState.liquiditySweepBear) ? c_red : c_gray
    table.cell(dashTable, 1, 6, smcText, text_color=smcCol, text_size=size.tiny)
    
    // Live Backtest Metric - Max Drawdown
    maxDrawdownPercent = (strategy.max_drawdown / strategy.initial_capital) * 100
    table.cell(dashTable, 2, 6, "Max Drawdown", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 6, str.tostring(maxDrawdownPercent, "0.00") + "%", text_color=c_red, text_size=size.tiny)
    
    // Rows 7: Confluence Scores
    table.cell(dashTable, 0, 7, "Confluence Score (L/S)", text_color=c_white, text_size=size.tiny)
    table.cell(dashTable, 1, 7, "Long: " + str.tostring(confluenceScoreLong, "#") + " | Short: " + str.tostring(confluenceScoreShort, "#"), text_color=c_blue, text_size=size.tiny)
    
    // Live Backtest Metric - Daily Performance
    table.cell(dashTable, 2, 7, "Daily PnL / Limit", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 7, str.tostring(dailyPnL, "$0") + " / " + str.tostring(-dailyLossLimit, "$0"), text_color=dailyPnL >= 0 ? c_green : c_red, text_size=size.tiny)
    
    // Rows 8: Strategy Active Control Status
    table.cell(dashTable, 0, 8, "Daily Safe-Trading State", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 1, 8, tradeAllowed ? "ACTIVE (SAFE)" : "BLOCKED", text_color=tradeAllowed ? c_green : c_red, text_size=size.tiny)
    
    // Live Backtest Metric - Consecutive Losses
    table.cell(dashTable, 2, 8, "Consec Losses (Max)", text_color=c_gray, text_size=size.tiny)
    table.cell(dashTable, 3, 8, str.tostring(consecutiveLosses) + " / " + str.tostring(riskMaxConsecutive), text_color=consecutiveLosses > 0 ? c_red : c_green, text_size=size.tiny)

// =============================================================================
// ╔════════════════════════════════════════════════════════════════════════════╗
// ║                     ALERT GENERATION                                     ║
// ╚════════════════════════════════════════════════════════════════════════════╝
// =============================================================================

if finalLong
    alert("IQCE Long Signal | Score: " + str.tostring(confluenceScoreLong, "#") + "% | Vol: " + volRegimeName, alert.freq_once_per_bar_close)

if finalShort
    alert("IQCE Short Signal | Score: " + str.tostring(confluenceScoreShort, "#") + "% | Vol: " + volRegimeName, alert.freq_once_per_bar_close)

======================================================================

4. UICE - Ultra-Institutional Composite Engine (sina)

//@version=6
indicator("UICE - Ultra-Institutional Composite Engine (sina)",
     overlay=true,
     max_lines_count=500,
     max_labels_count=500,
     max_boxes_count=500,
     max_bars_back=5000)

// ═══════════════════════════════════════════════════════════════════════════════
// ║                         PART 1: INPUT CONTROLS
// ═══════════════════════════════════════════════════════════════════════════════
groupMaster = "══════ MASTER CONTROLS ══════"
showDashboard   = input.bool(true, "Show Institutional Dashboard", group=groupMaster, tooltip="Toggle the visual on-screen institutional metrics dashboard.")
showSignals     = input.bool(true, "Show Entry Signals", group=groupMaster, tooltip="Plots entry arrows and detailed signal labels on the chart.")
showZones       = input.bool(true, "Show Liquidity/OB/FVG Zones", group=groupMaster, tooltip="Displays active Order Blocks and Fair Value Gaps zones on the chart.")
enableBacktest  = input.bool(true, "Enable Live Backtest", group=groupMaster, tooltip="Activates the custom historical trade simulation engine.")
backtestCapital = input.float(10000.0, "Backtest Initial Capital ($)", minval=1000.0, step=1000.0, group=groupMaster, tooltip="Initial starting balance for simulated backtesting. Recommended range: $1,000 to $1,000,000.")

// Presets & MTF
groupPreset = "══════ TIMEFRAME ADAPTATION PRESETS ══════"
tf_preset_mode = input.string("Auto-Adapt", "Engine Preset Mode",
     options=["Auto-Adapt", "Scalping (1m-5m)", "Day Trading (15m-30m)", "Swing Trading (1h-4h)", "Position (Daily)", "Manual Control"],
     group=groupPreset, tooltip="Automatically adjusts lookback lengths and thresholds based on style, or hands control over to manual parameters.")
htf_resolution = input.timeframe("240", "Higher Timeframe (HTF) Resolution", group=groupPreset, tooltip="Defines the timeframe for higher timeframe filters. Commonly set to 4x of current timeframe.")

// Layer toggles
groupLayers = "══════ LAYER TOGGLES ══════"
useRegimeLayer     = input.bool(true,  "Layer 1: Market Regime (Bayes + Entropy + Hurst)", group=groupLayers, tooltip="Enables Layer 1: Market Regime classification (Trend strength, Hurst Exponent, Shannon Entropy).")
useLiquidityLayer  = input.bool(true,  "Layer 2: Liquidity Intelligence (DBSCAN + 8-Factor Sweep)", group=groupLayers, tooltip="Enables Layer 2: Liquidity Sweeps detector using DBSCAN and 8-factor sweep engine.")
useStructureLayer  = input.bool(true,  "Layer 3: Structure & Patterns (BOS/CHoCH/MSS + 7 Shadows)", group=groupLayers, tooltip="Enables Layer 3: Structure tracking (BOS/CHoCH/MSS and 7 shadow candle formations).")
useHarmonicLayer   = input.bool(true,  "Layer 3b: Harmonic Patterns (Bat/Butterfly/Crab/Cypher/Shark/5-0)", group=groupLayers, tooltip="Enables Layer 3b: Harmonic Pattern Detection (Bat, Butterfly, Crab, Cypher, Shark, 5-0).")
useImbalanceLayer  = input.bool(true,  "Layer 4: Imbalance & Order Flow (OB + FVG + CVD + Delta)", group=groupLayers, tooltip="Enables Layer 4: Order Flow Imbalances, Order Blocks, FVGs, CVD and Delta.")
useMomentumLayer   = input.bool(true,  "Layer 5: Momentum (WaveTrend/VFI/AO/STC/Firefly/Squeeze)", group=groupLayers, tooltip="Enables Layer 5: Momentum engines (WaveTrend, VFI, AO, STC, Squeeze).")
useWyckoffLayer    = input.bool(true,  "Layer 5b: Wyckoff (Spring/Upthrust/Accumulation/Distribution)", group=groupLayers, tooltip="Enables Layer 5b: Wyckoff range analysis (Springs, Upthrusts, Accumulation/Distribution).")
useQuantLayer      = input.bool(true,  "Layer 6: Quantitative (Kalman + Regression + Monte Carlo)", group=groupLayers, tooltip="Enables Layer 6: Quantitative layer utilizing Kalman filter and Monte Carlo bands.")
usePlaybookLayer   = input.bool(true,  "Layer 6b: Playbook Engine (6 Institutional Patterns)", group=groupLayers, tooltip="Enables Layer 6b: Squeeze Breakouts and Sweep Reversals playbook rules.")
useRiskLayer       = input.bool(true,  "Layer 7: Risk & Execution (Dynamic SL/TP + Kill Switch)", group=groupLayers, tooltip="Enables Layer 7: Dynamic execution with Hurst-adjusted Stop Losses and Take Profits.")

// Engine Manual Parameters (used if Preset Mode is 'Manual Control')
groupManualParams = "══════ ENGINE MANUAL PARAMETERS ══════"
in_swing_liq = input.int(9, "Manual Liquidity Swing Length", minval=2, group=groupManualParams, tooltip="Manual liquidity high/low pivot lookup length. Range: 2 to 50.")
in_swing_str = input.int(5, "Manual Structure Swing Length", minval=2, group=groupManualParams, tooltip="Manual structural break lookup length. Range: 2 to 30.")
in_atr_len   = input.int(14, "Manual ATR Length", minval=5, group=groupManualParams, tooltip="Manual ATR calculation period. Range: 5 to 100.")
in_ob_ratio  = input.float(1.5, "Manual OB Displacement Threshold", minval=1.0, step=0.1, group=groupManualParams, tooltip="Manual Order Block displacement factor of ATR. Range: 1.0 to 5.0.")
in_wt_len_1  = input.int(10, "Manual WaveTrend Length 1", minval=5, group=groupManualParams, tooltip="Manual WaveTrend EMA calculation period. Range: 5 to 50.")
in_wt_len_2  = input.int(21, "Manual WaveTrend Length 2", minval=5, group=groupManualParams, tooltip="Manual WaveTrend SMA smoothed average period. Range: 5 to 100.")
in_vfi_len   = input.int(130, "Manual VFI Length", minval=10, group=groupManualParams, tooltip="Manual Volume Flow Indicator calculation period. Range: 10 to 500.")

// Fusion Engine Thresholds
groupFusionThresh = "══════ FUSION ENGINE THRESHOLDS ══════"
min_long_threshold   = input.float(55.0, "Long Entry Score Threshold (%)", minval=30.0, maxval=90.0, step=1.0, group=groupFusionThresh, tooltip="Minimum total score percentage to trigger a Long signal. Range: 30% to 90%.")
min_short_threshold  = input.float(55.0, "Short Entry Score Threshold (%)", minval=30.0, maxval=90.0, step=1.0, group=groupFusionThresh, tooltip="Minimum total score percentage to trigger a Short signal. Range: 30% to 90%.")
score_diff_threshold = input.float(10.0, "Score Differential Gap (%)", minval=2.0, maxval=30.0, step=1.0, group=groupFusionThresh, tooltip="Minimum score percentage gap required between long and short scores. Range: 2% to 30%.")

// Risk parameters
groupRisk = "══════ RISK & EXECUTION PARAMETERS ══════"
riskPerTrade    = input.float(1.5, "Dynamic Base Risk % per Trade", minval=0.1, maxval=5.0, step=0.1, group=groupRisk, tooltip="Standard capital percentage risked on trade. Range: 0.1% to 5.0%.")
tp1R            = input.float(1.2, "TP1 (R Multiple)", minval=0.5, maxval=5.0, step=0.1, group=groupRisk, tooltip="R-Multiple target for Take Profit 1. Range: 0.5 to 5.0.")
tp2R            = input.float(2.5, "TP2 (R Multiple)", minval=1.0, maxval=8.0, step=0.5, group=groupRisk, tooltip="R-Multiple target for Take Profit 2. Range: 1.0 to 8.0.")
tp3R            = input.float(4.5, "TP3 (R Multiple)", minval=2.0, maxval=12.0, step=0.5, group=groupRisk, tooltip="R-Multiple target for Take Profit 3. Range: 2.0 to 12.0.")
tp1Percent      = input.float(40.0, "TP1 Close %", minval=10.0, maxval=60.0, step=1.0, group=groupRisk, tooltip="Percentage of size closed at Take Profit 1. Range: 10% to 60%.")
tp2Percent      = input.float(40.0, "TP2 Close %", minval=10.0, maxval=60.0, step=1.0, group=groupRisk, tooltip="Percentage of size closed at Take Profit 2. Range: 10% to 60%.")
maxConsecLosses = input.int(6, "Max Consecutive Losses (Kill Switch)", minval=2, maxval=10, group=groupRisk, tooltip="Maximum consecutive losses to trigger institutional circuit breaker (Kill Switch). Range: 2 to 10.")
cooldownBars    = input.int(10, "Kill Switch Cooldown (Bars)", minval=5, maxval=50, group=groupRisk, tooltip="Number of bars to wait after trading halt. Range: 5 to 50.")
slippagePct     = input.float(0.04, "Slippage & Trading Fee % per Trade", minval=0.0, maxval=1.0, step=0.01, group=groupRisk, tooltip="Simulated slippage and fee cost per trade. Range: 0.0% to 1.0%.")

// Visual Customization Settings (Newly Expanded Style Section)
groupStyleDashboard = "══════ DASHBOARD STYLE SETTINGS ══════"
db_bg_color     = input.color(color.new(#0c0d14, 5), "Dashboard Background", group=groupStyleDashboard, tooltip="Background color of the dashboard table.")
db_text_color   = input.color(#e3e4e6, "Dashboard Text Color", group=groupStyleDashboard, tooltip="Main text color of the dashboard.")
db_border_color = input.color(#1a1d29, "Dashboard Border Color", group=groupStyleDashboard, tooltip="Grid border color of dashboard table.")
db_header_color = input.color(#1c2a5c, "Dashboard Header Background", group=groupStyleDashboard, tooltip="Header background color of dashboard.")
db_pos          = input.string("top_right", "Dashboard Position", options=["top_right", "bottom_right", "top_left", "bottom_left"], group=groupStyleDashboard, tooltip="Screen placement of institutional dashboard.")
db_size         = input.string("tiny", "Dashboard Font Size", options=["tiny", "small", "normal"], group=groupStyleDashboard, tooltip="Scaling size of dashboard table text.")

groupStyleSignals = "══════ GRAPHICAL STYLE SETTINGS ══════"
show_emas            = input.bool(true, "Show Institutional EMAs", group=groupStyleSignals, tooltip="Display fast, medium, slow EMAs on the price chart.")
style_ema_fast_color = input.color(#ffd600, "Fast EMA Color", group=groupStyleSignals, tooltip="Fast EMA line color.")
style_ema_mid_color  = input.color(#ff9800, "Medium EMA Color", group=groupStyleSignals, tooltip="Medium EMA line color.")
style_ema_slow_color = input.color(#2962ff, "Slow EMA Color", group=groupStyleSignals, tooltip="Slow EMA line color.")
style_ema_fast_width = input.int(1, "Fast EMA Line Width", minval=1, maxval=5, group=groupStyleSignals, tooltip="Fast EMA line thickness. Range: 1 to 5.")
style_ema_mid_width  = input.int(1, "Medium EMA Line Width", minval=1, maxval=5, group=groupStyleSignals, tooltip="Medium EMA line thickness. Range: 1 to 5.")
style_ema_slow_width = input.int(2, "Slow EMA Line Width", minval=1, maxval=5, group=groupStyleSignals, tooltip="Slow EMA line thickness. Range: 1 to 5.")
ema_fast_len         = input.int(21, "Fast EMA Length", minval=5, group=groupStyleSignals, tooltip="Fast EMA calculation period. Range: 5 to 500.")
ema_mid_len          = input.int(50, "Medium EMA Length", minval=5, group=groupStyleSignals, tooltip="Medium EMA calculation period. Range: 5 to 500.")
ema_slow_len         = input.int(200, "Slow EMA Length", minval=5, group=groupStyleSignals, tooltip="Slow EMA calculation period. Range: 5 to 500.")

groupStyleZones = "══════ LIQUIDITY & ZONES STYLE ══════"
show_ob_boxes     = input.bool(true, "Draw Active Order Blocks", group=groupStyleZones, tooltip="Plot Order Block zones on chart.")
show_fvg_boxes    = input.bool(true, "Draw Active Fair Value Gaps", group=groupStyleZones, tooltip="Plot Fair Value Gaps on chart.")
color_bull_ob     = input.color(color.new(#00e676, 85), "Bullish OB Color", group=groupStyleZones, tooltip="Color fill for bullish order blocks.")
color_bear_ob     = input.color(color.new(#ff5252, 85), "Bearish OB Color", group=groupStyleZones, tooltip="Color fill for bearish order blocks.")
color_bull_fvg    = input.color(color.new(#00e676, 92), "Bullish FVG Color", group=groupStyleZones, tooltip="Color fill for bullish Fair Value Gaps.")
color_bear_fvg    = input.color(color.new(#ff5252, 92), "Bearish FVG Color", group=groupStyleZones, tooltip="Color fill for bearish Fair Value Gaps.")
max_draw_zones    = input.int(8, "Max Zones to Draw (of each type)", minval=2, maxval=30, group=groupStyleZones, tooltip="Maximum count of zones to keep displayed. Range: 2 to 30.")
regime_bg_color   = input.bool(true, "Color Chart Background by Regime", group=groupStyleZones, tooltip="Color chart background to match current trend regime.")
mc_cloud_up_color = input.color(color.new(#00e676, 60), "Monte Carlo Upper Target", group=groupStyleZones, tooltip="Color for bullish Monte Carlo targets.")
mc_cloud_dn_color = input.color(color.new(#ff5252, 60), "Monte Carlo Lower Target", group=groupStyleZones, tooltip="Color for bearish Monte Carlo targets.")

// Session filter
groupSession = "══════ SESSION FILTER ══════"
useSessionFilter = input.bool(false, "Enable Session Filter", group=groupSession, tooltip="Restrict signal calculations to specific sessions.")
sessionLondon    = input.bool(true, "London Session (08-11 UTC)", group=groupSession, tooltip="London session window (08-11 UTC).")
sessionNY        = input.bool(true, "New York Session (13-16 UTC)", group=groupSession, tooltip="New York session window (13-16 UTC).")
sessionAsia      = input.bool(false, "Asia Session (00-03 UTC)", group=groupSession, tooltip="Asia session window (00-03 UTC).")

// ═══════════════════════════════════════════════════════════════════════════════
// ║                         PART 2: TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════════

type RegimeState
    string  regime
    float   confidence
    float   entropy
    float   hurst
    float   trend_strength
    float   volatility_regime

type SweepSignal
    bool    detected
    int     direction
    float   score
    float   price_level
    float   penetration_atr
    float   reclaim_pct
    float   wick_ratio
    bool    volume_spike

type StructureSignal
    bool    bos_bull
    bool    bos_bear
    bool    choch_bull
    bool    choch_bear
    bool    mss_bull
    bool    mss_bear
    float   strength
    int     trend_dir

type PlaybookSignal
    string  name
    int     direction
    float   score
    float   probability
    float   confidence
    int     bar_idx

type WyckoffState
    float   accumulation_prob
    float   distribution_prob
    string  current_phase
    bool    spring_detected
    bool    upthrust_detected
    bool    absorption_detected
    bool    sos_detected
    bool    sow_detected

type OrderBlock
    int     id
    bool    is_bullish
    float   top
    float   bottom
    float   midpoint
    float   strength
    int     created_bar
    bool    is_mitigated
    bool    is_breaker
    int     mitigated_bar
    box     ob_box

type ActiveFVG
    bool    is_bullish
    float   top
    float   bottom
    int     created_bar
    bool    is_mitigated

type MonteCarloResult
    float   cloud_top
    float   cloud_bottom
    float   median
    float   upper_band
    float   lower_band
    int     start_bar

type BacktestStats
    int     total_trades
    int     winning_trades
    int     losing_trades
    float   win_rate
    float   profit_factor
    float   net_profit
    float   max_drawdown
    float   max_drawdown_pct
    float   sharpe_ratio
    float   expectancy
    float   avg_win
    float   avg_loss
    float   avg_rr
    int     max_consecutive_wins
    int     max_consecutive_losses

type TradeLevels
    float   entry
    float   stop_loss
    float   tp1
    float   tp2
    float   tp3
    float   risk_amount
    float   position_size
    float   risk_rr

// ═══════════════════════════════════════════════════════════════════════════════
// ║                         PART 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

f_clamp(float val, float min_val, float max_val) =>
    math.max(min_val, math.min(max_val, val))

f_normalize(float val, float min_val, float max_val) =>
    range_val = max_val - min_val
    if range_val > 0.0
        result = (val - min_val) / range_val * 100.0
        if result > 100.0
            result := 100.0
        else if result < 0.0
            result := 0.0
        result
    else
        50.0

f_zscore(float src, int len) =>
    mean = ta.sma(src, len)
    stdev = ta.stdev(src, len)
    if stdev > 0.0
        (src - mean) / stdev
    else
        0.0

f_percentile(float[] arr, float p) =>
    if array.size(arr) == 0
        0.0
    else
        sorted = array.copy(arr)
        array.sort(sorted, order.ascending)
        idx = math.floor(p / 100.0 * (array.size(sorted) - 1))
        if idx > array.size(sorted) - 1
            idx := array.size(sorted) - 1
        else if idx < 0
            idx := 0
        array.get(sorted, idx)

f_secure_mtf(string tf, float src) =>
    request.security(syminfo.tickerid, tf, src[1], barmerge.gaps_off, barmerge.lookahead_off)

f_session_check() =>
    hour_utc = hour(time, "UTC")
    in_london = hour_utc >= 8 and hour_utc <= 11
    in_ny     = hour_utc >= 13 and hour_utc <= 16
    in_asia   = hour_utc >= 0 and hour_utc <= 3
    (useSessionFilter == false) or (sessionLondon and in_london) or (sessionNY and in_ny) or (sessionAsia and in_asia)

f_clear_visuals(line[] lines, label[] labels, box[] boxes) =>
    while array.size(lines) > 100
        line.delete(array.shift(lines))
    while array.size(labels) > 100
        label.delete(array.shift(labels))
    while array.size(boxes) > 100
        box.delete(array.shift(boxes))

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 4: LAYER 1 - MARKET REGIME DETECTION ENGINE
// ║     (Bayesian Updates + Shannon Entropy + Rescaled Range Hurst)
// ═══════════════════════════════════════════════════════════════════════════════

f_calculate_entropy(series float src, int len, float mean, float stdev) =>
    stdev_val = stdev
    if stdev_val == 0.0
        stdev_val := 1e-6

    c1 = 0
    c2 = 0
    c3 = 0
    c4 = 0
    c5 = 0
    for i = 0 to len - 1
        z = (src[i] - mean) / stdev_val
        if z < -1.5
            c1 := c1 + 1
        else if z >= -1.5 and z < -0.5
            c2 := c2 + 1
        else if z >= -0.5 and z <= 0.5
            c3 := c3 + 1
        else if z > 0.5 and z <= 1.5
            c4 := c4 + 1
        else if z > 1.5
            c5 := c5 + 1

    p1 = float(c1) / len
    p2 = float(c2) / len
    p3 = float(c3) / len
    p4 = float(c4) / len
    p5 = float(c5) / len

    entropy_val = 0.0
    if p1 > 0.0
        entropy_val := entropy_val - p1 * math.log(p1)
    if p2 > 0.0
        entropy_val := entropy_val - p2 * math.log(p2)
    if p3 > 0.0
        entropy_val := entropy_val - p3 * math.log(p3)
    if p4 > 0.0
        entropy_val := entropy_val - p4 * math.log(p4)
    if p5 > 0.0
        entropy_val := entropy_val - p5 * math.log(p5)

    f_normalize(entropy_val, 0.0, 1.61)

f_calculate_hurst_proxy(series float src, int len, float mean, float stdev) =>
    stdev_val = stdev
    if stdev_val == 0.0
        stdev_val := 1e-6

    max_dev = 0.0
    min_dev = 0.0
    cum_sum = 0.0
    for i = 0 to len - 1
        cum_sum := cum_sum + (src[i] - mean)
        if cum_sum > max_dev
            max_dev := cum_sum
        if cum_sum < min_dev
            min_dev := cum_sum
            
    rs = (max_dev - min_dev) / stdev_val
    hurst = 0.5
    if rs > 0.0 and len > 0
        hurst := math.log(rs) / math.log(len)
    if hurst < 0.0
        hurst := 0.0
    else if hurst > 1.0
        hurst := 1.0
    hurst

f_bayesian_regime(float atr_ratio, float wick_ratio, float volume_cv, float prev_prob) =>
    l_strong_up  = math.exp(-math.pow(atr_ratio - 0.8, 2) / 0.2) * math.exp(-math.pow(wick_ratio - 0.3, 2) / 0.15) * math.exp(-math.pow(volume_cv - 1.2, 2) / 0.3)
    l_weak_up    = math.exp(-math.pow(atr_ratio - 0.5, 2) / 0.15) * math.exp(-math.pow(wick_ratio - 0.4, 2) / 0.2)
    l_comp_range = math.exp(-math.pow(atr_ratio - 0.2, 2) / 0.1) * math.exp(-math.pow(wick_ratio - 0.6, 2) / 0.2) * math.exp(-math.pow(volume_cv - 0.5, 2) / 0.2)
    l_exp_range  = math.exp(-math.pow(atr_ratio - 0.4, 2) / 0.15) * math.exp(-math.pow(wick_ratio - 0.5, 2) / 0.2)
    l_choppy     = math.exp(-math.pow(atr_ratio - 0.6, 2) / 0.25) * math.exp(-math.pow(wick_ratio - 0.7, 2) / 0.25) * math.exp(-math.pow(volume_cv - 0.9, 2) / 0.3)

    total_l = l_strong_up + l_weak_up + l_comp_range + l_exp_range + l_choppy
    if total_l < 1e-5
        total_l := 1e-5

    p_strong_up  = (l_strong_up * prev_prob) / total_l
    p_weak_up    = (l_weak_up * prev_prob) / total_l
    p_comp_range = (l_comp_range * (1.0 - prev_prob)) / total_l
    p_exp_range  = (l_exp_range * (1.0 - prev_prob)) / total_l
    p_choppy     = (l_choppy * (1.0 - prev_prob)) / total_l

    new_total = p_strong_up + p_weak_up + p_comp_range + p_exp_range + p_choppy
    if new_total == 0.0
        new_total := 1e-5

    prev_p_strong_up  = p_strong_up
    prev_p_weak_up    = p_weak_up
    prev_p_comp_range = p_comp_range
    prev_p_exp_range  = p_exp_range

    regime = "NEUTRAL"
    confidence = 50.0

    if prev_p_strong_up > 0.3
        regime := "STRONG_TREND_UP"
        confidence := prev_p_strong_up / new_total * 100.0
    else if prev_p_weak_up > 0.3
        regime := "WEAK_TREND_UP"
        confidence := prev_p_weak_up / new_total * 100.0
    else if prev_p_comp_range > 0.35
        regime := "COMPRESSED_RANGE"
        confidence := prev_p_comp_range / new_total * 100.0
    else if prev_p_exp_range > 0.35
        regime := "EXPANDED_RANGE"
        confidence := prev_p_exp_range / new_total * 100.0
    else
        regime := "CHOPPY_RANGE"
        confidence := p_choppy / new_total * 100.0

    [regime, confidence, prev_p_strong_up]

f_regime_engine(float atr_current, float atr_slow, float close_sma, float close_stdev, float vol_sma, float vol_stdev, float adx_val) =>
    atr_ratio = atr_slow != 0.0 ? atr_current / atr_slow : 0.5

    body = math.abs(close - open)
    candle_range = high - low
    wick_ratio = 0.5
    if candle_range > 0.0
        wick_ratio := (candle_range - body) / candle_range

    volume_cv = 1.0
    if vol_sma > 0.0
        volume_cv := vol_stdev / vol_sma

    var float prev_regime_prob = 0.5
    [regime, confidence, new_prob] = f_bayesian_regime(atr_ratio, wick_ratio, volume_cv, prev_regime_prob)
    prev_regime_prob := new_prob

    entropy_val = f_calculate_entropy(close, 50, close_sma, close_stdev)
    hurst_val = f_calculate_hurst_proxy(close, 50, close_sma, close_stdev)

    trend_strength = adx_val * (0.5 + hurst_val * 0.5)
    trend_strength := f_normalize(trend_strength, 0.0, 100.0)

    volatility_regime = atr_ratio
    volatility_regime := f_normalize(volatility_regime, 0.2, 2.0)

    RegimeState.new(regime, confidence, entropy_val, hurst_val, trend_strength, volatility_regime)

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 5: LAYER 2 - LIQUIDITY INTELLIGENCE ENGINE
// ║    (Adaptive DBSCAN + 8-Factor Sweep Scoring)
// ═══════════════════════════════════════════════════════════════════════════════

f_dbscan_cluster(float[] prices, float[] strengths, float eps, int min_pts) =>
    n = array.size(prices)
    if n < min_pts
        [array.new_float(), array.new_float(), array.new_int()]
    else
        cluster_id = array.new_int(n, -1)
        current_cluster = 0
        for i = 0 to n - 1
            if array.get(cluster_id, i) == -1
                neighbors = 0
                for j = 0 to n - 1
                    if i != j and math.abs(array.get(prices, i) - array.get(prices, j)) <= eps
                        neighbors := neighbors + 1
                if neighbors >= min_pts - 1
                    current_cluster := current_cluster + 1
                    array.set(cluster_id, i, current_cluster)
                    for j = 0 to n - 1
                        if i != j and array.get(cluster_id, j) == -1 and math.abs(array.get(prices, i) - array.get(prices, j)) <= eps
                            array.set(cluster_id, j, current_cluster)
                            
        centers = array.new_float()
        center_strengths = array.new_float()
        sizes = array.new_int()

        if current_cluster > 0
            for c = 1 to current_cluster
                sum_price = 0.0
                sum_strength = 0.0
                cnt = 0
                for i = 0 to n - 1
                    if array.get(cluster_id, i) == c
                        sum_price := sum_price + array.get(prices, i)
                        sum_strength := sum_strength + array.get(strengths, i)
                        cnt := cnt + 1
                if cnt > 0
                    array.push(centers, sum_price / cnt)
                    array.push(center_strengths, sum_strength / cnt)
                    array.push(sizes, cnt)

        [centers, center_strengths, sizes]

f_sweep_scoring(float penetration, float reclaim_pct, float wick_ratio, bool body_ok,
                 float age, float volume_ratio, float mss_proximity, float atr_ref) =>
    target_pen = 0.35
    halfspan = 0.65
    pen_score = 1.0 - math.abs(penetration - target_pen) / halfspan
    if pen_score > 1.0
        pen_score := 1.0
    else if pen_score < 0.0
        pen_score := 0.0

    reclaim_score = reclaim_pct / 50.0
    if reclaim_score > 1.0
        reclaim_score := 1.0
    else if reclaim_score < 0.0
        reclaim_score := 0.0

    wick_score = wick_ratio / 1.5
    if wick_score > 1.0
        wick_score := 1.0
    else if wick_score < 0.0
        wick_score := 0.0

    body_score = 1.0
    if body_ok == false
        body_score := 0.3

    age_score = 1.0 - age / 100.0
    if age_score > 1.0
        age_score := 1.0
    else if age_score < 0.0
        age_score := 0.0

    vol_score = volume_ratio / 2.0
    if vol_score > 1.0
        vol_score := 1.0
    else if vol_score < 0.0
        vol_score := 0.0

    mss_score = 0.0
    if atr_ref > 0.0
        mss_score := mss_proximity / atr_ref
        if mss_score > 1.0
            mss_score := 1.0
        else if mss_score < 0.0
            mss_score := 0.0

    total_weight = 16.0 + 18.0 + 14.0 + 8.0 + 12.0 + 16.0 + 16.0
    raw_score = (pen_score * 16.0) + (reclaim_score * 18.0) + (wick_score * 14.0) + (body_score * 8.0) + (age_score * 12.0) + (vol_score * 16.0) + (mss_score * 16.0)
    result = raw_score / total_weight * 100.0
    if result > 100.0
        result := 100.0
    result

f_liquidity_engine(float ph, float pl, float vol_sma_20, float atr_val, int swing_len) =>
    var array<float> swing_highs    = array.new_float()
    var array<float> swing_lows     = array.new_float()
    var array<float> swing_high_vol = array.new_float()
    var array<float> swing_low_vol  = array.new_float()
    var array<int> swing_high_bars  = array.new_int()
    var array<int> swing_low_bars   = array.new_int()

    if not na(ph) and bar_index >= swing_len
        array.unshift(swing_highs, ph)
        array.unshift(swing_high_vol, volume[swing_len])
        array.unshift(swing_high_bars, bar_index - swing_len)
    if not na(pl) and bar_index >= swing_len
        array.unshift(swing_lows, pl)
        array.unshift(swing_low_vol, volume[swing_len])
        array.unshift(swing_low_bars, bar_index - swing_len)

    while array.size(swing_highs) > 100
        array.pop(swing_highs)
        array.pop(swing_high_vol)
        array.pop(swing_high_bars)
    while array.size(swing_lows) > 100
        array.pop(swing_lows)
        array.pop(swing_low_vol)
        array.pop(swing_low_bars)

    sweep_bull      = false
    sweep_bear      = false
    sweep_score     = 0.0
    sweep_price     = 0.0
    penetration_val = 0.0
    reclaim_val     = 0.0
    wick_val        = 0.0
    vol_spike       = false

    atr_sec = atr_val > 0.0 ? atr_val : 1e-6

    if array.size(swing_lows) > 0
        recent_low = array.get(swing_lows, 0)
        recent_low_bar = array.get(swing_low_bars, 0)
        if low < recent_low
            penetration_val := (recent_low - low) / atr_sec
            reclaim_val     := (close - recent_low) / (high - low + 1e-6) * 100.0
            wick_val        := (math.min(open, close) - low) / (high - low + 1e-6)
            body_ok         = close > open
            age             = float(bar_index - recent_low_bar)
            volume_ratio    = vol_sma_20 > 0.0 ? volume / vol_sma_20 : 1.0
            vol_spike       := volume_ratio > 1.5
            mss_prox        = 0.0
            if array.size(swing_highs) > 0 and close > array.get(swing_highs, 0)
                mss_prox := close - array.get(swing_highs, 0)

            sweep_bull  := true
            sweep_score := f_sweep_scoring(penetration_val, reclaim_val, wick_val, body_ok,
                                           age, volume_ratio, mss_prox, atr_sec)
            sweep_price := recent_low

    if array.size(swing_highs) > 0
        recent_high = array.get(swing_highs, 0)
        recent_high_bar = array.get(swing_high_bars, 0)
        if high > recent_high and close < recent_high
            penetration_val := (high - recent_high) / atr_sec
            reclaim_val     := (recent_high - close) / (high - low + 1e-6) * 100.0
            wick_val        := (high - math.max(open, close)) / (high - low + 1e-6)
            body_ok         = close < open
            age             = float(bar_index - recent_high_bar)
            volume_ratio    = vol_sma_20 > 0.0 ? volume / vol_sma_20 : 1.0
            vol_spike       := volume_ratio > 1.5
            mss_prox        = 0.0
            if array.size(swing_lows) > 0 and close < array.get(swing_lows, 0)
                mss_prox := array.get(swing_lows, 0) - close

            sweep_bear  := true
            sweep_score := f_sweep_scoring(penetration_val, reclaim_val, wick_val, body_ok,
                                           age, volume_ratio, mss_prox, atr_sec)
            sweep_price := recent_high

    SweepSignal.new(sweep_bull or sweep_bear, sweep_bull ? 1 : sweep_bear ? -1 : 0, sweep_score, sweep_price, penetration_val, reclaim_val, wick_val, vol_spike)

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 6: LAYER 3 - STRUCTURE TRACKING ENGINE
// ║    (BOS / CHoCH / MSS + Multi-Timeframe Filter)
// ═══════════════════════════════════════════════════════════════════════════════

f_structure_engine(float ph, float pl, float htf_close, float htf_ema) =>
    var float last_high = na
    var float last_low = na
    var int trend_dir = 0

    if not na(ph)
        last_high := ph
    if not na(pl)
        last_low := pl

    bos_bull = false
    bos_bear = false
    if not na(last_high) and close > last_high
        bos_bull := true
    if not na(last_low) and close < last_low
        bos_bear := true

    choch_bull = false
    choch_bear = false
    if bos_bull and trend_dir == -1
        choch_bull := true
    if bos_bear and trend_dir == 1
        choch_bear := true

    if bos_bull
        trend_dir := 1
    else if bos_bear
        trend_dir := -1

    mss_bull = false
    mss_bear = false
    if choch_bull and not na(htf_close) and not na(htf_ema) and htf_close > htf_ema
        mss_bull := true
    if choch_bear and not na(htf_close) and not na(htf_ema) and htf_close < htf_ema
        mss_bear := true

    strength = 50.0
    if bos_bull or bos_bear
        strength := 70.0
    if choch_bull or choch_bear
        strength := 85.0
    if mss_bull or mss_bear
        strength := 100.0

    StructureSignal.new(bos_bull, bos_bear, choch_bull, choch_bear, mss_bull, mss_bear, strength, trend_dir)

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 7: LAYER 3b - SHADOW PATTERNS (Hanzo)
// ═══════════════════════════════════════════════════════════════════════════════

f_shadow_patterns(float atr_val, float highest_20, float lowest_20, float highest_8, float lowest_8) =>
    body = math.abs(close - open)
    range_hl = high - low
    upper_shadow = high - math.max(open, close)
    lower_shadow = math.min(open, close) - low

    // ST1: Double Shadow Doji
    st1_bull = false
    st1_bear = false
    if range_hl > 0.0 and body / range_hl <= 0.25
        if lower_shadow > upper_shadow * 1.5
            st1_bull := true
        if upper_shadow > lower_shadow * 1.5
            st1_bear := true

    // ST2: Stop Hunt
    st2_bull = false
    st2_bear = false
    if bar_index >= 2
        prev_body_high = math.max(close[1], open[1])
        prev_body_low = math.min(close[1], open[1])
        min_pen = atr_val * 0.2
        if high > prev_body_high and upper_shadow >= min_pen and close <= prev_body_high
            st2_bear := true
        if low < prev_body_low and lower_shadow >= min_pen and close >= prev_body_low
            st2_bull := true

    // ST3: Double Shadow Confirmation
    st3_bull = false
    st3_bear = false
    if bar_index >= 6
        for offset = 2 to 6
            if lower_shadow[offset] > 0.0 and lower_shadow > 0.0
                diff_ratio = math.abs(lower_shadow[offset] - lower_shadow) / math.max(lower_shadow[offset], lower_shadow)
                if diff_ratio <= 0.15
                    middle_ok = true
                    for m = 1 to offset - 1
                        if low[m] <= lower_shadow[offset] * 0.88
                            middle_ok := false
                            break
                    if middle_ok
                        st3_bull := true
                        break
            if upper_shadow[offset] > 0.0 and upper_shadow > 0.0
                diff_ratio = math.abs(upper_shadow[offset] - upper_shadow) / math.max(upper_shadow[offset], upper_shadow)
                if diff_ratio <= 0.15
                    middle_ok = true
                    for m = 1 to offset - 1
                        if high[m] >= upper_shadow[offset] * 1.12
                            middle_ok := false
                            break
                    if middle_ok
                        st3_bear := true
                        break

    // ST4: Shadow Quasimodo
    st4_bull = false
    st4_bear = false
    swing_lookback = 5
    if bar_index >= swing_lookback * 3
        for i = swing_lookback to swing_lookback * 2
            is_swing_high = true
            for j = 1 to swing_lookback
                if high[i + j] > high[i] or high[i - j] > high[i]
                    is_swing_high := false
                    break
            if is_swing_high
                left_low = low[i + swing_lookback]
                right_low = low[i - swing_lookback]
                if left_low < low[i] and right_low > left_low
                    st4_bear := true
                    break

        for i = swing_lookback to swing_lookback * 2
            is_swing_low = true
            for j = 1 to swing_lookback
                if low[i + j] < low[i] or low[i - j] < low[i]
                    is_swing_low := false
                    break
            if is_swing_low
                left_high = high[i + swing_lookback]
                right_high = high[i - swing_lookback]
                if left_high > high[i] and right_high < left_high
                    st4_bull := true
                    break

    // ST5: Shadow Support / Resistance
    st5_valid = false
    st5_upper = 0.0
    st5_lower = 0.0
    zone_lookback = 15
    min_touches = 3
    if bar_index >= zone_lookback * 2
        for i = 1 to zone_lookback
            test_level = high[i]
            touch_count = 0
            for j = 0 to zone_lookback * 2
                if j > bar_index
                    break
                if math.abs(high[j] - test_level) <= atr_val * 0.15
                    touch_count := touch_count + 1
            if touch_count >= min_touches
                st5_upper := test_level
                st5_valid := true
                break
        for i = 1 to zone_lookback
            test_level = low[i]
            touch_count = 0
            for j = 0 to zone_lookback * 2
                if j > bar_index
                    break
                if math.abs(low[j] - test_level) <= atr_val * 0.15
                    touch_count := touch_count + 1
            if touch_count >= min_touches
                st5_lower := test_level
                st5_valid := true
                break

    // ST6: Shadow Fakeout
    st6_bull = false
    st6_bear = false
    base_lookback = 20
    if bar_index >= base_lookback
        penetration_pct = 0.12
        if not na(highest_20) and high[1] > highest_20 * (1.0 + penetration_pct) and close[1] < highest_20
            st6_bear := true
        if not na(lowest_20) and low[1] < lowest_20 * (1.0 - penetration_pct) and close[1] > lowest_20
            st6_bull := true

    // ST7: Shadow Compression
    st7_valid = false
    compression_bars = 8
    max_range_atr = 0.4
    if bar_index >= compression_bars
        current_range = highest_8 - lowest_8
        is_compressed = current_range <= atr_val * max_range_atr
        upper_touches = 0
        lower_touches = 0
        for i = 0 to compression_bars - 1
            if math.abs(high[i] - highest_8) <= atr_val * 0.08
                upper_touches := upper_touches + 1
            if math.abs(low[i] - lowest_8) <= atr_val * 0.08
                lower_touches := lower_touches + 1
        if is_compressed and upper_touches >= 2 and lower_touches >= 2
            st7_valid := true

    [st1_bull, st1_bear, st2_bull, st2_bear, st3_bull, st3_bear,
     st4_bull, st4_bear, st5_valid, st5_upper, st5_lower,
     st6_bull, st6_bear, st7_valid]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 8: LAYER 3c - HARMONIC PATTERNS ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

f_harmonic_patterns(float ph, float pl) =>
    var array<float> swing_points = array.new_float()
    var array<int> swing_types    = array.new_int()

    if not na(ph)
        array.unshift(swing_points, ph)
        array.unshift(swing_types, 1)
    if not na(pl)
        array.unshift(swing_points, pl)
        array.unshift(swing_types, -1)

    while array.size(swing_points) > 20
        array.pop(swing_points)
        array.pop(swing_types)

    bat_bull       = false
    bat_bear       = false
    butterfly_bull = false
    butterfly_bear = false
    crab_bull      = false
    crab_bear      = false
    cypher_bull    = false
    cypher_bear    = false
    shark_bull     = false
    shark_bear     = false
    five0_bull     = false
    five0_bear     = false

    if array.size(swing_points) >= 5 and array.size(swing_types) >= 5
        X      = array.get(swing_points, 4)
        A      = array.get(swing_points, 3)
        B      = array.get(swing_points, 2)
        C      = array.get(swing_points, 1)
        D      = array.get(swing_points, 0)
        type_X = array.get(swing_types, 4)
        type_A = array.get(swing_types, 3)

        if type_X == 1 and type_A == -1
            XA = math.abs(A - X)
            AB = math.abs(B - A)
            BC = math.abs(C - B)
            CD = math.abs(D - C)

            if XA > 0.0
                retrace_AB = AB / XA
                retrace_BC = BC / XA
                ext_CD     = CD / XA

                if retrace_AB >= 0.382 and retrace_AB <= 0.500 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 1.618 and ext_CD <= 2.618
                    bat_bull := true
                if retrace_AB >= 0.786 and retrace_AB <= 0.886 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 1.270 and ext_CD <= 1.618
                    butterfly_bull := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.886 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 2.240 and ext_CD <= 3.618
                    crab_bull := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.618 and retrace_BC >= 1.130 and retrace_BC <= 1.414 and ext_CD >= 0.786 and ext_CD <= 1.000
                    cypher_bull := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.618 and retrace_BC >= 1.130 and retrace_BC <= 1.618 and ext_CD >= 1.618 and ext_CD <= 2.240
                    shark_bull := true
                if retrace_AB >= 1.130 and retrace_AB <= 1.618 and retrace_BC >= 1.618 and retrace_BC <= 2.240 and ext_CD >= 0.500 and ext_CD <= 0.886
                    five0_bull := true

        if type_X == -1 and type_A == 1
            XA = math.abs(A - X)
            AB = math.abs(B - A)
            BC = math.abs(C - B)
            CD = math.abs(D - C)

            if XA > 0.0
                retrace_AB = AB / XA
                retrace_BC = BC / XA
                ext_CD     = CD / XA

                if retrace_AB >= 0.382 and retrace_AB <= 0.500 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 1.618 and ext_CD <= 2.618
                    bat_bear := true
                if retrace_AB >= 0.786 and retrace_AB <= 0.886 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 1.270 and ext_CD <= 1.618
                    butterfly_bear := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.886 and retrace_BC >= 0.382 and retrace_BC <= 0.886 and ext_CD >= 2.240 and ext_CD <= 3.618
                    crab_bear := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.618 and retrace_BC >= 1.130 and retrace_BC <= 1.414 and ext_CD >= 0.786 and ext_CD <= 1.000
                    cypher_bear := true
                if retrace_AB >= 0.382 and retrace_AB <= 0.618 and retrace_BC >= 1.130 and retrace_BC <= 1.618 and ext_CD >= 1.618 and ext_CD <= 2.240
                    shark_bear := true
                if retrace_AB >= 1.130 and retrace_AB <= 1.618 and retrace_BC >= 1.618 and retrace_BC <= 2.240 and ext_CD >= 0.500 and ext_CD <= 0.886
                    five0_bear := true

    [bat_bull, bat_bear, butterfly_bull, butterfly_bear, crab_bull, crab_bear, cypher_bull, cypher_bear, shark_bull, shark_bear, five0_bull, five0_bear]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 9: LAYER 4 - ORDER FLOW IMBALANCE ENGINE
// ║    (Order Blocks + Fair Value Gaps + CVD + Delta)
// ═══════════════════════════════════════════════════════════════════════════════

f_imbalance_engine(float atr_val, int struct_trend_dir, float cvd, float cvd_signal, float delta_smooth, float volume_ma_20, float ob_ratio_thresh, OrderBlock[] order_blocks) =>
    var int next_ob_id = 0

    candle_range    = high - low
    range_expansion = candle_range > atr_val * 0.8
    body_ratio      = math.abs(close - open) / (candle_range + 1e-6)
    impulse_up      = close > open and body_ratio > 0.6 and range_expansion
    impulse_down    = close < open and body_ratio > 0.6 and range_expansion

    displacement_ratio = candle_range / (atr_val + 1e-6)
    displacement_up    = impulse_up and displacement_ratio > ob_ratio_thresh
    displacement_down  = impulse_down and displacement_ratio > ob_ratio_thresh

    if displacement_up and bar_index >= 10
        for i = 1 to 10
            if close[i] < open[i]
                ob_top = math.max(open[i], close[i])
                ob_bottom = math.min(open[i], close[i])
                new_ob = OrderBlock.new(next_ob_id, true, ob_top, ob_bottom, (ob_top + ob_bottom)/2.0,
                                        displacement_ratio * 50.0, bar_index, false, false, 0, na)
                array.unshift(order_blocks, new_ob)
                next_ob_id := next_ob_id + 1
                break

    if displacement_down and bar_index >= 10
        for i = 1 to 10
            if close[i] > open[i]
                ob_top = math.max(open[i], close[i])
                ob_bottom = math.min(open[i], close[i])
                new_ob = OrderBlock.new(next_ob_id, false, ob_top, ob_bottom, (ob_top + ob_bottom)/2.0,
                                        displacement_ratio * 50.0, bar_index, false, false, 0, na)
                array.unshift(order_blocks, new_ob)
                next_ob_id := next_ob_id + 1
                break

    if array.size(order_blocks) > 0
        for i = 0 to array.size(order_blocks) - 1
            ob = array.get(order_blocks, i)
            if ob.is_mitigated == false
                if ob.is_bullish and low <= ob.bottom
                    ob.is_mitigated  := true
                    ob.mitigated_bar := bar_index
                else if ob.is_bullish and low < ob.top
                    ob.is_breaker := true
                if ob.is_bullish == false and high >= ob.top
                    ob.is_mitigated  := true
                    ob.mitigated_bar := bar_index
                    if low < ob.bottom
                        ob.is_breaker := true

    while array.size(order_blocks) > 20
        old_ob = array.pop(order_blocks)
        if not na(old_ob.ob_box)
            box.delete(old_ob.ob_box)

    fvg_bull = false
    if bar_index >= 2 and low > high[2] and (low - high[2]) > atr_val * 0.15
        fvg_bull := true

    fvg_bear = false
    if bar_index >= 2 and high < low[2] and (low[2] - high) > atr_val * 0.15
        fvg_bear := true

    cvd_bull   = cvd > cvd_signal
    cvd_bear   = cvd < cvd_signal
    delta_bull = delta_smooth > 0.0
    delta_bear = delta_smooth < 0.0
    absorption = volume > volume_ma_20 * 1.5 and candle_range < atr_val * 0.5

    best_ob_direction = 0
    best_ob_score     = 50.0
    if array.size(order_blocks) > 0
        nearest_ob = array.get(order_blocks, 0)
        if nearest_ob.is_mitigated == false
            if nearest_ob.is_bullish
                best_ob_direction := 1
                if low <= nearest_ob.top and low >= nearest_ob.bottom
                    best_ob_score := 100.0
                else
                    dist_to_ob = math.min(math.abs(close - nearest_ob.top), math.abs(close - nearest_ob.bottom))
                    best_ob_score := f_normalize(nearest_ob.strength / (dist_to_ob / (atr_val + 1e-6) + 1.0), 0.0, 100.0)
            else
                best_ob_direction := -1
                if high >= nearest_ob.bottom and high <= nearest_ob.top
                    best_ob_score := 100.0
                else
                    dist_to_ob = math.min(math.abs(close - nearest_ob.top), math.abs(close - nearest_ob.bottom))
                    best_ob_score := f_normalize(nearest_ob.strength / (dist_to_ob / (atr_val + 1e-6) + 1.0), 0.0, 100.0)

    [fvg_bull, fvg_bear, best_ob_direction, best_ob_score, cvd_bull, cvd_bear, delta_bull, delta_bear, absorption, order_blocks]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 10: LAYER 5 - MOMENTUM ENGINE
// ║    (WaveTrend + VFI + AO + STC + Firefly + Squeeze)
// ═══════════════════════════════════════════════════════════════════════════════

f_momentum_engine(float wt1, float wt2, float vfi, float vfi_signal, float vfi_vave, float ao, float ao_signal, float ao_sma_100, float stc, float ww_fly, bool sqz_on, float mom_hist) =>
    wt_cross_bull = ta.crossover(wt1, wt2) and wt1 <= -40.0
    wt_cross_bear = ta.crossunder(wt1, wt2) and wt1 >= 40.0
    wt_bull       = wt1 > wt2
    wt_bear       = wt1 < wt2
    wt_oversold   = wt1 <= -40.0
    wt_overbought = wt1 >= 40.0
    wt_score      = f_normalize((wt1 + 60.0) / 120.0 * 100.0, 0.0, 100.0)

    vfi_bull   = vfi > vfi_signal
    vfi_bear   = vfi < vfi_signal
    vfi_score  = f_normalize(vfi / (vfi_vave + 1e-6) * 100.0, -100.0, 100.0)

    ao_cross_bull = ta.crossover(ao, ao_signal)
    ao_cross_bear = ta.crossunder(ao, ao_signal)
    ao_bull       = ao > ao_signal and ao > 0.0
    ao_bear       = ao < ao_signal and ao < 0.0
    ao_score      = f_normalize(ao, -ta.atr(100), ta.atr(100))

    stc_bull       = stc > nz(stc[1], 50.0)
    stc_bear       = stc < nz(stc[1], 50.0)
    stc_oversold   = stc <= 25.0
    stc_overbought = stc >= 75.0
    stc_score      = f_normalize(stc, 0.0, 100.0)

    firefly_bull  = ww_fly > 50.0 and ww_fly > ww_fly[1]
    firefly_bear  = ww_fly < 50.0 and ww_fly < ww_fly[1]
    firefly_score = ww_fly

    // FIX: Replaced ta.change(bool) logic with direct shifted check
    sqz_release = sqz_on[1] and not sqz_on
    mom_rising  = mom_hist > mom_hist[1]

    bull_mom_score = 0.0
    if wt_cross_bull
        bull_mom_score := bull_mom_score + 20.0
    else if wt_bull
        bull_mom_score := bull_mom_score + 10.0
    if vfi_bull
        bull_mom_score := bull_mom_score + 15.0
    if ao_cross_bull
        bull_mom_score := bull_mom_score + 15.0
    else if ao_bull
        bull_mom_score := bull_mom_score + 10.0
    if stc_bull
        bull_mom_score := bull_mom_score + 15.0
    else if stc_oversold
        bull_mom_score := bull_mom_score + 10.0
    if firefly_bull
        bull_mom_score := bull_mom_score + 15.0
    if sqz_release and mom_rising
        bull_mom_score := bull_mom_score + 20.0

    bear_mom_score = 0.0
    if wt_cross_bear
        bear_mom_score := bear_mom_score + 20.0
    else if wt_bear
        bear_mom_score := bear_mom_score + 10.0
    if vfi_bear
        bear_mom_score := bear_mom_score + 15.0
    if ao_cross_bear
        bear_mom_score := bear_mom_score + 15.0
    else if ao_bear
        bear_mom_score := bear_mom_score + 10.0
    if stc_bear
        bear_mom_score := bear_mom_score + 15.0
    else if stc_overbought
        bear_mom_score := bear_mom_score + 10.0
    if firefly_bear
        bear_mom_score := bear_mom_score + 15.0
    if sqz_release and not mom_rising
        bear_mom_score := bear_mom_score + 20.0

    if bull_mom_score > 100.0
        bull_mom_score := 100.0
    if bear_mom_score > 100.0
        bear_mom_score := 100.0

    [wt_cross_bull, wt_cross_bear, wt_bull, wt_bear, wt_oversold, wt_overbought, wt_score,
     vfi_bull, vfi_bear, vfi_score,
     ao_cross_bull, ao_cross_bear, ao_bull, ao_bear, ao_score,
     stc_bull, stc_bear, stc_oversold, stc_overbought, stc_score,
     firefly_bull, firefly_bear, firefly_score,
     sqz_on, sqz_release, mom_rising, bull_mom_score, bear_mom_score]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 11: LAYER 5b - WYCKOFF ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

f_wyckoff_engine(float atr, float h_sw, float l_sw, float vol_sma_20) =>
    accum_prob = 50.0
    dist_prob  = 50.0
    phase      = "C"
    spring     = false
    upthrust   = false
    absorption = false
    sos        = false
    sow        = false

    if not na(h_sw) and not na(l_sw)
        range_size = h_sw - l_sw
        if range_size > 0.0
            pct_pos = (close - l_sw) / range_size
            if pct_pos <= 0.15 and volume > vol_sma_20 * 1.2 and close > low
                spring := true
                accum_prob := 80.0
                phase := "D"
            if pct_pos >= 0.85 and volume > vol_sma_20 * 1.2 and close < high
                upthrust := true
                dist_prob := 80.0
                phase := "D"
            if pct_pos >= 0.50 and pct_pos <= 0.70 and volume > vol_sma_20
                absorption := true
                phase := "C"

    WyckoffState.new(accum_prob, dist_prob, phase, spring, upthrust, absorption, sos, sow)

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 12: LAYER 6 - QUANTITATIVE ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

f_quant_engine(float atr) =>
    var float x_est = close
    var float p_est = 1.0
    float q = 0.01
    float r = 0.1
    float p_temp = p_est + q
    float k_gain = p_temp / (p_temp + r)
    x_est := x_est + k_gain * (close - x_est)
    p_est := (1.0 - k_gain) * p_temp

    kf_slope = x_est - nz(x_est[1], x_est)
    kf_prev_slope = nz(x_est[1], x_est) - nz(x_est[2], x_est)
    kf_accel = kf_slope - kf_prev_slope

    norm_slope = f_clamp(kf_slope / (atr + 1e-6) * 10.0, -50.0, 50.0)
    norm_accel = f_clamp(kf_accel / (atr + 1e-6) * 10.0, -25.0, 25.0)

    z = f_zscore(close, 20)
    mean_rev_prob = f_clamp(50.0 + (math.abs(z) * 15.0), 0.0, 100.0)
    trend_cont_prob = 100.0 - mean_rev_prob

    quant_score = 50.0
    if kf_slope > 0.0
        quant_score := quant_score + 15.0
    else
        quant_score := quant_score - 15.0
    if z > 2.0
        quant_score := quant_score - 25.0
    else if z < -2.0
        quant_score := quant_score + 25.0
    quant_score := f_clamp(quant_score, 0.0, 100.0)

    [x_est, norm_slope, norm_accel, z, mean_rev_prob, trend_cont_prob, quant_score]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 13: LAYER 6b - PLAYBOOK ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

f_playbook_engine(
    float sweep_score, float struct_strength, float ob_score, float constant_val,
    float wyckoff_acc, float mom_score, int trend_val,
    bool sweep_bull, bool sweep_bear,
    bool spring_detected, bool upthrust_detected,
    bool fvg_bull, bool fvg_bear, int ob_dir, float ob_str,
    int struct_dir, bool sqz_rel) =>

    active_playbooks = array.new<PlaybookSignal>()

    if sweep_bull and struct_dir == 1
        array.push(active_playbooks, PlaybookSignal.new("SWEEP_REVERSAL", 1, sweep_score, 85.0, 90.0, bar_index))
    if sweep_bear and struct_dir == -1
        array.push(active_playbooks, PlaybookSignal.new("SWEEP_REVERSAL", -1, sweep_score, 85.0, 90.0, bar_index))

    if spring_detected
        array.push(active_playbooks, PlaybookSignal.new("WYCKOFF_RECLAIM", 1, wyckoff_acc, 80.0, 85.0, bar_index))
    if upthrust_detected
        array.push(active_playbooks, PlaybookSignal.new("WYCKOFF_RECLAIM", -1, wyckoff_acc, 80.0, 85.0, bar_index))

    if fvg_bull and ob_dir == 1 and ob_str > 60.0
        array.push(active_playbooks, PlaybookSignal.new("ORDER_FLOW_CONVERGE", 1, ob_str, 75.0, 80.0, bar_index))
    if fvg_bear and ob_dir == -1 and ob_str > 60.0
        array.push(active_playbooks, PlaybookSignal.new("ORDER_FLOW_CONVERGE", -1, ob_str, 75.0, 80.0, bar_index))

    if sqz_rel and trend_val != 0
        array.push(active_playbooks, PlaybookSignal.new("SQUEEZE_BREAKOUT", trend_val, mom_score, 70.0, 75.0, bar_index))

    selected = PlaybookSignal.new("NONE", 0, 0.0, 0.0, 0.0, bar_index)
    if array.size(active_playbooks) > 0
        float max_score = -1.0
        for i = 0 to array.size(active_playbooks) - 1
            pb = array.get(active_playbooks, i)
            if pb.score > max_score
                max_score := pb.score
                selected := pb

    [selected, active_playbooks]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 14: LAYER 7 - RISK & EXECUTION ENGINE
// ║   (Dynamically Scaled Risk & Reward based on Hurst Exponent)
// ═══════════════════════════════════════════════════════════════════════════════

f_risk_engine(float entry_p, int dir, float atr, float h_sw, float l_sw, float trend_str, float vol_reg, float hurst_val) =>
    hurst_multiplier = 0.6 + nz(hurst_val, 0.5) * 1.4

    float stop_loss_p = 0.0
    if dir == 1
        stop_loss_p := not na(l_sw) ? math.min(l_sw, entry_p - (atr * 2.0)) : entry_p - (atr * 2.5)
        if stop_loss_p > entry_p - (atr * 0.5)
            stop_loss_p := entry_p - (atr * 0.5)
    else
        stop_loss_p := not na(h_sw) ? math.max(h_sw, entry_p + (atr * 2.0)) : entry_p + (atr * 2.5)
        if stop_loss_p < entry_p + (atr * 0.5)
            stop_loss_p := entry_p + (atr * 0.5)

    risk_pips     = math.abs(entry_p - stop_loss_p)
    risk_amount   = 10000.0 * (riskPerTrade / 100.0) // fallback base capital
    position_size = risk_pips > 0.0 ? risk_amount / risk_pips : 0.0

    float tp1 = 0.0
    float tp2 = 0.0
    float tp3 = 0.0

    if dir == 1
        tp1 := entry_p + risk_pips * tp1R * hurst_multiplier
        tp2 := entry_p + risk_pips * tp2R * hurst_multiplier
        tp3 := entry_p + risk_pips * tp3R * hurst_multiplier
    else
        tp1 := entry_p - risk_pips * tp1R * hurst_multiplier
        tp2 := entry_p - risk_pips * tp2R * hurst_multiplier
        tp3 := entry_p - risk_pips * tp3R * hurst_multiplier

    risk_rr = risk_pips > 0.0 ? (tp3 - entry_p) / risk_pips : 0.0
    [entry_p, stop_loss_p, tp1, tp2, tp3, risk_amount, position_size, risk_rr]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 15: CORE FUSION ENGINE DEFINITION
// ║      (Dynamic Consensus and Adaptive Scoring Weights Matrix)
// ═══════════════════════════════════════════════════════════════════════════════

f_fusion_engine(
     RegimeState regime, SweepSignal sweep, StructureSignal structure,
     float shadow_bull_norm, float shadow_bear_norm,
     float struct_bull_score, float struct_bear_score,
     float sweep_bull_score, float sweep_bear_score,
     float harm_bull_norm, float harm_bear_norm,
     bool fvg_bull, bool fvg_bear, int ob_direction, float ob_score,
     bool cvd_bull, bool cvd_bear, bool delta_bull, bool delta_bear, bool absorption,
     float bull_mom_score, float bear_mom_score, WyckoffState wyckoff, float quant_score_norm, PlaybookSignal playbook,
     float min_l_thresh, float min_s_thresh, float diff_thresh) =>

    w_structure = 0.20
    w_liquidity = 0.20
    w_momentum  = 0.15
    w_imbalance = 0.15
    w_wyckoff   = 0.10
    w_quant     = 0.10
    w_harmonic  = 0.05
    w_shadow    = 0.05

    if regime.regime == "STRONG_TREND_UP" or regime.regime == "WEAK_TREND_UP" or regime.regime == "STRONG_TREND_DOWN" or regime.regime == "WEAK_TREND_DOWN"
        w_structure := 0.25
        w_momentum  := 0.20
        w_liquidity := 0.15
        w_imbalance := 0.15
    else if regime.regime == "COMPRESSED_RANGE" or regime.regime == "EXPANDED_RANGE"
        w_liquidity := 0.30
        w_wyckoff   := 0.20
        w_structure := 0.15
        w_momentum  := 0.10

    momentum_bull = bull_mom_score
    momentum_bear = bear_mom_score

    imbalance_bull = 50.0
    imbalance_bear = 50.0
    if ob_direction == 1
        imbalance_bull := ob_score
        imbalance_bear := 100.0 - ob_score
    else if ob_direction == -1
        imbalance_bear := ob_score
        imbalance_bull := 100.0 - ob_score

    if fvg_bull
        imbalance_bull := math.min(100.0, imbalance_bull + 30.0)
    if fvg_bear
        imbalance_bear := math.min(100.0, imbalance_bear + 30.0)
    if absorption
        imbalance_bull := math.min(100.0, imbalance_bull + 10.0)
        imbalance_bear := math.min(100.0, imbalance_bear + 10.0)

    wyckoff_bull = 50.0
    wyckoff_bear = 50.0
    if wyckoff.spring_detected or wyckoff.current_phase == "D"
        wyckoff_bull := wyckoff.accumulation_prob
    if wyckoff.upthrust_detected or wyckoff.current_phase == "E"
        wyckoff_bear := wyckoff.distribution_prob

    quant_bull = quant_score_norm * 100.0
    quant_bear = (1.0 - quant_score_norm) * 100.0

    long_score_raw = (struct_bull_score * w_structure) +
                     (sweep_bull_score * w_liquidity) +
                     (momentum_bull * w_momentum) +
                     (imbalance_bull * w_imbalance) +
                     (wyckoff_bull * w_wyckoff) +
                     (quant_bull * w_quant) +
                     (harm_bull_norm * 100.0 * w_harmonic) +
                     (shadow_bull_norm * 100.0 * w_shadow)

    short_score_raw = (struct_bear_score * w_structure) +
                      (sweep_bear_score * w_liquidity) +
                      (momentum_bear * w_momentum) +
                      (imbalance_bear * w_imbalance) +
                      (wyckoff_bear * w_wyckoff) +
                      (quant_bear * w_quant) +
                      (harm_bear_norm * 100.0 * w_harmonic) +
                      (shadow_bear_norm * 100.0 * w_shadow)

    total_weight = w_structure + w_liquidity + w_momentum + w_imbalance + w_wyckoff + w_quant + w_harmonic + w_shadow
    total_weight_sec = total_weight > 0.0 ? total_weight : 1.0
    long_score  = long_score_raw / total_weight_sec
    short_score = short_score_raw / total_weight_sec

    if regime.regime == "STRONG_TREND_UP" or regime.regime == "WEAK_TREND_UP"
        long_score := f_clamp(long_score + regime.confidence * 0.15, 0.0, 100.0)
    else if regime.regime == "STRONG_TREND_DOWN" or regime.regime == "WEAK_TREND_DOWN"
        short_score := f_clamp(short_score + regime.confidence * 0.15, 0.0, 100.0)

    if playbook.name != "NONE"
        if playbook.direction == 1
            long_score := f_clamp(long_score + playbook.score * 0.25, 0.0, 100.0)
        else if playbook.direction == -1
            short_score := f_clamp(short_score + playbook.score * 0.25, 0.0, 100.0)

    dynamic_long_thresh  = min_l_thresh
    dynamic_short_thresh = min_s_thresh
    dynamic_diff_thresh  = diff_thresh

    if regime.regime == "STRONG_TREND_UP" or regime.regime == "WEAK_TREND_UP"
        dynamic_long_thresh := min_l_thresh - 8.0
        dynamic_diff_thresh := diff_thresh / 1.5
    else if regime.regime == "STRONG_TREND_DOWN" or regime.regime == "WEAK_TREND_DOWN"
        dynamic_short_thresh := min_s_thresh - 8.0
        dynamic_diff_thresh  := diff_thresh / 1.5

    long_signal  = long_score >= dynamic_long_thresh and long_score > short_score + dynamic_diff_thresh
    short_signal = short_score >= dynamic_short_thresh and short_score > long_score + dynamic_diff_thresh

    [long_signal, short_signal, long_score, short_score]

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 16: PRESETS AND ADAPTIVE AUTO-TUNING
// ═══════════════════════════════════════════════════════════════════════════════

var int swing_len_liq     = 9
var int swing_len_struct  = 5
var int atr_len           = 14
var float ob_ratio_thresh = 1.5
var int wt_len_1          = 10
var int wt_len_2          = 21
var int vfi_len           = 130

preset_scalping = tf_preset_mode == "Scalping (1m-5m)" or (tf_preset_mode == "Auto-Adapt" and timeframe.isminutes and timeframe.multiplier <= 5)
preset_daytrade = tf_preset_mode == "Day Trading (15m-30m)" or (tf_preset_mode == "Auto-Adapt" and timeframe.isminutes and timeframe.multiplier > 5 and timeframe.multiplier <= 30)
preset_swing    = tf_preset_mode == "Swing Trading (1h-4h)" or (tf_preset_mode == "Auto-Adapt" and timeframe.isminutes and timeframe.multiplier > 30) or (timeframe.isdaily == false and timeframe.isminutes == false)
preset_position = tf_preset_mode == "Position (Daily)" or (tf_preset_mode == "Auto-Adapt" and timeframe.isdaily)

if preset_scalping
    swing_len_liq     := 5
    swing_len_struct  := 3
    atr_len           := 10
    ob_ratio_thresh   := 1.2
    wt_len_1          := 8
    wt_len_2          := 14
    vfi_len           := 80
else if preset_daytrade
    swing_len_liq     := 8
    swing_len_struct  := 5
    atr_len           := 14
    ob_ratio_thresh   := 1.4
    wt_len_1          := 10
    wt_len_2          := 21
    vfi_len           := 100
else if preset_swing
    swing_len_liq     := 12
    swing_len_struct  := 7
    atr_len           := 14
    ob_ratio_thresh   := 1.6
    wt_len_1          := 12
    wt_len_2          := 26
    vfi_len           := 130
else if preset_position
    swing_len_liq     := 15
    swing_len_struct  := 9
    atr_len           := 20
    ob_ratio_thresh   := 1.8
    wt_len_1          := 14
    wt_len_2          := 28
    vfi_len           := 150
else // Manual Control
    swing_len_liq     := in_swing_liq
    swing_len_struct  := in_swing_str
    atr_len           := in_atr_len
    ob_ratio_thresh   := in_ob_ratio
    wt_len_1          := in_wt_len_1
    wt_len_2          := in_wt_len_2
    vfi_len           := in_vfi_len

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 17: GLOBAL INDICATORS IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════════════════════

atr_val = ta.atr(atr_len)
atr_50  = ta.atr(50)

// Standard Deviations & SMAs globally calculated
close_sma_50   = ta.sma(close, 50)
close_stdev_50 = ta.stdev(close, 50)
vol_sma_50     = ta.sma(volume, 50)
vol_stdev_50   = ta.stdev(volume, 50)
vol_sma_20     = ta.sma(volume, 20)

// Institutional EMAs Correctly Calculated
fast_ema = ta.ema(close, ema_fast_len)
mid_ema  = ta.ema(close, ema_mid_len)
slow_ema = ta.ema(close, ema_slow_len)

// Extract ADX correctly via standard DMI built-in function
[_, _, adx_val] = ta.dmi(14, 14)

// Constant-size Pivot calculations (to avoid Pine V6 constant error) - Extracted for complete consistency
ph_5  = ta.pivothigh(high, 5, 5)
pl_5  = ta.pivotlow(low, 5, 5)
ph_9  = ta.pivothigh(high, 9, 9)
pl_9  = ta.pivotlow(low, 9, 9)
ph_15 = ta.pivothigh(high, 15, 15)
pl_15 = ta.pivotlow(low, 15, 15)

// Extracted pivots for dynamic backtest SL estimation (Resolves Warning at 2029/2030)
ph_sl_global = ta.pivothigh(high, 10, 10)
pl_sl_global = ta.pivotlow(low, 10, 10)

// Resolve Pivot references according to adaptive swing lengths
ph_liq_resolved = swing_len_liq == 5 ? ph_5 : swing_len_liq == 9 ? ph_9 : swing_len_liq == 15 ? ph_15 : ta.pivothigh(high, swing_len_liq, swing_len_liq)
pl_liq_resolved = swing_len_liq == 5 ? pl_5 : swing_len_liq == 9 ? pl_9 : swing_len_liq == 15 ? pl_15 : ta.pivotlow(low, swing_len_liq, swing_len_liq)

ph_str_resolved = swing_len_struct == 5 ? ph_5 : swing_len_struct == 9 ? ph_9 : swing_len_struct == 15 ? ph_15 : ta.pivothigh(high, swing_len_struct, swing_len_struct)
pl_str_resolved = swing_len_struct == 5 ? pl_5 : swing_len_struct == 9 ? pl_9 : swing_len_struct == 15 ? pl_15 : ta.pivotlow(low, swing_len_struct, swing_len_struct)

// Shadow logic helpers
shadow_highest_20 = ta.highest(high, 20)
shadow_lowest_20  = ta.lowest(low, 20)
shadow_highest_8  = ta.highest(high, 8)
shadow_lowest_8   = ta.lowest(low, 8)

// Wyckoff persistence helpers
var float last_swing_high_wy = na
var float last_swing_low_wy  = na
if not na(ph_str_resolved)
    last_swing_high_wy := ph_str_resolved
if not na(pl_str_resolved)
    last_swing_low_wy := pl_str_resolved

// Squeeze Momentum Indicator engine parameters
sqz_basis    = ta.sma(close, 20)
sqz_dev      = 2.0 * ta.stdev(close, 20)
sqz_upper_bb = sqz_basis + sqz_dev
sqz_lower_bb = sqz_basis - sqz_dev
sqz_atr      = ta.sma(ta.tr, 20)
sqz_upper_kc = sqz_basis + 1.5 * sqz_atr
sqz_lower_kc = sqz_basis - 1.5 * sqz_atr
sqz_on       = (sqz_lower_bb > sqz_lower_kc) and (sqz_upper_bb < sqz_upper_kc)
mom_hist     = ta.linreg(close - (ta.highest(high, 20) + ta.lowest(low, 20)) / 2.0, 20, 0)

// WaveTrend Engine
ap = hlc3
esa = ta.ema(ap, wt_len_1)
de = ta.ema(math.abs(ap - esa), wt_len_1)
ci = (ap - esa) / (0.015 * de)
wt1 = ta.ema(ci, wt_len_2)
wt2 = ta.sma(wt1, 4)

// VFI Engine
vfi_cutoff  = 0.2 * ta.atr(30)
vfi_typical = hlc3
vfi_vc      = volume
vfi_mf      = vfi_typical - vfi_typical[1]
vfi_dir     = vfi_mf > vfi_cutoff ? 1.0 : (vfi_mf < -vfi_cutoff ? -1.0 : 0.0)
vfi_val     = ta.ema(ta.cum(vfi_dir * vfi_vc), vfi_len)
vfi         = nz(vfi_val, 0.0)
vfi_signal  = ta.ema(vfi, 20)
vfi_vave    = ta.sma(volume, vfi_len)

// Awesome Oscillator
ao         = ta.sma(hl2, 5) - ta.sma(hl2, 34)
ao_signal  = ta.sma(ao, 9)
ao_sma_100 = ta.sma(ao, 100)

// Schaff Trend Cycle
f_stc(src, len1, len2) =>
    macd_val = ta.ema(src, len1) - ta.ema(src, len2)
    lowest_m = ta.lowest(macd_val, 10)
    highest_m = ta.highest(macd_val, 10)
    m_range = highest_m - lowest_m
    stc_v = m_range > 0.0 ? (macd_val - lowest_m) / m_range * 100.0 : 0.0
    ta.ema(stc_v, 5)
stc = f_stc(close, 23, 50)

// Firefly Approximation
ww_fly = ta.rsi(close, 14)

// Volume and CVD
volume_ma_20 = ta.sma(volume, 20)
delta_smooth = ta.ema(volume * (close - open) / (high - low + 1e-6), 14)
cvd          = ta.cum(volume * (close - open) / (high - low + 1e-6))
cvd_signal   = ta.ema(cvd, 20)

// MTF Fetching
htf_close   = f_secure_mtf(htf_resolution, close)
htf_ema_val = f_secure_mtf(htf_resolution, ta.ema(close, 50))

// Graphics structural memory
var line[] active_lines     = array.new<line>()
var label[] active_labels   = array.new<label>()
var box[] active_fvg_boxes  = array.new<box>()
var box[] ob_visual_boxes   = array.new<box>()

// Persistent stats tracking states
var float bt_balance            = backtestCapital
var float bt_net_profit         = 0.0
var int bt_total_trades         = 0
var int bt_winning_trades       = 0
var int bt_losing_trades        = 0
var float bt_max_dd_pct         = 0.0
var float bt_peak_balance       = backtestCapital
var int bt_max_consec_wins      = 0
var int consec_losses           = 0
var int bt_max_consec_losses    = 0
var int current_consec_wins     = 0
var float bt_total_win_amount   = 0.0
var float bt_total_loss_amount  = 0.0
var float[] trade_returns       = array.new_float()

// Trade execution active states
var int position_dir       = 0
var float position_entry   = 0.0
var float position_sl      = 0.0
var float position_tp1     = 0.0
var float position_tp2     = 0.0
var float position_tp3     = 0.0
var float position_risk    = 0.0
var float position_size_val = 0.0
var int position_entry_bar = 0
var bool tp1_hit           = false
var bool tp2_hit           = false
var bool trail_active      = false
var float trail_stop        = 0.0

// Emergency kill-switch variables
var bool kill_active       = false
var int kill_cooldown_bar  = 0

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 17b: CONDITIONAL ASSIGNMENT BLOCKS
// ═══════════════════════════════════════════════════════════════════════════════

RegimeState regime = RegimeState.new("NEUTRAL", 50.0, 0.5, 0.5, 50.0, 0.5)
if useRegimeLayer
    regime := f_regime_engine(atr_val, atr_50, close_sma_50, close_stdev_50, vol_sma_50, vol_stdev_50, adx_val)

SweepSignal sweep = SweepSignal.new(false, 0, 0.0, na, 0.0, 0.0, 0.0, false)
if useLiquidityLayer
    sweep := f_liquidity_engine(ph_liq_resolved, pl_liq_resolved, vol_sma_20, atr_val, swing_len_liq)

StructureSignal structure = StructureSignal.new(false, false, false, false, false, false, 50.0, 0)
if useStructureLayer
    structure := f_structure_engine(ph_str_resolved, pl_str_resolved, htf_close, htf_ema_val)

st1_bull  = false
st1_bear  = false
st2_bull  = false
st2_bear  = false
st3_bull  = false
st3_bear  = false
st4_bull  = false
st4_bear  = false
st5_valid = false
st5_upper = 0.0
st5_lower = 0.0
st6_bull  = false
st6_bear  = false
st7_valid = false

if useStructureLayer
    [s1bu, s1be, s2bu, s2be, s3bu, s3be, s4bu, s4be, s5v, s5u, s5l, s6bu, s6be, s7v] = f_shadow_patterns(atr_val, shadow_highest_20, shadow_lowest_20, shadow_highest_8, shadow_lowest_8)
    st1_bull  := s1bu
    st1_bear  := s1be
    st2_bull  := s2bu
    st2_bear  := s2be
    st3_bull  := s3bu
    st3_bear  := s3be
    st4_bull  := s4bu
    st4_bear  := s4be
    st5_valid := s5v
    st5_upper := s5u
    st5_lower := s5l
    st6_bull  := s6bu
    st6_bear  := s6be
    st7_valid := s7v

shadow_score = 0.0
if st1_bull or st1_bear
    shadow_score := shadow_score + 20.0
if st2_bull or st2_bear
    shadow_score := shadow_score + 15.0
if st3_bull or st3_bear
    shadow_score := shadow_score + 20.0
if st4_bull or st4_bear
    shadow_score := shadow_score + 15.0
if st5_valid
    shadow_score := shadow_score + 10.0
if st6_bull or st6_bear
    shadow_score := shadow_score + 10.0
if st7_valid
    shadow_score := shadow_score + 10.0
shadow_score := f_clamp(shadow_score, 0.0, 100.0)

bat_bull       = false
bat_bear       = false
butterfly_bull = false
butterfly_bear = false
crab_bull      = false
crab_bear      = false
cypher_bull    = false
cypher_bear    = false
shark_bull     = false
shark_bear     = false
five0_bull     = false
five0_bear     = false

if useHarmonicLayer
    [h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12] = f_harmonic_patterns(ph_str_resolved, pl_str_resolved)
    bat_bull       := h1
    bat_bear       := h2
    butterfly_bull := h3
    butterfly_bear := h4
    crab_bull      := h5
    crab_bear      := h6
    cypher_bull    := h7
    cypher_bear    := h8
    shark_bull     := h9
    shark_bear     := h10
    five0_bull     := h11
    five0_bear     := h12

harmonic_score = 0.0
if bat_bull or bat_bear
    harmonic_score := harmonic_score + 15.0
if butterfly_bull or butterfly_bear
    harmonic_score := harmonic_score + 15.0
if crab_bull or crab_bear
    harmonic_score := harmonic_score + 15.0
if cypher_bull or cypher_bear
    harmonic_score := harmonic_score + 15.0
if shark_bull or shark_bear
    harmonic_score := harmonic_score + 20.0
if five0_bull or five0_bear
    harmonic_score := harmonic_score + 20.0
harmonic_score := f_clamp(harmonic_score, 0.0, 100.0)

var OrderBlock[] order_blocks = array.new<OrderBlock>()

fvg_bull     = false
fvg_bear     = false
ob_direction = 0
ob_score     = 50.0
cvd_bull     = false
cvd_bear     = false
delta_bull   = false
delta_bear   = false
absorption   = false

if useImbalanceLayer
    [o1, o2, o3, o4, o5, o6, o7, o8, o9, o10] = f_imbalance_engine(atr_val, structure.trend_dir, cvd, cvd_signal, delta_smooth, volume_ma_20, ob_ratio_thresh, order_blocks)
    fvg_bull     := o1
    fvg_bear     := o2
    ob_direction := o3
    ob_score     := o4
    cvd_bull     := o5
    cvd_bear     := o6
    delta_bull   := o7
    delta_bear   := o8
    absorption   := o9
    order_blocks := o10

wt_cross_bull  = false
wt_cross_bear  = false
wt_bull        = false
wt_bear        = false
wt_oversold    = false
wt_overbought  = false
wt_score       = 50.0
vfi_bull       = false
vfi_bear       = false
vfi_score      = 50.0
ao_cross_bull  = false
ao_cross_bear  = false
ao_bull        = false
ao_bear        = false
ao_score       = 50.0
stc_bull       = false
stc_bear       = false
stc_oversold   = false
stc_overbought = false
stc_score      = 50.0
firefly_bull   = false
firefly_bear   = false
firefly_score  = 50.0
sqz_release    = false
mom_rising     = false
bull_mom_score = 50.0
bear_mom_score = 50.0

if useMomentumLayer
    [m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20, m21, m22, m23, m24, m25, m26, m27, m28] = f_momentum_engine(wt1, wt2, vfi, vfi_signal, vfi_vave, ao, ao_signal, ao_sma_100, stc, ww_fly, sqz_on, mom_hist)
    wt_cross_bull  := m1
    wt_cross_bear  := m2
    wt_bull        := m3
    wt_bear        := m4
    wt_oversold    := m5
    wt_overbought  := m6
    wt_score       := m7
    vfi_bull       := m8
    vfi_bear       := m9
    vfi_score      := m10
    ao_cross_bull  := m11
    ao_cross_bear  := m12
    ao_bull        := m13
    ao_bear        := m14
    ao_score       := m15
    stc_bull       := m16
    stc_bear       := m17
    stc_oversold   := m18
    stc_overbought := m19
    stc_score      := m20
    firefly_bull   := m21
    firefly_bear   := m22
    firefly_score  := m23
    sqz_release    := m25
    mom_rising     := m26
    bull_mom_score := m27
    bear_mom_score := m28

WyckoffState wyckoff = WyckoffState.new(50.0, 50.0, "B", false, false, false, false, false)
if useWyckoffLayer
    wyckoff := f_wyckoff_engine(atr_val, last_swing_high_wy, last_swing_low_wy, vol_sma_20)

kf_price        = close
norm_slope      = 0.0
norm_accel      = 0.0
zscore          = 0.0
mean_rev_prob   = 50.0
trend_cont_prob = 50.0
quant_score     = 50.0

if useQuantLayer
    [q1, q2, q3, q4, q5, q6, q7] = f_quant_engine(atr_val)
    kf_price        := q1
    norm_slope      := q2
    norm_accel      := q3
    zscore          := q4
    mean_rev_prob   := q5
    trend_cont_prob := q6
    quant_score     := q7

prev_close   = nz(close[1], close)
log_returns  = prev_close > 0.0 and close > 0.0 ? math.log(close / prev_close) : 0.0
mc_mean_ret  = nz(ta.sma(log_returns, 20), 0.0)
mc_stdev_ret = nz(ta.stdev(log_returns, 20), 0.001)
mc_drift     = mc_mean_ret - 0.5 * math.pow(mc_stdev_ret, 2)
mc_steps     = 5
mc_val_up    = close * math.exp(mc_drift * mc_steps + mc_stdev_ret * math.sqrt(mc_steps) * 1.645)
mc_val_dn    = close * math.exp(mc_drift * mc_steps - mc_stdev_ret * math.sqrt(mc_steps) * 1.645)
mc_val_median = close * math.exp(mc_drift * mc_steps)

mc_res = MonteCarloResult.new(mc_val_up, mc_val_dn, mc_val_median, mc_val_up, mc_val_dn, bar_index)

regime_trend_val = 0
if regime.regime == "STRONG_TREND_UP" or regime.regime == "WEAK_TREND_UP"
    regime_trend_val := 1
else if regime.regime == "STRONG_TREND_DOWN" or regime.regime == "WEAK_TREND_DOWN"
    regime_trend_val := -1

PlaybookSignal selected_playbook = PlaybookSignal.new("NONE", 0, 0.0, 0.0, 0.0, bar_index)
PlaybookSignal[] active_playbooks = array.new<PlaybookSignal>()

if usePlaybookLayer
    [p1, p2] = f_playbook_engine(
         sweep.score, structure.strength, ob_score, 50.0,
         wyckoff.accumulation_prob, bull_mom_score,
         regime_trend_val,
         sweep.detected and sweep.direction == 1, sweep.detected and sweep.direction == -1,
         wyckoff.spring_detected, wyckoff.upthrust_detected,
         fvg_bull, fvg_bear, ob_direction, ob_score,
         structure.trend_dir, sqz_release)
    selected_playbook := p1
    active_playbooks  := p2

// ═══════════════════════════════════════════════════════════════════════════════
// ║           PART 17c: MEMORY DECAY STATE ENGINE FOR CONFLUENCE
// ║   (Memorization of break of structure and liquidity sweep to boost signals)
// ═══════════════════════════════════════════════════════════════════════════════

var float struct_bull_score = 0.0
var float struct_bear_score = 0.0
var float sweep_bull_score  = 0.0
var float sweep_bear_score  = 0.0
var float harm_bull_score   = 0.0
var float harm_bear_score   = 0.0
var float shadow_bull_score = 0.0
var float shadow_bear_score = 0.0

atr_ratio_decay = atr_val / (atr_50 + 1e-6)
decay_factor    = f_clamp(atr_ratio_decay, 0.5, 2.0)

if structure.strength > 0
    if structure.trend_dir == 1 or structure.bos_bull or structure.choch_bull or structure.mss_bull
        struct_bull_score := structure.strength
        struct_bear_score := math.max(0.0, struct_bear_score - (5.0 * decay_factor))
    else
        struct_bear_score := structure.strength
        struct_bull_score := math.max(0.0, struct_bull_score - (5.0 * decay_factor))
else
    struct_bull_score := math.max(0.0, struct_bull_score - (2.0 * decay_factor))
    struct_bear_score := math.max(0.0, struct_bear_score - (2.0 * decay_factor))

if sweep.detected
    if sweep.direction == 1
        sweep_bull_score := sweep.score
        sweep_bear_score := math.max(0.0, sweep_bear_score - (8.0 * decay_factor))
    else
        sweep_bear_score := sweep.score
        sweep_bull_score := math.max(0.0, sweep_bull_score - (8.0 * decay_factor))
else
    sweep_bull_score := math.max(0.0, sweep_bull_score - (3.0 * decay_factor))
    sweep_bear_score := math.max(0.0, sweep_bear_score - (3.0 * decay_factor))

any_bull_harmonic = bat_bull or butterfly_bull or crab_bull or cypher_bull or shark_bull or five0_bull
any_bear_harmonic = bat_bear or butterfly_bear or crab_bear or cypher_bear or shark_bear or five0_bear
if harmonic_score > 0
    if any_bull_harmonic
        harm_bull_score := harmonic_score
        harm_bear_score := math.max(0.0, harm_bear_score - (6.0 * decay_factor))
    if any_bear_harmonic
        harm_bear_score := harmonic_score
        harm_bull_score := math.max(0.0, harm_bull_score - (6.0 * decay_factor))
else
    harm_bull_score := math.max(0.0, harm_bull_score - (1.5 * decay_factor))
    harm_bear_score := math.max(0.0, harm_bear_score - (1.5 * decay_factor))

any_bull_shadow = st1_bull or st2_bull or st3_bull or st4_bull or st6_bull
any_bear_shadow = st1_bear or st2_bear or st3_bear or st4_bear or st6_bear
if shadow_score > 0
    if any_bull_shadow
        shadow_bull_score := shadow_score
        shadow_bear_score := math.max(0.0, shadow_bear_score - (10.0 * decay_factor))
    if any_bear_shadow
        shadow_bear_score := shadow_score
        shadow_bull_score := math.max(0.0, shadow_bull_score - (10.0 * decay_factor))
else
    shadow_bull_score := math.max(0.0, shadow_bull_score - (4.0 * decay_factor))
    shadow_bear_score := math.max(0.0, shadow_bear_score - (4.0 * decay_factor))

fvg_bull_val = false
fvg_bear_val = false
if useImbalanceLayer
    fvg_bull_val := fvg_bull
    fvg_bear_val := fvg_bear

[long_signal_raw, short_signal_raw, long_score, short_score] = f_fusion_engine(
    regime, sweep, structure,
    shadow_bull_score / 100.0, shadow_bear_score / 100.0,
    struct_bull_score, struct_bear_score,
    sweep_bull_score, sweep_bear_score,
    harm_bull_score / 100.0, harm_bear_score / 100.0,
    fvg_bull_val, fvg_bear_val, ob_direction, ob_score,
    cvd_bull, cvd_bear, delta_bull, delta_bear, absorption,
    bull_mom_score, bear_mom_score, wyckoff, quant_score / 100.0, selected_playbook,
    min_long_threshold, min_short_threshold, score_diff_threshold)

session_ok = f_session_check()
var int last_signal_bar = -100
cooldown_ok = (bar_index - last_signal_bar) > 5

final_long_signal  = long_signal_raw and session_ok and cooldown_ok and kill_active == false and position_dir == 0
final_short_signal = short_signal_raw and session_ok and cooldown_ok and kill_active == false and position_dir == 0

if final_long_signal or final_short_signal
    last_signal_bar := bar_index

if kill_active and bar_index >= kill_cooldown_bar
    kill_active := false

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 18: TRADE EXECUTION (Backtest Mode)
// ═══════════════════════════════════════════════════════════════════════════════

if enableBacktest and session_ok and kill_active == false
    ph_sl = ph_sl_global
    pl_sl = pl_sl_global
    var float last_swing_high_sl = na
    var float last_swing_low_sl  = na
    if not na(ph_sl)
        last_swing_high_sl := ph_sl
    if not na(pl_sl)
        last_swing_low_sl := pl_sl

    if final_long_signal and position_dir == 0
        [entry, stop, tp1, tp2, tp3, risk_amt, pos_size, risk_rr] = f_risk_engine(
            close, 1, atr_val, last_swing_high_sl, last_swing_low_sl,
            regime.trend_strength / 100.0, regime.volatility_regime, regime.hurst)
        position_dir      := 1
        position_entry    := entry
        position_sl       := stop
        position_tp1      := tp1
        position_tp2      := tp2
        position_tp3      := tp3
        position_risk     := risk_amt
        position_size_val := pos_size
        position_entry_bar := bar_index
        tp1_hit           := false
        tp2_hit           := false
        trail_active      := false
        trail_stop        := 0.0

    if final_short_signal and position_dir == 0
        [entry, stop, tp1, tp2, tp3, risk_amt, pos_size, risk_rr] = f_risk_engine(
            close, -1, atr_val, last_swing_high_sl, last_swing_low_sl,
            regime.trend_strength / 100.0, regime.volatility_regime, regime.hurst)
        position_dir      := -1
        position_entry    := entry
        position_sl       := stop
        position_tp1      := tp1
        position_tp2      := tp2
        position_tp3      := tp3
        position_risk     := risk_amt
        position_size_val := pos_size
        position_entry_bar := bar_index
        tp1_hit           := false
        tp2_hit           := false
        trail_active      := false
        trail_stop        := 0.0

    // Long position management
    trigger_close_long = false
    exit_price_long    = 0.0
    exit_reason_long   = ""

    if position_dir == 1
        if tp1_hit == false and high >= position_tp1
            tp1_hit := true
            close_pnl = (position_tp1 - position_entry) * position_size_val * (tp1Percent / 100.0)
            bt_balance := bt_balance + close_pnl
            bt_net_profit := bt_net_profit + close_pnl
            position_size_val := position_size_val * (1.0 - tp1Percent / 100.0)

        if tp1_hit and tp2_hit == false and high >= position_tp2
            tp2_hit := true
            close_pnl = (position_tp2 - position_entry) * position_size_val * (tp2Percent / 100.0)
            bt_balance := bt_balance + close_pnl
            bt_net_profit := bt_net_profit + close_pnl
            position_size_val := position_size_val * (1.0 - tp2Percent / 100.0)
            trail_active := true
            trail_stop := position_entry + (position_tp2 - position_entry) * 0.5

        if trail_active and high > trail_stop
            trail_stop := math.max(trail_stop, high - (atr_val * 2.0))

        if high >= position_tp3
            trigger_close_long := true
            exit_price_long := position_tp3
            exit_reason_long := "TP3"
        else if trail_active and low < trail_stop
            trigger_close_long := true
            exit_price_long := trail_stop
            exit_reason_long := "TRAIL"
        else if low <= position_sl
            trigger_close_long := true
            exit_price_long := position_sl
            exit_reason_long := "SL"

        if trigger_close_long
            trade_pnl = (exit_price_long - position_entry) * position_size_val
            total_slippage_cost = position_size_val * position_entry * (slippagePct / 100.0) * 2.0
            trade_pnl := trade_pnl - total_slippage_cost

            bt_balance := bt_balance + trade_pnl
            bt_net_profit := bt_net_profit + trade_pnl
            bt_total_trades := bt_total_trades + 1
            array.push(trade_returns, trade_pnl)

            if trade_pnl > 0.0
                bt_winning_trades := bt_winning_trades + 1
                bt_total_win_amount := bt_total_win_amount + trade_pnl
                current_consec_wins := current_consec_wins + 1
                consec_losses := 0
                if current_consec_wins > bt_max_consec_wins
                    bt_max_consec_wins := current_consec_wins
            else
                bt_losing_trades := bt_losing_trades + 1
                bt_total_loss_amount := bt_total_loss_amount + math.abs(trade_pnl)
                consec_losses := consec_losses + 1
                current_consec_wins := 0
                if consec_losses > bt_max_consec_losses
                    bt_max_consec_losses := consec_losses

            if bt_balance > bt_peak_balance
                bt_peak_balance := bt_balance
            dd_pct = (bt_peak_balance - bt_balance) / bt_peak_balance * 100.0
            if dd_pct > bt_max_dd_pct
                bt_max_dd_pct := dd_pct

            if consec_losses >= maxConsecLosses
                kill_active := true
                kill_cooldown_bar := bar_index + cooldownBars

            position_dir      := 0
            position_size_val := 0.0
            tp1_hit           := false
            tp2_hit           := false
            trail_active      := false
            trail_stop        := 0.0
            trigger_close_long := false

    // Short position management
    trigger_close_short = false
    exit_price_short    = 0.0
    exit_reason_short   = ""

    if position_dir == -1
        if tp1_hit == false and low <= position_tp1
            tp1_hit := true
            close_pnl = (position_entry - position_tp1) * position_size_val * (tp1Percent / 100.0)
            bt_balance := bt_balance + close_pnl
            bt_net_profit := bt_net_profit + close_pnl
            position_size_val := position_size_val * (1.0 - tp1Percent / 100.0)

        if tp1_hit and tp2_hit == false and low <= position_tp2
            tp2_hit := true
            close_pnl = (position_entry - position_tp2) * position_size_val * (tp2Percent / 100.0)
            bt_balance := bt_balance + close_pnl
            bt_net_profit := bt_net_profit + close_pnl
            position_size_val := position_size_val * (1.0 - tp2Percent / 100.0)
            trail_active := true
            trail_stop := position_entry - (position_entry - position_tp2) * 0.5

        if trail_active and low < trail_stop
            trail_stop := math.min(trail_stop, low + (atr_val * 2.0))

        if low <= position_tp3
            trigger_close_short := true
            exit_price_short := position_tp3
            exit_reason_short := "TP3"
        else if trail_active and high > trail_stop
            trigger_close_short := true
            exit_price_short := trail_stop
            exit_reason_short := "TRAIL"
        else if high >= position_sl
            trigger_close_short := true
            exit_price_short := position_sl
            exit_reason_short := "SL"

        if trigger_close_short
            trade_pnl = (position_entry - exit_price_short) * position_size_val
            total_slippage_cost = position_size_val * position_entry * (slippagePct / 100.0) * 2.0
            trade_pnl := trade_pnl - total_slippage_cost

            bt_balance := bt_balance + trade_pnl
            bt_net_profit := bt_net_profit + trade_pnl
            bt_total_trades := bt_total_trades + 1
            array.push(trade_returns, trade_pnl)

            if trade_pnl > 0.0
                bt_winning_trades := bt_winning_trades + 1
                bt_total_win_amount := bt_total_win_amount + trade_pnl
                current_consec_wins := current_consec_wins + 1
                consec_losses := 0
                if current_consec_wins > bt_max_consec_wins
                    bt_max_consec_wins := current_consec_wins
            else
                bt_losing_trades := bt_losing_trades + 1
                bt_total_loss_amount := bt_total_loss_amount + math.abs(trade_pnl)
                consec_losses := consec_losses + 1
                current_consec_wins := 0
                if consec_losses > bt_max_consec_losses
                    bt_max_consec_losses := consec_losses

            if bt_balance > bt_peak_balance
                bt_peak_balance := bt_balance
            dd_pct = (bt_peak_balance - bt_balance) / bt_peak_balance * 100.0
            if dd_pct > bt_max_dd_pct
                bt_max_dd_pct := dd_pct

            if consec_losses >= maxConsecLosses
                kill_active := true
                kill_cooldown_bar := bar_index + cooldownBars

            position_dir      := 0
            position_size_val := 0.0
            tp1_hit           := false
            tp2_hit           := false
            trail_active      := false
            trail_stop        := 0.0
            trigger_close_short := false

// UI stats tracking
bt_win_rate      = bt_total_trades > 0 ? (float(bt_winning_trades) / bt_total_trades) * 100.0 : 0.0
bt_profit_factor = bt_total_loss_amount > 0.0 ? bt_total_win_amount / bt_total_loss_amount : bt_total_win_amount > 0.0 ? 99.9 : 0.0
bt_avg_win       = bt_winning_trades > 0 ? bt_total_win_amount / bt_winning_trades : 0.0
bt_avg_loss      = bt_losing_trades > 0 ? bt_total_loss_amount / bt_losing_trades : 0.0
bt_expectancy    = bt_total_trades > 0 ? (bt_win_rate / 100.0 * bt_avg_win) - ((1.0 - bt_win_rate / 100.0) * bt_avg_loss) : 0.0

float ret_stdev = 1.0
if array.size(trade_returns) > 1
    mean_ret = array.avg(trade_returns)
    sum_sq = 0.0
    for i = 0 to array.size(trade_returns) - 1
        sum_sq := sum_sq + math.pow(array.get(trade_returns, i) - mean_ret, 2)
    ret_stdev := math.sqrt(sum_sq / (array.size(trade_returns) - 1))
else
    ret_stdev := 1.0

if ret_stdev == 0.0
    ret_stdev := 1.0

bt_sharpe_ratio = bt_total_trades > 0 ? (bt_avg_win - bt_avg_loss) / ret_stdev : 0.0

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 19: MODERN MINIMALIST SIGNAL VISUALIZATION
// ║              (Enhanced Drawing Engine Limits)
// ═══════════════════════════════════════════════════════════════════════════════

plot(show_emas ? fast_ema : na, "UICE Fast EMA", style_ema_fast_color, style_ema_fast_width)
plot(show_emas ? mid_ema : na, "UICE Medium EMA", style_ema_mid_color, style_ema_mid_width)
plot(show_emas ? slow_ema : na, "UICE Slow EMA", style_ema_slow_color, style_ema_slow_width)

var line mc_top_line = na
var line mc_bot_line = na
if showZones and useQuantLayer and barstate.islast
    line.delete(mc_top_line)
    line.delete(mc_bot_line)
    mc_top_line := line.new(bar_index, close, bar_index + 5, mc_res.cloud_top, color=mc_cloud_up_color, width=1, style=line.style_dashed)
    mc_bot_line := line.new(bar_index, close, bar_index + 5, mc_res.cloud_bottom, color=mc_cloud_dn_color, width=1, style=line.style_dashed)

if showZones and show_ob_boxes and bar_index >= 50
    while array.size(ob_visual_boxes) > 0
        bx = array.shift(ob_visual_boxes)
        box.delete(bx)

    drawn_ob_count = 0
    if array.size(order_blocks) > 0
        for i = 0 to array.size(order_blocks) - 1
            if drawn_ob_count >= max_draw_zones
                break
            ob = array.get(order_blocks, i)
            if not ob.is_mitigated
                col = ob.is_bullish ? color_bull_ob : color_bear_ob
                border_col = ob.is_bullish ? color.new(col, 40) : color.new(col, 40)
                bx = box.new(left=ob.created_bar, top=ob.top, right=bar_index, bottom=ob.bottom,
                             bgcolor=col, border_color=border_col, border_style=line.style_dashed)
                array.push(ob_visual_boxes, bx)
                drawn_ob_count := drawn_ob_count + 1

var ActiveFVG[] fvg_tracker = array.new<ActiveFVG>()

if fvg_bull_val
    array.unshift(fvg_tracker, ActiveFVG.new(true, low, high[2], bar_index - 2, false))
if fvg_bear_val
    array.unshift(fvg_tracker, ActiveFVG.new(false, low[2], high, bar_index - 2, false))

if array.size(fvg_tracker) > 0
    for i = 0 to array.size(fvg_tracker) - 1
        fvg = array.get(fvg_tracker, i)
        if not fvg.is_mitigated
            if fvg.is_bullish and low <= fvg.bottom
                fvg.is_mitigated := true
            else if fvg.is_bullish == false and high >= fvg.top
                fvg.is_mitigated := true
        array.set(fvg_tracker, i, fvg)

while array.size(fvg_tracker) > 30
    array.pop(fvg_tracker)

if showZones and show_fvg_boxes and bar_index >= 50
    while array.size(active_fvg_boxes) > 0
        bx = array.shift(active_fvg_boxes)
        box.delete(bx)

    drawn_fvg_count = 0
    if array.size(fvg_tracker) > 0
        for i = 0 to array.size(fvg_tracker) - 1
            if drawn_fvg_count >= max_draw_zones
                break
            fvg = array.get(fvg_tracker, i)
            if not fvg.is_mitigated
                col = fvg.is_bullish ? color_bull_fvg : color_bear_fvg
                border_col = fvg.is_bullish ? color.new(col, 60) : color.new(col, 60)
                bx = box.new(left=fvg.created_bar, top=fvg.top, right=bar_index, bottom=fvg.bottom,
                             bgcolor=col, border_color=border_col, border_style=line.style_dotted)
                array.push(active_fvg_boxes, bx)
                drawn_fvg_count := drawn_fvg_count + 1

plotshape(showSignals and final_long_signal, "UICE LONG", shape.triangleup,
          location.belowbar, color=color.new(#00e676, 0), size=size.small)
plotshape(showSignals and final_short_signal, "UICE SHORT", shape.triangledown,
          location.abovebar, color=color.new(#ff5252, 0), size=size.small)

f_clear_visuals(active_lines, active_labels, active_fvg_boxes)

if showSignals and final_long_signal
    label_txt = "UICE LONG\nScore: " + str.tostring(math.round(long_score)) + "%\nRegime: " + regime.regime + "\nPlaybook: " + selected_playbook.name
    lbl = label.new(bar_index, low - atr_val * 0.8, label_txt,
              color=color.new(#00e676, 20), textcolor=color.white,
              style=label.style_label_up, size=size.small)
    array.push(active_labels, lbl)

if showSignals and final_short_signal
    label_txt = "UICE SHORT\nScore: " + str.tostring(math.round(short_score)) + "%\nRegime: " + regime.regime + "\nPlaybook: " + selected_playbook.name
    lbl = label.new(bar_index, high + atr_val * 0.8, label_txt,
              color=color.new(#ff5252, 20), textcolor=color.white,
              style=label.style_label_down, size=size.small)
    array.push(active_labels, lbl)

bgcolor(useRegimeLayer and regime_bg_color and regime.regime == "STRONG_TREND_UP" ? color.new(#00e676, 96) :
        useRegimeLayer and regime_bg_color and regime.regime == "STRONG_TREND_DOWN" ? color.new(#ff5252, 96) :
        useRegimeLayer and regime_bg_color and (regime.regime == "COMPRESSED_RANGE" or regime.regime == "EXPANDED_RANGE") ? color.new(#ffd600, 96) : na)

// ═══════════════════════════════════════════════════════════════════════════════
// ║              PART 20: INSTITUTIONAL DASHBOARD (sina Theme)
// ═══════════════════════════════════════════════════════════════════════════════

if showDashboard and barstate.islast
    dashboard_position = db_pos == "top_right" ? position.top_right :
                         db_pos == "bottom_right" ? position.bottom_right :
                         db_pos == "top_left" ? position.top_left :
                         position.bottom_left

    dashboard_size = db_size == "tiny" ? size.tiny :
                     db_size == "small" ? size.small :
                     size.normal

    var table dashboard = table.new(dashboard_position, 4, 20,
                                   bgcolor=db_bg_color,
                                   border_color=db_border_color,
                                   border_width=1, frame_width=2)

    table.merge_cells(dashboard, 0, 0, 3, 0)
    table.cell(dashboard, 0, 0, "UICE - INSTITUTIONAL COMPOSITE ENGINE (sina)",
              bgcolor=db_header_color, text_color=db_text_color,
              text_size=dashboard_size, text_halign=text.align_center)

    // Row 1: Market Regime
    table.cell(dashboard, 0, 1, "REGIME", text_color=color.gray, text_size=dashboard_size)
    regime_color = color.orange
    if regime.regime == "STRONG_TREND_UP" or regime.regime == "WEAK_TREND_UP"
        regime_color := color.green
    else if regime.regime == "STRONG_TREND_DOWN" or regime.regime == "WEAK_TREND_DOWN"
        regime_color := color.red
    table.cell(dashboard, 1, 1, regime.regime, text_color=regime_color, text_size=dashboard_size)
    table.cell(dashboard, 2, 1, "Conf: " + str.tostring(math.round(regime.confidence)) + "%", text_color=color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 3, 1, "H:" + str.tostring(regime.hurst, "#.00"), text_color=color.gray, text_size=dashboard_size)

    // Row 2: Liquidity
    table.cell(dashboard, 0, 2, "LIQUIDITY", text_color=color.gray, text_size=dashboard_size)
    sweep_text = "NONE"
    sweep_color = color.gray
    if sweep.detected and sweep.direction == 1
        sweep_text := "SWEEP ▲"
        sweep_color := color.green
    else if sweep.detected and sweep.direction == -1
        sweep_text := "SWEEP ▼"
        sweep_color := color.red
    table.cell(dashboard, 1, 2, sweep_text, text_color=sweep_color, text_size=dashboard_size)
    table.cell(dashboard, 2, 2, "Score: " + str.tostring(math.round(sweep.score)), text_color=color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 3, 2, sweep.volume_spike ? "🔥 VOL" : "", text_color=color.orange, text_size=dashboard_size)

    // Row 3: Structure
    table.cell(dashboard, 0, 3, "STRUCTURE", text_color=color.gray, text_size=dashboard_size)
    struct_text = "---"
    struct_color = color.gray
    if structure.bos_bull or structure.choch_bull or structure.mss_bull
        struct_text := "BULLISH"
        struct_color := color.green
    else if structure.bos_bear or structure.choch_bear or structure.mss_bear
        struct_text := "BEARISH"
        struct_color := color.red
    table.cell(dashboard, 1, 3, struct_text, text_color=struct_color, text_size=dashboard_size)
    table.cell(dashboard, 2, 3, "Str: " + str.tostring(math.round(structure.strength)), text_color=color.yellow, text_size=dashboard_size)
    trend_dir_text = "NEUTRAL"
    trend_dir_color = color.gray
    if structure.trend_dir == 1
        trend_dir_text := "▲ UPTREND"
        trend_dir_color := color.green
    else if structure.trend_dir == -1
        trend_dir_text := "▼ DOWNTREND"
        trend_dir_color := color.red
    table.cell(dashboard, 3, 3, trend_dir_text, text_color=trend_dir_color, text_size=dashboard_size)

    // Row 4: Patterns
    table.cell(dashboard, 0, 4, "PATTERNS", text_color=color.gray, text_size=dashboard_size)
    table.cell(dashboard, 1, 4, "Shadow: " + str.tostring(math.round(shadow_score)) + "%", text_color=color.rgb(238, 130, 238), text_size=dashboard_size)
    table.cell(dashboard, 2, 4, "Harmonic: " + str.tostring(math.round(harmonic_score)) + "%", text_color=color.rgb(238, 130, 238), text_size=dashboard_size)
    harmonic_icon = ""
    if bat_bull or butterfly_bull or crab_bull or cypher_bull or shark_bull or five0_bull or bat_bear or butterfly_bear or crab_bear or cypher_bear or shark_bear or five0_bear
        harmonic_icon := "🦋"
    table.cell(dashboard, 3, 4, harmonic_icon, text_color=color.green, text_size=dashboard_size)

    // Row 5: Imbalance
    table.cell(dashboard, 0, 5, "IMBALANCE", text_color=color.gray, text_size=dashboard_size)
    imb_text = "NONE"
    imb_color = color.gray
    if fvg_bull or ob_direction == 1
        imb_text := "BULLISH"
        imb_color := color.green
    else if fvg_bear or ob_direction == -1
        imb_text := "BEARISH"
        imb_color := color.red
    table.cell(dashboard, 1, 5, imb_text, text_color=imb_color, text_size=dashboard_size)
    table.cell(dashboard, 2, 5, "OB: " + str.tostring(math.round(ob_score)), text_color=color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 3, 5, absorption ? "🔹ABS" : "", text_color=color.orange, text_size=dashboard_size)

    // Row 6: Momentum
    table.cell(dashboard, 0, 6, "MOMENTUM", text_color=color.gray, text_size=dashboard_size)
    table.cell(dashboard, 1, 6, "WT: " + str.tostring(math.round(wt_score)) + "%",
              text_color=wt_score > 60.0 ? color.green : wt_score < 40.0 ? color.red : color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 2, 6, "VFI: " + str.tostring(math.round(vfi_score)) + "%",
              text_color=vfi_score > 50.0 ? color.green : color.red, text_size=dashboard_size)
    table.cell(dashboard, 3, 6, "STC: " + str.tostring(math.round(stc_score)) + "%",
              text_color=stc_score > 75.0 ? color.green : stc_score < 25.0 ? color.red : color.yellow, text_size=dashboard_size)

    // Row 7: Wyckoff State
    table.cell(dashboard, 0, 7, "WYCKOFF", text_color=color.gray, text_size=dashboard_size)
    table.cell(dashboard, 1, 7, "Phase: " + wyckoff.current_phase, text_color=color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 2, 7, "Accum: " + str.tostring(math.round(wyckoff.accumulation_prob)) + "%", text_color=color.green, text_size=dashboard_size)
    table.cell(dashboard, 3, 7, "Dist: " + str.tostring(math.round(wyckoff.distribution_prob)) + "%", text_color=color.red, text_size=dashboard_size)

    // Row 8: Quantitative
    table.cell(dashboard, 0, 8, "QUANT LAYER", text_color=color.gray, text_size=dashboard_size)
    table.cell(dashboard, 1, 8, "Z-Score: " + str.tostring(zscore, "#.00"),
              text_color=zscore > 0.0 ? color.green : color.red, text_size=dashboard_size)
    table.cell(dashboard, 2, 8, "Slope: " + str.tostring(norm_slope, "#.0"),
              text_color=norm_slope > 0.0 ? color.green : color.red, text_size=dashboard_size)
    table.cell(dashboard, 3, 8, "Q-Score: " + str.tostring(math.round(quant_score)) + "%", text_color=color.yellow, text_size=dashboard_size)

    // Row 9: Playbook
    table.cell(dashboard, 0, 9, "PLAYBOOK", text_color=color.gray, text_size=dashboard_size)
    pb_color = color.gray
    if selected_playbook.direction == 1
        pb_color := color.green
    else if selected_playbook.direction == -1
        pb_color := color.red
    table.cell(dashboard, 1, 9, selected_playbook.name, text_color=pb_color, text_size=dashboard_size)
    table.cell(dashboard, 2, 9, "Score: " + str.tostring(math.round(selected_playbook.score)) + "%", text_color=color.yellow, text_size=dashboard_size)
    table.cell(dashboard, 3, 9, "PBs: " + str.tostring(array.size(active_playbooks)), text_color=color.gray, text_size=dashboard_size)

    // Separator
    table.merge_cells(dashboard, 0, 10, 3, 10)
    table.cell(dashboard, 0, 10, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", text_color=color.gray, text_size=dashboard_size)

    // Row 11: Final Scores
    table.cell(dashboard, 0, 11, "FINAL SCORES", text_color=db_text_color, text_size=dashboard_size)
    table.cell(dashboard, 1, 11, "LONG: " + str.tostring(math.round(long_score)) + "%",
              bgcolor=color.new(color.green, 80), text_color=color.white, text_size=dashboard_size)
    table.cell(dashboard, 2, 11, "SHORT: " + str.tostring(math.round(short_score)) + "%",
              bgcolor=color.new(color.red, 80), text_color=color.white, text_size=dashboard_size)
    table.cell(dashboard, 3, 11, kill_active ? "🔴 KILL" : "🟢 ACTIVE",
              bgcolor=kill_active ? color.new(color.red, 80) : color.new(color.green, 80),
              text_color=color.white, text_size=dashboard_size)

    // Row 12: Signal
    table.cell(dashboard, 0, 12, "SIGNAL", text_color=color.gray, text_size=dashboard_size)
    signal_text_final = "---"
    signal_color_final = color.gray
    if final_long_signal
        signal_text_final := "▲ LONG"
        signal_color_final := color.green
    else if final_short_signal
        signal_text_final := "▼ SHORT"
        signal_color_final := color.red
    table.cell(dashboard, 1, 12, signal_text_final, text_color=signal_color_final, text_size=dashboard_size)
    table.cell(dashboard, 2, 12, "Preset: " + tf_preset_mode, text_color=color.gray, text_size=dashboard_size)
    table.cell(dashboard, 3, 12, session_ok ? "🕐 OK" : "⛔ OFF", text_color=session_ok ? color.green : color.red, text_size=dashboard_size)

    // Separator for backtest
    table.merge_cells(dashboard, 0, 13, 3, 13)
    table.cell(dashboard, 0, 13, "━━━━━━ BACKTEST PERFORMANCE ━━━━━━", text_color=color.gray, text_size=dashboard_size)

    // Backtest stats
    if enableBacktest
        table.cell(dashboard, 0, 14, "Win Rate", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 1, 14, str.tostring(math.round(bt_win_rate)) + "%",
                  text_color=bt_win_rate > 50.0 ? color.green : color.red, text_size=dashboard_size)
        table.cell(dashboard, 2, 14, "Profit Factor", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 3, 14, str.tostring(bt_profit_factor, "#.00"),
                  text_color=bt_profit_factor > 1.5 ? color.green : bt_profit_factor > 1.0 ? color.yellow : color.red, text_size=dashboard_size)

        table.cell(dashboard, 0, 15, "Total Trades", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 1, 15, str.tostring(bt_total_trades), text_color=color.white, text_size=dashboard_size)
        table.cell(dashboard, 2, 15, "Net Profit", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 3, 15, "$" + str.tostring(math.round(bt_net_profit, 2)),
                  text_color=bt_net_profit >= 0.0 ? color.green : color.red, text_size=dashboard_size)

        table.cell(dashboard, 0, 16, "Max DD %", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 1, 16, str.tostring(math.round(bt_max_dd_pct, 1)) + "%",
                  text_color=bt_max_dd_pct < 15.0 ? color.green : color.red, text_size=dashboard_size)
        table.cell(dashboard, 2, 16, "Sharpe Ratio", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 3, 16, str.tostring(bt_sharpe_ratio, "#.00"),
                  text_color=bt_sharpe_ratio > 1.0 ? color.green : bt_sharpe_ratio > 0.0 ? color.yellow : color.red, text_size=dashboard_size)

        table.cell(dashboard, 0, 17, "Expectancy", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 1, 17, "$" + str.tostring(bt_expectancy, "#.00"),
                  text_color=bt_expectancy > 0.0 ? color.green : color.red, text_size=dashboard_size)
        table.cell(dashboard, 2, 17, "Avg Win/Loss", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 3, 17, "$" + str.tostring(math.round(bt_avg_win, 2)) + "/$" + str.tostring(math.round(bt_avg_loss, 2)),
                  text_color=color.white, text_size=dashboard_size)

        table.cell(dashboard, 0, 18, "Consec Wins", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 1, 18, str.tostring(bt_max_consec_wins), text_color=color.green, text_size=dashboard_size)
        table.cell(dashboard, 2, 18, "Consec Losses", text_color=color.gray, text_size=dashboard_size)
        table.cell(dashboard, 3, 18, str.tostring(consec_losses) + "/" + str.tostring(maxConsecLosses),
                  text_color=consec_losses >= maxConsecLosses - 1 ? color.red : color.gray, text_size=dashboard_size)

======================================================================                  

5. APEX MERIDIAN (sina) 

// ============================================================================
// ██████████████████████████████████████████████████████████████████████████
// ██                                                                       ██
// ██    APEX MERIDIAN (sina) — CRYPTO CONFLUENCE SYSTEM                    ██
// ██    Architecture  : Multi-Layer Weighted Confluence System             ██
// ██    Asset Target  : BTC/USDT (Adaptable to Major Crypto Pairs)         ██
// ██    Timeframe     : Dynamic Timeframe Optimizer (Auto / Manual)        ██
// ██    Engine Type   : Trend-Following + Structure-Reactive Hybrid        ██
// ██    Risk Model    : ATR-Structural Dynamic | Partial TP Scaling        ██
// ██    Pine Version  : 6                                                  ██
// ██                                                                       ██
// ██████████████████████████████████████████████████████████████████████████
// ============================================================================

//@version=6
strategy(
     title = "APEX MERIDIAN (sina)", 
     overlay = true, 
     initial_capital = 10000, 
     default_qty_type = strategy.percent_of_equity, 
     default_qty_value = 3, 
     commission_type = strategy.commission.percent, 
     commission_value = 0.02, 
     slippage = 0, 
     max_bars_back = 1000, 
     calc_on_every_tick = true, 
     process_orders_on_close = true
     )

// ============================================================================
// ████  SECTION 1: INPUT GROUPS & USER PARAMETERS WITH TOOLTIPS  ████████████
// ============================================================================

// ── Group: Preset & System Mode ──────────────────────────────────────────────
var string GRP_PRESET   = "⚙️ System Preset Mode"
i_presetMode            = input.string("Auto", "Preset Mode Selection", options = ["Auto", "Manual"], group = GRP_PRESET, tooltip = "Auto: System dynamically optimizes swing depths, ATR multipliers, and HTF ranges for the active timeframe. Manual: Force system to use settings specified below.")

// ── Group: Higher Timeframe Configuration ────────────────────────────────────
var string GRP_HTF      = "🔷 Higher Timeframe Configuration"
i_htfRes                = input.timeframe("D",    "HTF Bias Timeframe [Manual]",     group = GRP_HTF, tooltip = "Used in Manual mode. Determines the timeframe from which structural trend direction is derived. Recommended: Daily for 4H execution.")
i_htfEmaFast            = input.int(21,           "HTF Fast EMA Period",  minval=5,  group = GRP_HTF, tooltip = "Shorter-term trend boundary calculated on the HTF chart. Recommended: 21.")
i_htfEmaSlow            = input.int(55,           "HTF Slow EMA Period",  minval=10, group = GRP_HTF, tooltip = "Medium-term trend boundary calculated on the HTF chart. Recommended: 55.")
i_htfEma200             = input.int(200,          "HTF Trend EMA Period", minval=50, group = GRP_HTF, tooltip = "Global institutional baseline. Price above this line signals a macro bull trend.")

// ── Group: Market Structure Engine ───────────────────────────────────────────
var string GRP_STRUCT   = "🔶 Market Structure Engine"
i_swingLookback         = input.int(10,           "Swing Lookback Depth [Manual]", minval=3,  maxval=50, group = GRP_STRUCT, tooltip = "Left/Right bar confirmation depth to establish valid swing high/low points. Low values react faster but generate noise.")
i_bosBuffer             = input.float(0.001,      "BOS Confirm Buffer (%)",       minval=0.0001, maxval=0.01, step=0.0001, group = GRP_STRUCT, tooltip = "Percent cushion required past a structural swing high/low to validate a Break of Structure.")
i_showStructure         = input.bool(true,        "Show Structure Labels",        group = GRP_STRUCT, tooltip = "Enables visual markup of BOS (Break of Structure) and CHoCH (Change of Character) on the chart.")
i_showBOS               = input.bool(true,        "Show BOS/CHoCH Lines",         group = GRP_STRUCT, tooltip = "Draws structural validation levels derived from recent pivot extremes.")

// ── Group: Order Block Detection ─────────────────────────────────────────────
var string GRP_OB       = "🟣 Order Block Detection"
i_obLookback            = input.int(30,           "Order Block Search Depth",     minval=5,  maxval=100, group = GRP_OB, tooltip = "Maximum past bars scanned to locate valid institutional order blocks.")
i_obMinSize             = input.float(0.3,        "Min OB Size (ATR Multiple)",   minval=0.1, maxval=3.0, step=0.1, group = GRP_OB, tooltip = "Filters out insignificant consolidation blocks. Requires the block candles to scale with volatility.")
i_obMaxAge              = input.int(100,          "Max OB Age (Bars)",            minval=10, maxval=300, group = GRP_OB, tooltip = "Invalidates blocks if not retested within this period. Prevents outdated structures from skewing current executions.")
i_showOB                = input.bool(true,        "Show Order Blocks",            group = GRP_OB, tooltip = "Renders verified high-volume buy/sell zones on the chart with soft-shaded boxes.")
i_obBoxExtend           = input.int(20,           "OB Visual Extension (Bars)",   minval=1,  maxval=50, group = GRP_OB, tooltip = "Visual extension of OB boundaries into future space for entry planning.")

// ── Group: Fair Value Gap Detection ──────────────────────────────────────────
var string GRP_FVG      = "🟢 Fair Value Gap Detection"
i_fvgMinSize            = input.float(0.2,        "Min FVG Size (ATR Multiple)",  minval=0.05, maxval=2.0, step=0.05, group = GRP_FVG, tooltip = "Minimum gap height as a fraction of current ATR. Prevents micro gaps from registering as active targets.")
i_fvgMaxAge             = input.int(50,           "Max FVG Age (Bars)",           minval=5, maxval=150, group = GRP_FVG, tooltip = "Gaps older than this value are deleted from active memory.")
i_showFVG               = input.bool(true,        "Show Fair Value Gaps",         group = GRP_FVG, tooltip = "Renders dynamic FVG inefficiency zones with subtle dashed boundaries.")

// ── Group: Momentum & Regime System ──────────────────────────────────────────
var string GRP_MOM      = "🔴 Momentum & Regime System"
i_rsiPeriod             = input.int(14,           "RSI Period",                   minval=7,  maxval=30, group = GRP_MOM, tooltip = "Lookback window for relative strength calculations. Recommended default is 14.")
i_rsiOB                 = input.int(70,           "RSI Overbought Level",         minval=60, maxval=85, group = GRP_MOM, tooltip = "Overbought score boundary. Cross above flags momentum saturation.")
i_rsiOS                 = input.int(30,           "RSI Oversold Level",           minval=15, maxval=40, group = GRP_MOM, tooltip = "Oversold score boundary. Cross below flags deep discount.")
i_macdFast              = input.int(12,           "MACD Fast Period",             minval=5,  maxval=25, group = GRP_MOM, tooltip = "Lookback for fast-response moving average. Default: 12.")
i_macdSlow              = input.int(26,           "MACD Slow Period",             minval=15, maxval=50, group = GRP_MOM, tooltip = "Lookback for slow-response moving average. Default: 26.")
i_macdSignal            = input.int(9,            "MACD Signal Period",           minval=3,  maxval=20, group = GRP_MOM, tooltip = "Smoothing period for the MACD crossover line. Default: 9.")
i_adxPeriod             = input.int(14,           "ADX Period",                   minval=7,  maxval=30, group = GRP_MOM, tooltip = "Lookback for Average Directional Index trend strength calculation.")
i_adxThreshold          = input.float(20.0,       "ADX Trend Threshold",          minval=10, maxval=40, step=0.5, group = GRP_MOM, tooltip = "Levels below this threshold signal range-bound market behavior.")
i_adxStrong             = input.float(30.0,       "ADX Strong Trend Level",       minval=20, maxval=60, step=0.5, group = GRP_MOM, tooltip = "Levels above this indicate a heavy institutional trending environment.")

// ── Group: VWAP Confluence System ────────────────────────────────────────────
var string GRP_VWAP     = "🔵 VWAP Confluence System"
i_useVwap               = input.bool(true,        "Enable VWAP Confluence",       group = GRP_VWAP, tooltip = "Integrates volume-weighted average pricing into the final signal score calculations.")
i_vwapDevMult1          = input.float(1.0,        "VWAP Band 1 Deviation",        minval=0.5, maxval=3.0, step=0.1, group = GRP_VWAP, tooltip = "Standard deviation multiplier for first-tier support/resistance bands.")
i_vwapDevMult2          = input.float(2.0,        "VWAP Band 2 Deviation",        minval=1.0, maxval=5.0, step=0.1, group = GRP_VWAP, tooltip = "Standard deviation multiplier for extreme outer-tier volatility bands.")
i_showVwap              = input.bool(true,        "Show VWAP Bands",              group = GRP_VWAP, tooltip = "Visualizes VWAP dynamic baseline and standard deviation bands on the chart.")

// ── Group: ATR & Volatility System ───────────────────────────────────────────
var string GRP_ATR      = "⚡ ATR & Volatility System"
i_atrPeriod             = input.int(14,           "ATR Period [Manual]",          minval=7,  maxval=30, group = GRP_ATR, tooltip = "Lookback period used to measure average true range market volatility.")
i_atrMultSL             = input.float(1.5,        "Stop Loss ATR Mult [Manual]",  minval=0.5, maxval=5.0, step=0.1, group = GRP_ATR, tooltip = "Determines Stop Loss distance based on current volatility to avoid getting stopped out by crypto wicks.")
i_atrMultTP1            = input.float(1.5,        "TP1 ATR Mult [Manual]",        minval=0.5, maxval=5.0, step=0.1, group = GRP_ATR, tooltip = "Volatility multiplier for First Take Profit level.")
i_atrMultTP2            = input.float(3.0,        "TP2 ATR Mult [Manual]",        minval=1.0, maxval=10.0, step=0.1, group = GRP_ATR, tooltip = "Volatility multiplier for Second Take Profit level.")
i_atrMultTP3            = input.float(5.0,        "TP3 ATR Mult [Manual]",        minval=2.0, maxval=15.0, step=0.1, group = GRP_ATR, tooltip = "Volatility multiplier for Final/Trailing Take Profit level.")
i_atrMultTrail          = input.float(2.0,        "Trailing Stop ATR Multiple",   minval=0.5, maxval=5.0, step=0.1, group = GRP_ATR, tooltip = "Volatility distance preserved behind price for the dynamic trailing exit.")
i_volFilterEnable       = input.bool(true,        "Enable Volatility Filter",     group = GRP_ATR, tooltip = "Blocks execution when market volatility reaches extremely dead or unsustainably chaotic levels.")
i_volFilterPeriod       = input.int(50,           "Volatility Percentile Period", minval=20, maxval=200, group = GRP_ATR, tooltip = "Lookback history for classifying current ATR percentile relative to historical range.")
i_volFilterLow          = input.float(15.0,       "Min Volatility Percentile",    minval=5,  maxval=40, step=1, group = GRP_ATR, tooltip = "Lowest volatility percentile tolerated. Avoids range-bound markets.")
i_volFilterHigh         = input.float(85.0,       "Max Volatility Percentile",    minval=50, maxval=99, step=1, group = GRP_ATR, tooltip = "Highest volatility percentile tolerated. Avoids hyper-extended flash crashes.")

// ── Group: Confluence Scoring Weights ────────────────────────────────────────
var string GRP_SCORE    = "⚖️ Confluence Scoring Weights"
i_wStructure            = input.float(30.0,       "Market Structure Weight (%)",  minval=0, maxval=50, step=1, group = GRP_SCORE, tooltip = "Percentage weight of structure alignment in the final entry score computation.")
i_wOrderBlock           = input.float(25.0,       "Order Block Weight (%)",       minval=0, maxval=50, step=1, group = GRP_SCORE, tooltip = "Percentage weight of proximity to valid order blocks.")
i_wMomentum             = input.float(20.0,       "Momentum Weight (%)",          minval=0, maxval=50, step=1, group = GRP_SCORE, tooltip = "Percentage weight of RSI, MACD, and EMA alignment.")
i_wVwap                 = input.float(15.0,       "VWAP Confluence Weight (%)",   minval=0, maxval=50, step=1, group = GRP_SCORE, tooltip = "Percentage weight of VWAP dynamic bands confirmation.")
i_wHTF                  = input.float(10.0,       "HTF Bias Weight (%)",          minval=0, maxval=30, step=1, group = GRP_SCORE, tooltip = "Percentage weight of higher timeframe trend bias.")
i_minLongScore          = input.float(60.0,       "Min Long Entry Score (%)",     minval=40, maxval=95, step=1, group = GRP_SCORE, tooltip = "Minimum confluence score threshold required to trigger buy setups.")
i_minShortScore         = input.float(60.0,       "Min Short Entry Score (%)",    minval=40, maxval=95, step=1, group = GRP_SCORE, tooltip = "Minimum confluence score threshold required to trigger sell setups.")

// ── Group: Position Sizing & Risk ────────────────────────────────────────────
var string GRP_RISK     = "🛡️ Position Sizing & Risk Management"
i_riskPctPerTrade       = input.float(1.0,        "Risk % Per Trade",             minval=0.1, maxval=5.0, step=0.1, group = GRP_RISK, tooltip = "Translates Stop Loss distance into a concrete contract size based on portfolio equity.")
i_tp1Pct                = input.float(33.0,       "TP1 Close % of Position",      minval=10, maxval=60,  step=1, group = GRP_RISK, tooltip = "Position reduction percentage executed when price taps target TP1.")
i_tp2Pct                = input.float(33.0,       "TP2 Close % of Position",      minval=10, maxval=60,  step=1, group = GRP_RISK, tooltip = "Position reduction percentage executed when price taps target TP2.")
i_breakEvenAfterTP1     = input.bool(true,        "Move to Breakeven After TP1",  group = GRP_RISK, tooltip = "Locks in protection by shifting Stop Loss to Entry price after TP1 is filled.")
i_trailAfterTP2         = input.bool(true,        "Enable Trail After TP2",       group = GRP_RISK, tooltip = "Launches trailing ATR exit on the remaining position portion after TP2 target is secured.")
i_maxConsecLoss         = input.int(4,            "Max Consecutive Losses",       minval=1, maxval=10, group = GRP_RISK, tooltip = "System Kill Switch. Shuts down order generation if consecutive losses hit this number.")
i_killCooldown          = input.int(10,           "Kill Switch Cooldown (Bars)",  minval=1, maxval=50, group = GRP_RISK, tooltip = "Inactivation time window (candles) before the strategy recovers from a Kill Switch shutdown.")

// ── Group: Visualization ─────────────────────────────────────────────────────
var string GRP_VIZ      = "🎨 Visualization & Display"
i_showDashboard         = input.bool(true,        "Show Performance Dashboard",   group = GRP_VIZ, tooltip = "Renders a clean, institutional trading performance overlay on the upper right corner of the chart.")
i_showSignalLabels      = input.bool(true,        "Show Signal Labels",           group = GRP_VIZ, tooltip = "Toggles high-contrast entry buy/sell labels detailing score and active confirmation pillars.")
i_showTpSlLines         = input.bool(true,        "Show TP/SL Lines",             group = GRP_VIZ, tooltip = "Toggles real-time dynamic TP/SL target lines on active positions.")
i_showEMAs              = input.bool(true,        "Show EMA Ribbons",             group = GRP_VIZ, tooltip = "Renders three-tier trend-following EMA ribbon structure.")
i_showScoreBg           = input.bool(true,        "Show Score Background",        group = GRP_VIZ, tooltip = "Paints subtle background heat gradients mapped directly to the confluence scoring levels.")

// ── Group: Backtesting Date Range ─────────────────────────────────────────────
var string GRP_DATE     = "📅 Backtest Date Range"
i_startDate             = input.time(timestamp("01 Jan 2020 00:00 +0000"), "Start Date", group = GRP_DATE)
i_endDate               = input.time(timestamp("31 Dec 2099 00:00 +0000"), "End Date",   group = GRP_DATE)


// ============================================================================
// ████  SECTION 2: DYNAMIC PRESET ENGINE (AUTO OPTIMIZER)  ██████████████████
// ============================================================================

// Resolve current chart timeframe in minutes to execute automatic classification
float current_tf_minutes = timeframe.isseconds ? 0.1 : 
                           timeframe.isminutes ? float(timeframe.multiplier) : 
                           timeframe.isdaily   ? 1440.0 * timeframe.multiplier : 
                           timeframe.isweekly  ? 10080.0 * timeframe.multiplier : 43200.0

// Declare variable parameters to capture dynamic modifications
string  calc_htfRes         = i_htfRes
int     calc_swingLookback   = i_swingLookback
int     calc_atrPeriod       = i_atrPeriod
float   calc_atrMultSL       = i_atrMultSL
float   calc_atrMultTP1      = i_atrMultTP1
float   calc_atrMultTP2      = i_atrMultTP2
float   calc_atrMultTP3      = i_atrMultTP3

// Timeframe classification conditions
bool is_scalping = current_tf_minutes <= 15.0
bool is_intraday = current_tf_minutes > 15.0 and current_tf_minutes <= 120.0
bool is_swing    = current_tf_minutes > 120.0 and current_tf_minutes <= 240.0
bool is_macro    = current_tf_minutes > 240.0

if i_presetMode == "Auto"
    if is_scalping
        calc_htfRes         := "60"
        calc_swingLookback   := 15
        calc_atrPeriod       := 21
        calc_atrMultSL       := 2.2
        calc_atrMultTP1      := 1.5
        calc_atrMultTP2      := 3.0
        calc_atrMultTP3      := 4.5
    else if is_intraday
        calc_htfRes         := "240"
        calc_swingLookback   := 10
        calc_atrPeriod       := 14
        calc_atrMultSL       := 1.8
        calc_atrMultTP1      := 1.5
        calc_atrMultTP2      := 3.0
        calc_atrMultTP3      := 5.0
    else if is_swing
        calc_htfRes         := "D"
        calc_swingLookback   := 8
        calc_atrPeriod       := 14
        calc_atrMultSL       := 1.5
        calc_atrMultTP1      := 1.5
        calc_atrMultTP2      := 3.0
        calc_atrMultTP3      := 5.0
    else // is_macro
        calc_htfRes         := "W"
        calc_swingLookback   := 5
        calc_atrPeriod       := 14
        calc_atrMultSL       := 1.5
        calc_atrMultTP1      := 2.0
        calc_atrMultTP2      := 4.0
        calc_atrMultTP3      := 6.0


// ============================================================================
// ████  SECTION 3: UNCONDITIONAL ROOT-SCOPE INDICATOR CALCULATIONS  █████████
// ============================================================================

// ── ATR System (Pre-computed for constant inputs to avoid pine v6 compile errors)
float atr14             = ta.atr(14)
float atr21             = ta.atr(21)
float atr               = nz(calc_atrPeriod == 21 ? atr21 : atr14)

// ── Volatility Percentile Rank
float atrHistoryMax     = ta.highest(atr, i_volFilterPeriod)
float atrHistoryMin     = ta.lowest(atr, i_volFilterPeriod)
float volRange          = atrHistoryMax - atrHistoryMin
float volPercentile     = volRange > 0 ? ((atr - atrHistoryMin) / volRange) * 100 : 50.0
bool  volFilterPass     = not i_volFilterEnable or (volPercentile >= i_volFilterLow and volPercentile <= i_volFilterHigh)

// ── Local Core EMAs
float ema9              = ta.ema(close, 9)
float ema21             = ta.ema(close, 21)
float ema50             = ta.ema(close, 50)
float ema100            = ta.ema(close, 100)
float ema200            = ta.ema(close, 200)

// ── Momentum Oscillator Core
float rsi               = ta.rsi(close, i_rsiPeriod)
[macdLine, signalLine, macdHist] = ta.macd(close, i_macdFast, i_macdSlow, i_macdSignal)

// ── ADX / Trend Strength Engine
float raw_hl            = high - low
float raw_hc            = math.abs(high - close[1])
float raw_lc            = math.abs(low - close[1])
float trueRange         = math.max(raw_hl, math.max(raw_hc, raw_lc))

float dmPlus            = high - high[1] > low[1] - low ? math.max(high - high[1], 0) : 0
float dmMinus           = low[1] - low > high - high[1] ? math.max(low[1] - low, 0)   : 0

float smTR              = ta.rma(trueRange, i_adxPeriod)
float smDmPlus          = ta.rma(dmPlus, i_adxPeriod)
float smDmMinus         = ta.rma(dmMinus, i_adxPeriod)

float diPlus            = smTR != 0 ? (smDmPlus  / smTR) * 100 : 0
float diMinus           = smTR != 0 ? (smDmMinus / smTR) * 100 : 0
float diSum             = diPlus + diMinus
float dx                = diSum != 0 ? (math.abs(diPlus - diMinus) / diSum) * 100 : 0
float adx               = ta.rma(dx, i_adxPeriod)

// ── VWAP Calculations
float vwapVal           = ta.vwap(hlc3)
int   vwapBandPeriod    = 20
float vwapStdev         = ta.stdev(hlc3, vwapBandPeriod)
float vwapBand1Up       = vwapVal + (i_vwapDevMult1 * vwapStdev)
float vwapBand1Dn       = vwapVal - (i_vwapDevMult1 * vwapStdev)
float vwapBand2Up       = vwapVal + (i_vwapDevMult2 * vwapStdev)
float vwapBand2Dn       = vwapVal - (i_vwapDevMult2 * vwapStdev)


// ============================================================================
// ████  SECTION 4: HIGHER TIMEFRAME BIAS ENGINE  ██████████████████████████
// ============================================================================

f_htf_calculations() =>
    [close[1], ta.ema(close, i_htfEmaFast)[1], ta.ema(close, i_htfEmaSlow)[1], ta.ema(close, i_htfEma200)[1], ta.rsi(close, 14)[1]]

// Execution of structural higher timeframe calculations
[htfClose, htfEmaFast, htfEmaSlow, htfEma200Val, htfRsi] = request.security(syminfo.tickerid, calc_htfRes, f_htf_calculations(), barmerge.gaps_off, barmerge.lookahead_off)

bool htfAbove200        = not na(htfEma200Val) and htfClose > htfEma200Val
bool htfAboveSlow       = not na(htfEmaSlow)   and htfClose > htfEmaSlow
bool htfFastAboveSlow   = not na(htfEmaFast) and not na(htfEmaSlow) and htfEmaFast > htfEmaSlow
bool htfRsiBullish      = not na(htfRsi) and htfRsi > 50
bool htfRsiBearish      = not na(htfRsi) and htfRsi < 50

int htfBullPoints       = (htfAbove200 ? 1 : 0) + (htfAboveSlow ? 1 : 0) + (htfFastAboveSlow ? 1 : 0) + (htfRsiBullish ? 1 : 0)
int htfBearPoints       = (not htfAbove200 ? 1 : 0) + (not htfAboveSlow ? 1 : 0) + (not htfFastAboveSlow ? 1 : 0) + (htfRsiBearish ? 1 : 0)

float htfLongScore      = (htfBullPoints / 4.0) * 100
float htfShortScore     = (htfBearPoints / 4.0) * 100


// ============================================================================
// ████  SECTION 5: MARKET STRUCTURE DETECTION ENGINE  █████████████████████
// ============================================================================

// Pre-calculate pivot configurations unconditionally to avoid pine compilation errors
pivH5  = ta.pivothigh(high, 5, 5),   pivL5  = ta.pivotlow(low, 5, 5)
pivH8  = ta.pivothigh(high, 8, 8),   pivL8  = ta.pivotlow(low, 8, 8)
pivH10 = ta.pivothigh(high, 10, 10), pivL10 = ta.pivotlow(low, 10, 10)
pivH15 = ta.pivothigh(high, 15, 15), pivL15 = ta.pivotlow(low, 15, 15)

// Dynamic assignment map matching lookbacks cleanly
float swingH = calc_swingLookback == 5  ? pivH5  : calc_swingLookback == 8  ? pivH8  : calc_swingLookback == 15 ? pivH15 : pivH10
float swingL = calc_swingLookback == 5  ? pivL5  : calc_swingLookback == 8  ? pivL8  : calc_swingLookback == 15 ? pivL15 : pivL10

var float lastSwingHigh     = na
var float lastSwingLow      = na
var int   lastSwingHighBar  = na
var int   lastSwingLowBar   = na
var float prevSwingHigh     = na
var float prevSwingLow      = na

if not na(swingH)
    prevSwingHigh       := lastSwingHigh
    lastSwingHigh       := swingH
    lastSwingHighBar    := bar_index - calc_swingLookback

if not na(swingL)
    prevSwingLow        := lastSwingLow
    lastSwingLow        := swingL
    lastSwingLowBar     := bar_index - calc_swingLookback

// ── Break of Structure (BOS) Detection
float bosBuffer         = close * i_bosBuffer
bool bosLong            = not na(lastSwingHigh) and close > lastSwingHigh + bosBuffer and close[1] <= lastSwingHigh + bosBuffer
bool bosShort           = not na(lastSwingLow) and close < lastSwingLow - bosBuffer and close[1] >= lastSwingLow - bosBuffer

var bool inUptrend      = false
var bool inDowntrend    = false

if bosLong
    inUptrend           := true
    inDowntrend         := false
if bosShort
    inDowntrend         := true
    inUptrend           := false

bool chochBull          = inDowntrend and bosLong
bool chochBear          = inUptrend and bosShort

float dealingRangeHigh  = not na(lastSwingHigh) ? lastSwingHigh : high
float dealingRangeLow   = not na(lastSwingLow) ? lastSwingLow : low
float dealingRangeMid   = (dealingRangeHigh + dealingRangeLow) / 2.0
bool  priceInDiscount   = close < dealingRangeMid
bool  priceInPremium    = close > dealingRangeMid

float structureLongScore  = 0.0
float structureShortScore = 0.0

if inUptrend
    structureLongScore  := structureLongScore + 40.0
if bosLong
    structureLongScore  := structureLongScore + 30.0
if chochBull
    structureLongScore  := structureLongScore + 20.0
if priceInDiscount
    structureLongScore  := structureLongScore + 10.0

if inDowntrend
    structureShortScore := structureShortScore + 40.0
if bosShort
    structureShortScore := structureShortScore + 30.0
if chochBear
    structureShortScore := structureShortScore + 20.0
if priceInPremium
    structureShortScore := structureShortScore + 10.0

structureLongScore      := math.min(structureLongScore, 100.0)
structureShortScore     := math.min(structureShortScore, 100.0)


// ============================================================================
// ████  SECTION 6: ORDER BLOCK DETECTION & SCORING  ███████████████████████
// ============================================================================

var float bullOB_Top    = na
var float bullOB_Bot    = na
var int   bullOB_Age    = 0
var bool  bullOB_Valid  = false

var float bearOB_Top    = na
var float bearOB_Bot    = na
var int   bearOB_Age    = 0
var bool  bearOB_Valid  = false

float obMinSize         = atr * i_obMinSize

// Static loop index logic avoids pine runtime errors
for i = 1 to 30
    bool wasBearish      = close[i] < open[i]
    float candleSize     = math.abs(close[i] - open[i])
    float subsequentMove = close[i-1] - close[i]

    if wasBearish and candleSize >= obMinSize and subsequentMove > atr * 1.5 and not bullOB_Valid
        bullOB_Top      := math.max(open[i], close[i])
        bullOB_Bot      := math.min(open[i], close[i])
        bullOB_Age      := i
        bullOB_Valid    := true
        break

for i = 1 to 30
    bool wasBullish      = close[i] > open[i]
    float candleSize     = math.abs(close[i] - open[i])
    float subsequentMove = close[i] - close[i-1]

    if wasBullish and candleSize >= obMinSize and subsequentMove > atr * 1.5 and not bearOB_Valid
        bearOB_Top      := math.max(open[i], close[i])
        bearOB_Bot      := math.min(open[i], close[i])
        bearOB_Age      := i
        bearOB_Valid    := true
        break

// ── Invalidation Engine
if bullOB_Valid
    bullOB_Age          := bullOB_Age + 1
    if close < bullOB_Bot or bullOB_Age > i_obMaxAge
        bullOB_Valid    := false
        bullOB_Top      := na
        bullOB_Bot      := na

if bearOB_Valid
    bearOB_Age          := bearOB_Age + 1
    if close > bearOB_Top or bearOB_Age > i_obMaxAge
        bearOB_Valid    := false
        bearOB_Top      := na
        bearOB_Bot      := na

// Proximity Scoring using safety nz structures to prevent compilation na leaks
float obLongScore       = 0.0
float obShortScore      = 0.0

if bullOB_Valid and not na(bullOB_Top) and not na(bullOB_Bot)
    if close >= bullOB_Bot and close <= bullOB_Top
        obLongScore     := 100.0
    else if close > bullOB_Top and close <= bullOB_Top + atr
        float dist      = close - bullOB_Top
        obLongScore     := math.max(0, 80.0 - (dist / atr) * 30.0)
    else if close < bullOB_Bot and close >= bullOB_Bot - atr
        float dist      = bullOB_Bot - close
        obLongScore     := math.max(0, 60.0 - (dist / atr) * 30.0)

if bearOB_Valid and not na(bearOB_Top) and not na(bearOB_Bot)
    if close >= bearOB_Bot and close <= bearOB_Top
        obShortScore    := 100.0
    else if close < bearOB_Bot and close >= bearOB_Bot - atr
        float dist      = bearOB_Bot - close
        obShortScore    := math.max(0, 80.0 - (dist / atr) * 30.0)
    else if close > bearOB_Top and close <= bearOB_Top + atr
        float dist      = close - bearOB_Top
        obShortScore    := math.max(0, 60.0 - (dist / atr) * 30.0)


// ============================================================================
// ████  SECTION 7: FAIR VALUE GAP (FVG) DETECTION  ████████████████████████
// ============================================================================

var float bullFVG_Top   = na
var float bullFVG_Bot   = na
var int   bullFVG_Age   = 0
var bool  bullFVG_Valid = false

var float bearFVG_Top   = na
var float bearFVG_Bot   = na
var int   bearFVG_Age   = 0
var bool  bearFVG_Valid = false

float fvgMinSize        = atr * i_fvgMinSize
float potBullFVGBot     = high[2]
float potBullFVGTop     = low[0]
float potBearFVGTop     = low[2]
float potBearFVGBot     = high[0]

bool newBullFVG         = potBullFVGTop > potBullFVGBot and (potBullFVGTop - potBullFVGBot) >= fvgMinSize
bool newBearFVG         = potBearFVGTop < potBearFVGBot and (potBearFVGBot - potBearFVGTop) >= fvgMinSize

if newBullFVG and (not bullFVG_Valid or bullFVG_Age > 5)
    bullFVG_Top         := potBullFVGTop
    bullFVG_Bot         := potBullFVGBot
    bullFVG_Age         := 0
    bullFVG_Valid       := true

if newBearFVG and (not bearFVG_Valid or bearFVG_Age > 5)
    bearFVG_Top         := potBearFVGTop
    bearFVG_Bot         := potBearFVGBot
    bearFVG_Age         := 0
    bearFVG_Valid       := true

if bullFVG_Valid
    bullFVG_Age         := bullFVG_Age + 1
    if close < bullFVG_Bot or bullFVG_Age > i_fvgMaxAge
        bullFVG_Valid   := false
        bullFVG_Top     := na
        bullFVG_Bot     := na

if bearFVG_Valid
    bearFVG_Age         := bearFVG_Age + 1
    if close > bearFVG_Top or bearFVG_Age > i_fvgMaxAge
        bearFVG_Valid   := false
        bearFVG_Top     := na
        bearFVG_Bot     := na

float fvgLongBonus      = 0.0
float fvgShortBonus     = 0.0

if bullFVG_Valid and not na(bullFVG_Top) and not na(bullFVG_Bot)
    if close >= bullFVG_Bot and close <= bullFVG_Top
        fvgLongBonus    := 20.0
    else if close > bullFVG_Top and close <= bullFVG_Top + atr * 0.5
        fvgLongBonus    := 10.0

if bearFVG_Valid and not na(bearFVG_Top) and not na(bearFVG_Bot)
    if close <= bearFVG_Top and close >= bearFVG_Bot
        fvgShortBonus   := 20.0
    else if close < bearFVG_Bot and close >= bearFVG_Bot - atr * 0.5
        fvgShortBonus   := 10.0

obLongScore             := math.min(100.0, obLongScore + fvgLongBonus)
obShortScore            := math.min(100.0, obShortScore + fvgShortBonus)


// ============================================================================
// ████  SECTION 8: MOMENTUM & REGIME SCORING ENGINE  ██████████████████████
// ============================================================================

bool isTrending         = adx >= i_adxThreshold
bool isStrongTrend      = adx >= i_adxStrong
bool isBullTrend        = diPlus > diMinus
bool isBearTrend        = diMinus > diPlus

bool rsiBullishZone     = rsi > 50 and rsi < i_rsiOB
bool rsiBearishZone     = rsi < 50 and rsi > i_rsiOS
bool rsiOversold        = rsi <= i_rsiOS
bool rsiOverbought      = rsi >= i_rsiOB

float rsiHighest        = ta.highest(rsi, 14)
float rsiLowest         = ta.lowest(rsi, 14)
float priceHighest      = ta.highest(high, 14)
float priceLowest       = ta.lowest(low, 14)

bool rsiBullDiv         = low == priceLowest and rsi > rsiLowest + 5
bool rsiBearDiv         = high == priceHighest and rsi < rsiHighest - 5

bool macdBullish        = macdLine > 0 and macdLine > signalLine
bool macdBearish        = macdLine < 0 and macdLine < signalLine
bool macdBullCross      = ta.crossover(macdLine, signalLine)
bool macdBearCross      = ta.crossunder(macdLine, signalLine)
bool macdMomentumUp     = macdHist > macdHist[1]
bool macdMomentumDown   = macdHist < macdHist[1]

bool emaAlignBull       = ema9 > ema21 and ema21 > ema50
bool emaAlignBear       = ema9 < ema21 and ema21 < ema50
bool priceAboveEma200   = close > ema200
bool priceBelowEma200   = close < ema200

float momentumLongScore  = 0.0
float momentumShortScore = 0.0

if isTrending and isBullTrend
    momentumLongScore   := momentumLongScore + (isStrongTrend ? 30.0 : 20.0)
if isTrending and isBearTrend
    momentumShortScore  := momentumShortScore + (isStrongTrend ? 30.0 : 20.0)

if rsiBullishZone
    momentumLongScore   := momentumLongScore + 15.0
if rsiOversold
    momentumLongScore   := momentumLongScore + 25.0
if rsiBullDiv
    momentumLongScore   := momentumLongScore + 20.0
if rsiBearishZone
    momentumShortScore  := momentumShortScore + 15.0
if rsiOverbought
    momentumShortScore  := momentumShortScore + 25.0
if rsiBearDiv
    momentumShortScore  := momentumShortScore + 20.0

if macdBullish
    momentumLongScore   := momentumLongScore + 10.0
if macdBullCross
    momentumLongScore   := momentumLongScore + 15.0
if macdMomentumUp and macdBullish
    momentumLongScore   := momentumLongScore + 10.0
if macdBearish
    momentumShortScore  := momentumShortScore + 10.0
if macdBearCross
    momentumShortScore  := momentumShortScore + 15.0
if macdMomentumDown and macdBearish
    momentumShortScore  := momentumShortScore + 10.0

if emaAlignBull and priceAboveEma200
    momentumLongScore   := momentumLongScore + 20.0
else if emaAlignBull
    momentumLongScore   := momentumLongScore + 10.0

if emaAlignBear and priceBelowEma200
    momentumShortScore  := momentumShortScore + 20.0
else if emaAlignBear
    momentumShortScore  := momentumShortScore + 10.0

momentumLongScore       := math.min(100.0, momentumLongScore)
momentumShortScore      := math.min(100.0, momentumShortScore)


// ============================================================================
// ████  SECTION 9: VWAP CONFLUENCE SCORING ENGINE  ████████████████████████
// ============================================================================

float vwapLongScore     = 0.0
float vwapShortScore    = 0.0

if i_useVwap and not na(vwapVal)
    bool priceAboveVwap = close > vwapVal
    bool priceBelowVwap = close < vwapVal
    bool priceAtVwap    = math.abs(close - vwapVal) < atr * 0.3

    if priceAboveVwap
        vwapLongScore   := vwapLongScore + 30.0
        if close[1] < vwapVal
            vwapLongScore := vwapLongScore + 20.0

    if close >= vwapBand1Dn and close <= vwapVal
        vwapLongScore   := vwapLongScore + 25.0
    if close >= vwapBand2Dn and close < vwapBand1Dn
        vwapLongScore   := vwapLongScore + 35.0

    if priceAtVwap
        vwapLongScore   := vwapLongScore + 15.0

    if priceBelowVwap
        vwapShortScore  := vwapShortScore + 30.0
        if close[1] > vwapVal
            vwapShortScore := vwapShortScore + 20.0

    if close <= vwapBand1Up and close >= vwapVal
        vwapShortScore  := vwapShortScore + 25.0
    if close <= vwapBand2Up and close > vwapBand1Up
        vwapShortScore  := vwapShortScore + 35.0

    if priceAtVwap
        vwapShortScore  := vwapShortScore + 15.0

vwapLongScore           := math.min(100.0, vwapLongScore)
vwapShortScore          := math.min(100.0, vwapShortScore)


// ============================================================================
// ████  SECTION 10: WEIGHTED CONFLUENCE SCORING SYSTEM  ███████████████████
// ============================================================================

// Normalise dynamic weights
float totalWeight       = i_wStructure + i_wOrderBlock + i_wMomentum + i_wVwap + i_wHTF
float wStruct_norm      = totalWeight > 0 ? i_wStructure  / totalWeight : 0.25
float wOB_norm          = totalWeight > 0 ? i_wOrderBlock / totalWeight : 0.25
float wMom_norm         = totalWeight > 0 ? i_wMomentum   / totalWeight : 0.20
float wVwap_norm        = totalWeight > 0 ? i_wVwap       / totalWeight : 0.15
float wHTF_norm         = totalWeight > 0 ? i_wHTF        / totalWeight : 0.10

// Safe extraction of confluence components (guarantees no na score-poisoning)
float safe_structLong   = nz(structureLongScore, 0.0)
float safe_structShort  = nz(structureShortScore, 0.0)
float safe_obLong       = nz(obLongScore, 0.0)
float safe_obShort      = nz(obShortScore, 0.0)
float safe_momLong      = nz(momentumLongScore, 0.0)
float safe_momShort     = nz(momentumShortScore, 0.0)
float safe_vwapLong     = nz(vwapLongScore, 0.0)
float safe_vwapShort    = nz(vwapShortScore, 0.0)
float safe_htfLong      = nz(htfLongScore, 0.0)
float safe_htfShort     = nz(htfShortScore, 0.0)

float confluenceLong    = (safe_structLong   * wStruct_norm) +
                          (safe_obLong       * wOB_norm)     +
                          (safe_momLong      * wMom_norm)    +
                          (safe_vwapLong     * wVwap_norm)   +
                          (safe_htfLong      * wHTF_norm)

float confluenceShort   = (safe_structShort  * wStruct_norm) +
                          (safe_obShort      * wOB_norm)     +
                          (safe_momShort     * wMom_norm)    +
                          (safe_vwapShort    * wVwap_norm)   +
                          (safe_htfShort     * wHTF_norm)


// ============================================================================
// ████  SECTION 11: KILL SWITCH ENGINE (RISK SAFEGUARDS)  █████████████████
// ============================================================================

var int consecLosses    = 0
var int killCooldownBar = 0
var bool killActive     = false

if strategy.closedtrades > 0
    float lastReturn    = strategy.closedtrades.profit(strategy.closedtrades - 1)
    if lastReturn < 0
        consecLosses    := consecLosses + 1
    else
        consecLosses    := 0

if consecLosses >= i_maxConsecLoss
    killActive          := true
    killCooldownBar     := bar_index + i_killCooldown
    consecLosses        := 0

if killActive and bar_index >= killCooldownBar
    killActive          := false

bool withinDateRange    = time >= i_startDate and time <= i_endDate
bool tradingPermitted   = not killActive and withinDateRange and volFilterPass


// ============================================================================
// ████  SECTION 12: ENTRY SIGNAL GENERATION & VERIFICATION  ██████████████
// ============================================================================

bool longSignalRaw      = confluenceLong  >= i_minLongScore  and tradingPermitted
bool shortSignalRaw     = confluenceShort >= i_minShortScore and tradingPermitted

float dist_from_ema21   = math.abs(close - ema21) / atr
bool notExtended        = dist_from_ema21 < 4.0

bool hasVolume          = not na(volume) and volume > 0
float avgVolume         = ta.sma(volume, 20)
bool volConfirm         = not hasVolume or (volume > avgVolume * 0.8)

// Execution Signals
bool longSignal         = longSignalRaw  and notExtended and volConfirm
bool shortSignal        = shortSignalRaw and notExtended and volConfirm


// ============================================================================
// ████  SECTION 13: RISK MANAGEMENT & DYNAMIC LEVELS  ████████████████████
// ============================================================================

float longStopAtr       = close - (atr * calc_atrMultSL)
float longStopStruct    = not na(lastSwingLow) ? lastSwingLow - (atr * 0.3) : longStopAtr
float longSL            = math.min(longStopAtr, longStopStruct)

float shortStopAtr      = close + (atr * calc_atrMultSL)
float shortStopStruct   = not na(lastSwingHigh) ? lastSwingHigh + (atr * 0.3) : shortStopAtr
float shortSL           = math.max(shortStopAtr, shortStopStruct)

float longTP1           = close + (atr * calc_atrMultTP1)
float longTP2           = close + (atr * calc_atrMultTP2)
float longTP3           = close + (atr * calc_atrMultTP3)

float shortTP1          = close - (atr * calc_atrMultTP1)
float shortTP2          = close - (atr * calc_atrMultTP2)
float shortTP3          = close - (atr * calc_atrMultTP3)

var float entryPrice    = na
var float activeSL      = na
var float activeTP1     = na
var float activeTP2     = na
var float activeTP3     = na
var bool  tp1Hit        = false
var bool  tp2Hit        = false
var bool  isLong        = false
var bool  isShort       = false
var float trailStopLevel = na
var bool  trailActive   = false

// ── Trailing Stop Calculations
if strategy.position_size > 0 and isLong
    if tp2Hit and i_trailAfterTP2
        trailActive     := true
        float newTrail  = high - (atr * i_atrMultTrail)
        trailStopLevel  := na(trailStopLevel) ? newTrail : math.max(trailStopLevel, newTrail)

if strategy.position_size < 0 and isShort
    if tp2Hit and i_trailAfterTP2
        trailActive     := true
        float newTrail  = low + (atr * i_atrMultTrail)
        trailStopLevel  := na(trailStopLevel) ? newTrail : math.min(trailStopLevel, newTrail)

if strategy.position_size == 0
    entryPrice          := na
    activeSL            := na
    activeTP1           := na
    activeTP2           := na
    activeTP3           := na
    tp1Hit              := false
    tp2Hit              := false
    isLong              := false
    isShort             := false
    trailStopLevel      := na
    trailActive         := false


// ============================================================================
// ████  SECTION 14: STRATEGY EXECUTION ENGINE  ████████████████████████████
// ============================================================================

// Calculate risk-adjusted trade sizes
float longRiskVal       = math.abs(close - longSL)
float longPositionSize  = longRiskVal > 0 ? (strategy.equity * (i_riskPctPerTrade / 100)) / longRiskVal : na

float shortRiskVal      = math.abs(shortSL - close)
float shortPositionSize = shortRiskVal > 0 ? (strategy.equity * (i_riskPctPerTrade / 100)) / shortRiskVal : na

// ── Long Strategy Executions
if longSignal and strategy.position_size == 0
    strategy.entry("LONG", strategy.long, qty = longPositionSize, comment = "L Entry " + str.tostring(math.round(confluenceLong, 1)) + "%")

    entryPrice          := close
    activeSL            := longSL
    activeTP1           := longTP1
    activeTP2           := longTP2
    activeTP3           := longTP3
    tp1Hit              := false
    tp2Hit              := false
    isLong              := true
    isShort             := false
    trailActive         := false
    trailStopLevel      := na

    strategy.exit("LONG_TP1", "LONG", qty_percent = i_tp1Pct, limit = longTP1, stop = longSL, comment = "L TP1")
    strategy.exit("LONG_TP2", "LONG", qty_percent = i_tp2Pct, limit = longTP2, stop = longSL, comment = "L TP2")
    strategy.exit("LONG_TP3", "LONG", limit = longTP3, stop = longSL, comment = "L TP3")

// ── Long Breakeven Logic
if isLong and strategy.position_size > 0 and not tp1Hit
    if high >= activeTP1
        tp1Hit          := true
        if i_breakEvenAfterTP1 and not na(entryPrice)
            strategy.cancel("LONG_TP1")
            strategy.cancel("LONG_TP2")
            strategy.cancel("LONG_TP3")
            activeSL    := entryPrice + (atr * 0.1)
            strategy.exit("LONG_TP2_BE", "LONG", qty_percent = i_tp2Pct, limit = activeTP2, stop = activeSL, comment = "L TP2 [BE]")
            strategy.exit("LONG_TRAIL", "LONG", limit = activeTP3, stop = activeSL, comment = "L TP3 [BE]")

if isLong and strategy.position_size > 0 and tp1Hit and not tp2Hit
    if high >= activeTP2
        tp2Hit          := true

if isLong and trailActive and not na(trailStopLevel) and strategy.position_size > 0
    strategy.exit("LONG_TRAIL_ACTIVE", "LONG", stop = trailStopLevel, comment = "L Trail")

// ── Short Strategy Executions
if shortSignal and strategy.position_size == 0
    strategy.entry("SHORT", strategy.short, qty = shortPositionSize, comment = "S Entry " + str.tostring(math.round(confluenceShort, 1)) + "%")

    entryPrice          := close
    activeSL            := shortSL
    activeTP1           := shortTP1
    activeTP2           := shortTP2
    activeTP3           := shortTP3
    tp1Hit              := false
    tp2Hit              := false
    isLong              := false
    isShort             := true
    trailActive         := false
    trailStopLevel      := na

    strategy.exit("SHORT_TP1", "SHORT", qty_percent = i_tp1Pct, limit = shortTP1, stop = shortSL, comment = "S TP1")
    strategy.exit("SHORT_TP2", "SHORT", qty_percent = i_tp2Pct, limit = shortTP2, stop = shortSL, comment = "S TP2")
    strategy.exit("SHORT_TP3", "SHORT", limit = shortTP3, stop = shortSL, comment = "S TP3")

// ── Short Breakeven Logic
if isShort and strategy.position_size < 0 and not tp1Hit
    if low <= activeTP1
        tp1Hit          := true
        if i_breakEvenAfterTP1 and not na(entryPrice)
            strategy.cancel("SHORT_TP1")
            strategy.cancel("SHORT_TP2")
            strategy.cancel("SHORT_TP3")
            activeSL    := entryPrice - (atr * 0.1)
            strategy.exit("SHORT_TP2_BE", "SHORT", qty_percent = i_tp2Pct, limit = activeTP2, stop = activeSL, comment = "S TP2 [BE]")
            strategy.exit("SHORT_TRAIL", "SHORT", limit = activeTP3, stop = activeSL, comment = "S TP3 [BE]")

if isShort and strategy.position_size < 0 and tp1Hit and not tp2Hit
    if low <= activeTP2
        tp2Hit          := true

if isShort and trailActive and not na(trailStopLevel) and strategy.position_size < 0
    strategy.exit("SHORT_TRAIL_ACTIVE", "SHORT", stop = trailStopLevel, comment = "S Trail")


// ============================================================================
// ████  SECTION 15: VISUAL LAYER — EMAs, VWAP & CONFLUENCE HEATMAP  ████████
// ============================================================================

// ── EMA Ribbon Rendering
plot(i_showEMAs ? ema9   : na, "EMA 9",   color = color.new(color.yellow, 0),       linewidth = 1)
plot(i_showEMAs ? ema21  : na, "EMA 21",  color = color.new(color.orange, 0),       linewidth = 1)
plot(i_showEMAs ? ema50  : na, "EMA 50",  color = color.new(color.red,    30),      linewidth = 2)
plot(i_showEMAs ? ema200 : na, "EMA 200", color = color.new(color.white,  0),       linewidth = 3)

p_ema9  = plot(i_showEMAs ? ema9  : na, display = display.none)
p_ema21 = plot(i_showEMAs ? ema21 : na, display = display.none)
fill(p_ema9, p_ema21, color = ema9 > ema21 ? color.new(color.teal, 85) : color.new(color.red, 85), title = "EMA 9/21 Dynamic Fill")

// ── VWAP Visuals (With Corrected Style Types)
plot(i_showVwap and i_useVwap ? vwapVal      : na, "VWAP Baseline", color = color.new(color.white, 0),  linewidth = 2)
plot(i_showVwap and i_useVwap ? vwapBand1Up  : na, "VWAP +1σ Band", color = color.new(color.teal,  60), linewidth = 1)
plot(i_showVwap and i_useVwap ? vwapBand1Dn  : na, "VWAP -1σ Band", color = color.new(color.teal,  60), linewidth = 1)
plot(i_showVwap and i_useVwap ? vwapBand2Up  : na, "VWAP +2σ Band", color = color.new(color.purple,65), linewidth = 1)
plot(i_showVwap and i_useVwap ? vwapBand2Dn  : na, "VWAP -2σ Band", color = color.new(color.purple,65), linewidth = 1)

p_vwapUp1 = plot(i_showVwap and i_useVwap ? vwapBand1Up : na, display = display.none)
p_vwapDn1 = plot(i_showVwap and i_useVwap ? vwapBand1Dn : na, display = display.none)
fill(p_vwapUp1, p_vwapDn1, color = color.new(color.teal, 94), title = "VWAP Dynamic Dev Fill")

// ── Visual Background Heatmaps
color bgHeatColor = na
if i_showScoreBg
    if confluenceLong > confluenceShort and confluenceLong > 50
        float alpha = math.min(95, 98 - (confluenceLong - 50) * 0.4)
        bgHeatColor := color.new(color.teal, int(alpha))
    else if confluenceShort > confluenceLong and confluenceShort > 50
        float alpha = math.min(95, 98 - (confluenceShort - 50) * 0.4)
        bgHeatColor := color.new(color.red, int(alpha))

bgcolor(bgHeatColor, title = "Confluence Trend Heatmap")


// ============================================================================
// ████  SECTION 16: VISUAL LAYER — REAL-TIME STRUCTURE & LABELS  ███████████
// ============================================================================

// ── Real-Time Swing Levels
var line lineSwingHigh = na
var line lineSwingLow  = na

if i_showBOS and not na(lastSwingHigh)
    line.delete(lineSwingHigh)
    lineSwingHigh := line.new(x1 = lastSwingHighBar, y1 = lastSwingHigh, x2 = bar_index + 3, y2 = lastSwingHigh, color = color.new(color.red, 40), width = 1, style = line.style_dashed)

if i_showBOS and not na(lastSwingLow)
    line.delete(lineSwingLow)
    lineSwingLow  := line.new(x1 = lastSwingLowBar, y1 = lastSwingLow, x2 = bar_index + 3, y2 = lastSwingLow, color = color.new(color.teal, 40), width = 1, style = line.style_dashed)

// ── Dynamic Structural Labels
if i_showStructure and bosLong
    label.new(bar_index, high + atr * 0.4, text = "BOS ▲", color = color.new(color.teal, 10), textcolor = color.white, size = size.tiny, style = label.style_label_down)

if i_showStructure and bosShort
    label.new(bar_index, low - atr * 0.4, text = "BOS ▼", color = color.new(color.red, 10), textcolor = color.white, size = size.tiny, style = label.style_label_up)

if i_showStructure and chochBull
    label.new(bar_index, high + atr * 0.6, text = "CHoCH ▲", color = color.new(color.lime, 10), textcolor = color.black, size = size.small, style = label.style_label_down)

if i_showStructure and chochBear
    label.new(bar_index, low - atr * 0.6, text = "CHoCH ▼", color = color.new(color.orange, 10), textcolor = color.black, size = size.small, style = label.style_label_up)


// ============================================================================
// ████  SECTION 17: VISUAL LAYER — ORDER BLOCKS & FVG BOXES  ██████████████
// ============================================================================

var box boxBullOB = na
var box boxBearOB = na

// Clean up and redraw Bull Order Block
if i_showOB and bullOB_Valid and not na(bullOB_Top) and not na(bullOB_Bot)
    box.delete(boxBullOB)
    boxBullOB := box.new(
         left = bar_index - bullOB_Age,
         top = bullOB_Top,
         right = bar_index + i_obBoxExtend,
         bottom = bullOB_Bot,
         border_color = color.new(color.teal, 40),
         bgcolor = color.new(color.teal, 92),
         border_width = 1,
         text = "Bull OB",
         text_color = color.new(color.teal, 20),
         text_size = size.tiny
         )
else if not bullOB_Valid
    box.delete(boxBullOB)
    boxBullOB := na

// Clean up and redraw Bear Order Block
if i_showOB and bearOB_Valid and not na(bearOB_Top) and not na(bearOB_Bot)
    box.delete(boxBearOB)
    boxBearOB := box.new(
         left = bar_index - bearOB_Age,
         top = bearOB_Top,
         right = bar_index + i_obBoxExtend,
         bottom = bearOB_Bot,
         border_color = color.new(color.red, 40),
         bgcolor = color.new(color.red, 92),
         border_width = 1,
         text = "Bear OB",
         text_color = color.new(color.red, 20),
         text_size = size.tiny
         )
else if not bearOB_Valid
    box.delete(boxBearOB)
    boxBearOB := na

var box boxBullFVG = na
var box boxBearFVG = na

// Clean up and redraw Bull FVG
if i_showFVG and bullFVG_Valid and not na(bullFVG_Top) and not na(bullFVG_Bot)
    box.delete(boxBullFVG)
    boxBullFVG := box.new(
         left = bar_index - bullFVG_Age,
         top = bullFVG_Top,
         right = bar_index + 5,
         bottom = bullFVG_Bot,
         border_color = color.new(color.teal, 60),
         bgcolor = color.new(color.teal, 95),
         border_width = 1,
         border_style = line.style_dotted,
         text = "FVG ▲",
         text_color = color.new(color.teal, 40),
         text_size = size.tiny
         )
else if not bullFVG_Valid
    box.delete(boxBullFVG)
    boxBullFVG := na

// Clean up and redraw Bear FVG
if i_showFVG and bearFVG_Valid and not na(bearFVG_Top) and not na(bearFVG_Bot)
    box.delete(boxBearFVG)
    boxBearFVG := box.new(
         left = bar_index - bearFVG_Age,
         top = bearFVG_Top,
         right = bar_index + 5,
         bottom = bearFVG_Bot,
         border_color = color.new(color.red, 60),
         bgcolor = color.new(color.red, 95),
         border_width = 1,
         border_style = line.style_dotted,
         text = "FVG ▼",
         text_color = color.new(color.red, 40),
         text_size = size.tiny
         )
else if not bearFVG_Valid
    box.delete(boxBearFVG)
    boxBearFVG := na


// ============================================================================
// ████  SECTION 18: INTUITIVE SIGNALS WITH PILLARS MARKUP  ██████████████████
// ============================================================================

// Tracking active pillars supporting current market trend
int activePillarsLong  = (safe_structLong > 50 ? 1 : 0) + (safe_obLong > 50 ? 1 : 0) + (safe_momLong > 50 ? 1 : 0) + (safe_vwapLong > 50 ? 1 : 0) + (safe_htfLong > 50 ? 1 : 0)
int activePillarsShort = (safe_structShort > 50 ? 1 : 0) + (safe_obShort > 50 ? 1 : 0) + (safe_momShort > 50 ? 1 : 0) + (safe_vwapShort > 50 ? 1 : 0) + (safe_htfShort > 50 ? 1 : 0)

if i_showSignalLabels and longSignal
    label.new(
         x = bar_index, 
         y = low - atr * 1.0, 
         text = "▲ BUY\n" + str.tostring(math.round(confluenceLong, 1)) + "%\n" + "[Pillars: " + str.tostring(activePillarsLong) + "/5]", 
         color = color.new(color.teal, 10), 
         textcolor = color.white, 
         size = size.small, 
         style = label.style_label_up
         )

if i_showSignalLabels and shortSignal
    label.new(
         x = bar_index, 
         y = high + atr * 1.0, 
         text = "▼ SELL\n" + str.tostring(math.round(confluenceShort, 1)) + "%\n" + "[Pillars: " + str.tostring(activePillarsShort) + "/5]", 
         color = color.new(color.red, 10), 
         textcolor = color.white, 
         size = size.small, 
         style = label.style_label_down
         )


// ============================================================================
// ████  SECTION 19: EXECUTING TARGET LINES FOR ACTIVE TRADES  ███████████████
// ============================================================================

var line activeTp1Line = na
var line activeTp2Line = na
var line activeTp3Line = na
var line activeStopLine = na

if i_showTpSlLines and strategy.position_size != 0
    line.delete(activeTp1Line)
    line.delete(activeTp2Line)
    line.delete(activeTp3Line)
    line.delete(activeStopLine)

    if not na(activeTP1)
        activeTp1Line := line.new(x1 = bar_index - 2, y1 = activeTP1, x2 = bar_index + 12, y2 = activeTP1, color = color.new(color.teal, 40), width = 1, style = line.style_dotted)
    if not na(activeTP2)
        activeTp2Line := line.new(x1 = bar_index - 2, y1 = activeTP2, x2 = bar_index + 12, y2 = activeTP2, color = color.new(color.green, 30), width = 1, style = line.style_dotted)
    if not na(activeTP3)
        activeTp3Line := line.new(x1 = bar_index - 2, y1 = activeTP3, x2 = bar_index + 12, y2 = activeTP3, color = color.new(color.lime, 20), width = 2, style = line.style_dotted)
    if not na(activeSL)
        activeStopLine := line.new(x1 = bar_index - 2, y1 = activeSL, x2 = bar_index + 12, y2 = activeSL, color = color.new(color.red, 30), width = 2, style = line.style_dotted)

if strategy.position_size == 0
    line.delete(activeTp1Line)
    line.delete(activeTp2Line)
    line.delete(activeTp3Line)
    line.delete(activeStopLine)


// ============================================================================
// ████  SECTION 20: CRYPTO PERFORMANCE DASHBOARD  ██████████████████████████
// ============================================================================

var table displayBoard = table.new(
     position = position.top_right, 
     columns = 2, 
     rows = 19, 
     bgcolor = color.new(color.black, 10), 
     border_color = color.new(color.gray, 50), 
     border_width = 1, 
     frame_color = color.new(color.white, 30), 
     frame_width = 1
     )

f_score_theme(float value) =>
    value >= 75 ? color.new(color.lime, 20) :
     value >= 60 ? color.new(color.teal, 20) :
     value >= 40 ? color.new(color.yellow, 20) :
                   color.new(color.red, 20)

f_return_theme(float value) =>
    value >= 0 ? color.new(color.teal, 20) : color.new(color.red, 20)

// Calculate clean closed trade portfolio performance
int   total_closed_trades = strategy.closedtrades
float portfolio_net_profit = strategy.netprofit
float gross_profit_value   = strategy.grossprofit
float gross_loss_value     = strategy.grossloss
float winrate_ratio        = total_closed_trades > 0 ? (strategy.wintrades / total_closed_trades) * 100 : 0
float profit_factor_ratio  = gross_loss_value != 0 ? math.abs(gross_profit_value / gross_loss_value) : (gross_profit_value > 0 ? 99.0 : 0)
float avg_trade_win        = strategy.wintrades > 0 ? gross_profit_value / strategy.wintrades : 0
float avg_trade_loss       = strategy.losstrades > 0 ? math.abs(gross_loss_value / strategy.losstrades) : 0
float max_drawdown_amount  = strategy.max_drawdown
float max_drawdown_percent = strategy.max_drawdown_percent
float current_total_equity = strategy.equity
float return_on_investment = ((current_total_equity - strategy.initial_capital) / strategy.initial_capital) * 100

if i_showDashboard and barstate.islast
    // Header Row
    table.cell(displayBoard, 0, 0, "⚡ APEX MERIDIAN", bgcolor = color.new(color.navy, 10), text_color = color.white, text_size = size.normal, text_halign = text.align_center)
    table.cell(displayBoard, 1, 0, "CRYPTO CONFLUENCE ENGINE", bgcolor = color.new(color.navy, 10), text_color = color.silver, text_size = size.tiny, text_halign = text.align_center)

    // Live Metrics Division Row
    table.cell(displayBoard, 0, 1, "━━━ CONFLUENCE METRICS ━━━", bgcolor = color.new(color.gray, 60), text_color = color.white, text_size = size.tiny, text_halign = text.align_center)
    table.cell(displayBoard, 1, 1, "━━━━━━━━━━━━━━━━━━━━━━", bgcolor = color.new(color.gray, 60), text_color = color.white, text_size = size.tiny, text_halign = text.align_center)

    // Dynamic Live Score Rows
    table.cell(displayBoard, 0, 2, "📈 Bullish Confluence Score", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 2, str.tostring(math.round(confluenceLong, 1)) + "%", bgcolor = f_score_theme(confluenceLong), text_color = color.white, text_size = size.small)

    table.cell(displayBoard, 0, 3, "📉 Bearish Confluence Score", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 3, str.tostring(math.round(confluenceShort, 1)) + "%", bgcolor = f_score_theme(confluenceShort), text_color = color.white, text_size = size.small)

    // Pillars Breakdown Rows
    table.cell(displayBoard, 0, 4, "🏗 Market Structure Pillar", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 4, str.tostring(math.round(structureLongScore, 0)) + "L / " + str.tostring(math.round(structureShortScore, 0)) + "S", bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 5, "🟣 Order Block Proximity", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 5, str.tostring(math.round(obLongScore, 0)) + "L / " + str.tostring(math.round(obShortScore, 0)) + "S", bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 6, "⚡ Oscillator Momentum", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 6, str.tostring(math.round(momentumLongScore, 0)) + "L / " + str.tostring(math.round(momentumShortScore, 0)) + "S", bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 7, "🔵 Volume-Weighted VWAP", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 7, str.tostring(math.round(vwapLongScore, 0)) + "L / " + str.tostring(math.round(vwapShortScore, 0)) + "S", bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 8, "🔷 HTF Trend Bias", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 8, str.tostring(math.round(htfLongScore, 0)) + "L / " + str.tostring(math.round(htfShortScore, 0)) + "S", bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    // Volatility State Row
    table.cell(displayBoard, 0, 9, "📊 ADX Trend Status", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    string adx_txt = str.tostring(math.round(adx, 1)) + " | " + (isStrongTrend ? "STRONG" : isTrending ? "TRENDING" : "RANGING")
    table.cell(displayBoard, 1, 9, adx_txt, bgcolor = isStrongTrend ? color.new(color.teal, 30) : isTrending ? color.new(color.blue, 40) : color.new(color.gray, 50), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 10, "⚡ ATR Vol Percentile", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 10, str.tostring(math.round(volPercentile, 1)) + "% | " + (volFilterPass ? "✓ ACTIVE" : "✗ BLOCKED"), bgcolor = volFilterPass ? color.new(color.teal, 50) : color.new(color.red, 40), text_color = color.white, text_size = size.tiny)

    // Strategy Performance Metrics Row
    table.cell(displayBoard, 0, 11, "━━━ PORTFOLIO SUMMARY ━━━", bgcolor = color.new(color.gray, 60), text_color = color.white, text_size = size.tiny, text_halign = text.align_center)
    table.cell(displayBoard, 1, 11, "━━━━━━━━━━━━━━━━━━━━━━", bgcolor = color.new(color.gray, 60), text_color = color.white, text_size = size.tiny, text_halign = text.align_center)

    table.cell(displayBoard, 0, 12, "🎯 System Win Rate", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 12, str.tostring(math.round(winrate_ratio, 1)) + "%", bgcolor = winrate_ratio >= 50 ? color.new(color.teal, 30) : color.new(color.red, 40), text_color = color.white, text_size = size.small)

    table.cell(displayBoard, 0, 13, "⚖️ Net Return (ROI)", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 13, str.tostring(math.round(return_on_investment, 2)) + "% ($" + str.tostring(math.round(portfolio_net_profit, 2)) + ")", bgcolor = f_return_theme(return_on_investment), text_color = color.white, text_size = size.small)

    table.cell(displayBoard, 0, 14, "💼 Total Executed Trades", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 14, str.tostring(total_closed_trades), bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 15, "📊 Profit Factor Ratio", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 15, str.tostring(math.round(profit_factor_ratio, 2)), bgcolor = profit_factor_ratio >= 1.5 ? color.new(color.teal, 30) : profit_factor_ratio >= 1.0 ? color.new(color.yellow, 40) : color.new(color.red, 40), text_color = color.white, text_size = size.small)

    table.cell(displayBoard, 0, 16, "💸 Avg Win / Avg Loss", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 16, "$" + str.tostring(math.round(avg_trade_win, 1)) + " / $" + str.tostring(math.round(avg_trade_loss, 1)), bgcolor = color.new(color.black, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 17, "📉 Max Portfolio Drawdown", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 17, str.tostring(math.round(max_drawdown_percent, 2)) + "% ($" + str.tostring(math.round(max_drawdown_amount, 1)) + ")", bgcolor = max_drawdown_percent < 15 ? color.new(color.teal, 40) : max_drawdown_percent < 30 ? color.new(color.yellow, 40) : color.new(color.red, 30), text_color = color.white, text_size = size.tiny)

    table.cell(displayBoard, 0, 18, "🛡️ Kill Switch Cooldown", bgcolor = color.new(color.black, 20), text_color = color.silver, text_size = size.tiny)
    table.cell(displayBoard, 1, 18, killActive ? "🔴 ACTIVE" : "🟢 PASS", bgcolor = killActive ? color.new(color.red, 30) : color.new(color.teal, 50), text_color = color.white, text_size = size.tiny)


// ============================================================================
// ████  SECTION 21: EXPORT DATA ALERTS  ███████████████████████████████████
// ============================================================================

alertcondition(longSignal,  title = "Apex Meridian Buy Setup",  message = "Apex Buy Setup: Confluence Score {{plot_0}}%, Close Price {{close}}")
alertcondition(shortSignal, title = "Apex Meridian Sell Setup", message = "Apex Sell Setup: Confluence Score {{plot_1}}%, Close Price {{close}}")
alertcondition(killActive,  title = "Apex Kill Switch Active",  message = "Apex Risk Control Triggered: Excessive consecutive losses. Cooling down.")

// ── Export Dynamic Scores for Alarm Integration
plot(confluenceLong,  "Bull Confluence Export",  display = display.data_window, color = color.teal)
plot(confluenceShort, "Bear Confluence Export",  display = display.data_window, color = color.red)
plot(adx,             "ADX Value Export",        display = display.data_window, color = color.yellow)
plot(volPercentile,   "ATR Vol Percentile Exp",  display = display.data_window, color = color.orange)


// ============================================================================
// ████  SECTION 22: TRAILING AND ACTIVE SL VISUAL PLOTS  ████████████████████
// ============================================================================

plot(trailActive and not na(trailStopLevel) ? trailStopLevel : na, "Dynamic Trail stop Line", color = color.new(color.yellow, 20), linewidth = 2, style = plot.style_stepline)
plot(strategy.position_size != 0 and not na(activeSL) ? activeSL : na, "Active Execution SL", color = color.new(color.red, 30), linewidth = 1, style = plot.style_circles)

======================================================================

6. 